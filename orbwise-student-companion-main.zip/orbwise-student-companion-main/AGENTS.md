<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Project rules
- The J.A.R.V.I.S app is a standalone HTML app in `public/jarvis/` (index, comandos, status, its own service worker and manifest); `/` redirects to it instead of embedding it, because frames block the microphone. Edit those files rather than re-creating features in React. Why: keeps the user-provided app intact as the single merged version.
- The app's built-in voice and AI use the server routes `/api/public/tts` and `/api/public/chat` with the server-held AI key. Why: works without the user pasting any key.
- When bumping the app, also bump the cache name in `public/jarvis/sw.js` so installed phones pick up the new version.
