const C='jarvis-v25';
const F=['./','index.html','manifest.webmanifest','icon-192.png','icon-512.png','jv-plus.css','jv-plus.js','jv-holo.js','jv-lab.js','jv-studio.js','jv-lang.js','jv-music.js','jv-cloud.js','jv-spotify.js','protocolos.js','supabase.js'];
self.addEventListener('install',e=>e.waitUntil(caches.open(C).then(c=>c.addAll(F).catch(()=>{})).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==C).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
// Sempre tenta a versão nova primeiro (assim o celular recebe as correções); sem internet, usa a cópia guardada.
self.addEventListener('fetch',e=>{
 const r=e.request,u=new URL(r.url);
 if(r.method!=='GET'||u.origin!==location.origin||u.pathname.startsWith('/api/'))return;
 const img=/\.(png|jpg|jpeg|webp|svg|ico)$/i.test(u.pathname);
 if(img){e.respondWith(caches.match(r).then(c=>c||fetch(r).then(res=>{if(res.ok){const cp=res.clone();caches.open(C).then(x=>x.put(r,cp))}return res})));return}
 e.respondWith(fetch(r).then(res=>{if(res.ok){const cp=res.clone();caches.open(C).then(x=>x.put(r,cp))}return res}).catch(()=>caches.match(r,{ignoreSearch:true}).then(c=>c||caches.match('./index.html'))));
});
// Notificações enviadas pelo servidor: aparecem mesmo com o app fechado.
self.addEventListener('push',e=>{let d={};try{d=e.data?e.data.json():{}}catch(x){d={body:e.data?e.data.text():''}}
 e.waitUntil(self.registration.showNotification(d.title||'J.A.R.V.I.S.',{body:d.body||'',tag:d.tag||undefined,renotify:!!d.tag,icon:'icon-192.png',badge:'icon-192.png',vibrate:[200,100,200],requireInteraction:/^ev-/.test(d.tag||''),data:{url:d.url||'./index.html'}}));});
self.addEventListener('notificationclick',e=>{e.notification.close();const u=new URL((e.notification.data&&e.notification.data.url)||'./index.html',self.registration.scope).href;
 e.waitUntil(clients.matchAll({type:'window',includeUncontrolled:true}).then(list=>{const w=list.find(c=>c.url.includes('/jarvis/'))||list[0];return w?w.focus():clients.openWindow(u)}));});
