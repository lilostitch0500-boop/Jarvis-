/* Tutor de idiomas: conversa guiada no idioma escolhido (fala e escuta no idioma), correções em português,
   frases para treinar pronúncia com nota. */
(function(){
'use strict';
const X=window.JVX;if(!X||!X.labPaneEl)return;const {q,qa,ce,LSg,LSs}=X,esc=X.esc;
const msg=t=>{try{toast(t)}catch{}};
const LANGS={en:['Inglês','en-US','🇺🇸'],es:['Espanhol','es-ES','🇪🇸'],fr:['Francês','fr-FR','🇫🇷'],it:['Italiano','it-IT','🇮🇹'],de:['Alemão','de-DE','🇩🇪'],ja:['Japonês','ja-JP','🇯🇵']};
const PH={
 en:[['Good morning! How are you today?','Bom dia! Como você está hoje?'],['My name is Murilo and I live in Brazil.','Meu nome é Murilo e eu moro no Brasil.'],['Could you help me, please?','Você poderia me ajudar, por favor?'],['I would like a glass of water.','Eu gostaria de um copo de água.'],['Where is the nearest subway station?','Onde fica a estação de metrô mais próxima?'],['I am learning English with Jarvis.','Estou aprendendo inglês com o Jarvis.'],['What do you do for fun?','O que você faz para se divertir?'],['See you tomorrow!','Até amanhã!']],
 es:[['¡Buenos días! ¿Cómo estás?','Bom dia! Como você está?'],['Me llamo Murilo y soy de Brasil.','Eu me chamo Murilo e sou do Brasil.'],['¿Dónde está el baño?','Onde fica o banheiro?'],['Quisiera una mesa para dos, por favor.','Eu queria uma mesa para dois, por favor.'],['¿Cuánto cuesta esto?','Quanto custa isto?'],['Estoy aprendiendo español.','Estou aprendendo espanhol.'],['Me gusta mucho la música.','Eu gosto muito de música.'],['¡Hasta luego!','Até logo!']],
 fr:[['Bonjour ! Comment ça va ?','Olá! Como vai?'],['Je m’appelle Murilo.','Eu me chamo Murilo.'],['Je voudrais un café, s’il vous plaît.','Eu queria um café, por favor.'],['Où est la gare ?','Onde fica a estação de trem?'],['Je ne comprends pas.','Eu não entendo.'],['Parlez plus lentement, s’il vous plaît.','Fale mais devagar, por favor.'],['J’aime apprendre les langues.','Eu gosto de aprender idiomas.'],['À bientôt !','Até breve!']],
 it:[['Buongiorno! Come stai?','Bom dia! Como você está?'],['Mi chiamo Murilo.','Eu me chamo Murilo.'],['Vorrei una pizza margherita.','Eu queria uma pizza margherita.'],['Dov’è la stazione?','Onde fica a estação?'],['Quanto costa?','Quanto custa?'],['Sto imparando l’italiano.','Estou aprendendo italiano.'],['Grazie mille!','Muito obrigado!'],['A domani!','Até amanhã!']],
 de:[['Guten Morgen! Wie geht es dir?','Bom dia! Como você está?'],['Ich heiße Murilo.','Eu me chamo Murilo.'],['Ich komme aus Brasilien.','Eu venho do Brasil.'],['Wo ist der Bahnhof?','Onde fica a estação de trem?'],['Ich hätte gern ein Wasser.','Eu gostaria de uma água.'],['Ich lerne Deutsch.','Eu estou aprendendo alemão.'],['Danke schön!','Muito obrigado!'],['Bis morgen!','Até amanhã!']],
 ja:[['おはようございます。','Bom dia. (ohayō gozaimasu)'],['はじめまして、ムリロです。','Muito prazer, sou o Murilo. (hajimemashite, Murilo desu)'],['ありがとうございます。','Muito obrigado. (arigatō gozaimasu)'],['すみません、駅はどこですか。','Com licença, onde fica a estação? (sumimasen, eki wa doko desu ka)'],['これはいくらですか。','Quanto custa isto? (kore wa ikura desu ka)'],['日本語を勉強しています。','Estou estudando japonês. (nihongo o benkyō shite imasu)'],['おいしいです！','Está delicioso! (oishii desu)'],['また明日。','Até amanhã. (mata ashita)']]};
const P=X.labPaneEl('lang');
P.innerHTML=`<div class="jxrow"><select id="tuL" aria-label="Idioma">${Object.entries(LANGS).map(([k,v])=>`<option value="${k}">${v[2]} ${v[0]}</option>`).join('')}</select><select id="tuLv" aria-label="Nível"><option value="iniciante">Iniciante</option><option value="intermediário">Intermediário</option><option value="avançado">Avançado</option></select><select id="tuTh" aria-label="Tema"><option>Conversa livre</option><option>Viagem e aeroporto</option><option>Restaurante</option><option>Escola e estudos</option><option>Games, filmes e séries</option><option>Entrevista de emprego</option><option>Tecnologia</option></select><button class="x" type="button" id="tuGo">▶ Começar aula</button><button class="x" type="button" id="tuEnd" hidden>■ Encerrar</button></div>
<div class="tuChat" id="tuChat" role="log" aria-live="polite"><div class="hint">Escolha o idioma, o nível e o tema, e toque em ▶ Começar aula. O Jarvis fala no idioma, o senhor responde falando ou escrevendo, e ele corrige em português.</div></div>
<form id="tuF" class="jxrow tuBar"><button type="button" class="x tuMic" id="tuMic" aria-label="Falar no idioma">🎤</button><input class="t grow" id="tuIn" placeholder="Responda no idioma que está aprendendo…" autocomplete="off"><button class="x">Enviar</button></form>
<label class="hint" style="display:flex;gap:6px;align-items:center"><input type="checkbox" id="tuPt"> Ler as correções em português em voz alta</label>
<h2>Frases para treinar a pronúncia</h2><div class="hint">Toque em 🔊 para ouvir e em 🎤 para repetir: o Jarvis dá uma nota para a sua pronúncia.</div><div class="tuPh" id="tuPh" style="margin-top:8px"></div>`;
const chat=q('#tuChat',P),inp=q('#tuIn',P),selL=q('#tuL',P),ptC=q('#tuPt',P);
const st=LSg('jv_tutor',{l:'en',lv:'iniciante',th:'Conversa livre',pt:false});selL.value=st.l;q('#tuLv',P).value=st.lv;q('#tuTh',P).value=st.th;ptC.checked=!!st.pt;
const keep=()=>LSs('jv_tutor',{l:selL.value,lv:q('#tuLv',P).value,th:q('#tuTh',P).value,pt:ptC.checked});
[selL,q('#tuLv',P),q('#tuTh',P),ptC].forEach(e=>e.addEventListener('change',()=>{keep();if(e===selL){rPh();if(on)start()}}));
let on=false,hist=[],busy=false;
const L=()=>LANGS[selL.value];

/* ---------- voz no idioma ---------- */
const SYN=window.speechSynthesis;
function voiceFor(bcp){const vs=SYN?SYN.getVoices():[],b=bcp.toLowerCase(),p=b.split('-')[0];return vs.find(v=>v.lang.toLowerCase().replace('_','-')===b)||vs.find(v=>v.lang.toLowerCase().startsWith(p))}
function say(t,bcp,then){if(!SYN){then&&then();return}try{SYN.cancel()}catch{}const u=new SpeechSynthesisUtterance(t);u.lang=bcp;const v=voiceFor(bcp);if(v)u.voice=v;u.rate=bcp.startsWith('pt')?1:.9;u.onend=u.onerror=()=>then&&then();SYN.speak(u)}
const SRc=window.SpeechRecognition||window.webkitSpeechRecognition;let rec=null;
function hear(bcp,onFinal,onPart,btn){if(!SRc){msg('O reconhecimento de voz não funciona neste navegador. Use o Chrome.');return}if(rec){try{rec.abort()}catch{}rec=null;return}
 try{stopRec()}catch{}try{SYN.cancel()}catch{}const r=rec=new SRc();r.lang=bcp;r.interimResults=true;r.maxAlternatives=3;r.continuous=false;btn&&btn.classList.add('on');
 r.onresult=e=>{const x=e.results[e.results.length-1];if(x.isFinal){onFinal([...x].map(a=>a.transcript))}else onPart&&onPart(x[0].transcript)};
 r.onerror=e=>{if(e.error==='not-allowed'||e.error==='service-not-allowed')msg('Microfone bloqueado. Libere o microfone para o Jarvis no navegador.');else if(e.error!=='no-speech'&&e.error!=='aborted')msg('Não consegui ouvir: '+e.error)};
 r.onend=()=>{if(rec===r)rec=null;btn&&btn.classList.remove('on');setTimeout(()=>{try{resume()}catch{}},700)};try{r.start()}catch(e){rec=null;btn&&btn.classList.remove('on');msg('Não consegui ligar o microfone.')}}

/* ---------- conversa ---------- */
const tag=ce('div','','<span></span><button type="button">Sair</button>');tag.id='jxTutorTag';document.body.append(tag);
q('span',tag).onclick=()=>X.labPane('lang');q('button',tag).onclick=()=>end(true);
function bubble(k,target,pt){const d=ce('div','tuB '+k);if(k==='u'){d.textContent=target}else{const a=ce('div','tuT');a.textContent=target;d.append(a);if(pt){const b=ce('div','tuPt');b.textContent=pt;d.append(b)}const s=ce('button','x','🔊');s.type='button';s.setAttribute('aria-label','Ouvir de novo');s.onclick=()=>say(target,L()[1]);d.append(s)}
 const h=q('.hint',chat);if(h&&!chat.querySelector('.tuB'))h.remove();chat.append(d);chat.scrollTop=chat.scrollHeight;return d}
function sys(){const[n]=L(),lv=q('#tuLv',P).value,th=q('#tuTh',P).value;return`Você é J.A.R.V.I.S., tutor particular de ${n} do senhor (nível ${lv}, tema: ${th}). Conduza uma conversa natural para ele praticar: frases curtas e adequadas ao nível, com interesse genuíno pelo que ele diz, sem transformar a conversa num questionário.
Responda SEMPRE em exatamente duas linhas, neste formato:
ALVO: (sua fala em ${n}, 1 ou 2 frases curtas, terminando com uma pergunta simples para continuar)${selL.value==='ja'?' Inclua a leitura em romaji entre parênteses.':''}
PT: (em português do Brasil: a tradução da sua fala; e, se o senhor errou algo em ${n}, a correção gentil com a forma certa e uma explicação de 1 frase; se acertou, um elogio curto)
Sem markdown e sem emojis.`}
function parse(t){const m=String(t).match(/ALVO:\s*([\s\S]*?)(?:\n\s*PT:\s*([\s\S]*))?$/i);if(m)return[m[1].trim(),(m[2]||'').trim()];return[String(t).trim(),'']}
async function turn(user){if(busy)return;busy=true;const w=bubble('a','…');w.classList.add('wait');if(user)hist.push({role:'user',content:user});
 try{const msgs=hist.length?hist:[{role:'user',content:'(Comece a aula: cumprimente o senhor e faça a primeira pergunta sobre o tema.)'}];const t=await X.tutorAsk(msgs.slice(-14),sys());hist.push({role:'assistant',content:t});const[a,pt]=parse(t);w.remove();bubble('a',a,pt);say(a.replace(/\([^)]*\)/g,''),L()[1],()=>{if(ptC.checked&&pt)say(pt,'pt-BR')})}
 catch(e){w.remove();if(user)hist.pop();const d=bubble('a','Não consegui continuar a aula agora: '+e.message+(/cr[eé]dito/i.test(e.message)?' Enquanto isso, as frases de pronúncia abaixo funcionam sem IA.':''));d.classList.add('err')}finally{busy=false}}
function start(){on=true;hist=[];chat.innerHTML='';q('#tuGo',P).hidden=true;q('#tuEnd',P).hidden=false;q('span',tag).textContent='🌐 AULA DE '+L()[0].toUpperCase();tag.classList.add('on');X.sfx('boot');turn('')}
function end(say_){on=false;tag.classList.remove('on');q('#tuGo',P).hidden=false;q('#tuEnd',P).hidden=true;try{SYN.cancel()}catch{}if(rec){try{rec.abort()}catch{}}if(say_)msg('Aula encerrada. Muito bem, senhor.')}
X.tutorStart=k=>{if(k&&LANGS[k]){selL.value=k;keep();rPh()}X.labPane('lang');start()};
q('#tuGo',P).onclick=start;q('#tuEnd',P).onclick=()=>end(true);
q('#tuF',P).onsubmit=e=>{e.preventDefault();const v=inp.value.trim();if(!v)return;if(!on){start();setTimeout(()=>{},0)}inp.value='';bubble('u',v);turn(v)};
q('#tuMic',P).onclick=e=>hear(L()[1],alts=>{const v=alts[0].trim();inp.value='';if(!v)return;if(!on){on=true;q('#tuGo',P).hidden=true;q('#tuEnd',P).hidden=false;q('span',tag).textContent='🌐 AULA DE '+L()[0].toUpperCase();tag.classList.add('on')}bubble('u',v);turn(v)},p=>{inp.value=p},e.currentTarget);

/* ---------- pronúncia ---------- */
const norm=s=>String(s).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\([^)]*\)/g,'').replace(/[^\p{L}\p{N}]/gu,'');
function dice(a,b){a=norm(a);b=norm(b);if(!a||!b)return 0;if(a===b)return 1;const bg=s=>{const m=new Map();for(let i=0;i<s.length-1;i++){const k=s.slice(i,i+2);m.set(k,(m.get(k)||0)+1)}return m};const A=bg(a),B=bg(b);let n=0;A.forEach((v,k)=>{n+=Math.min(v,B.get(k)||0)});return 2*n/Math.max(1,(a.length-1)+(b.length-1))}
function rPh(){const el=q('#tuPh',P),k=selL.value;el.innerHTML='';(PH[k]||[]).forEach(([t,tr])=>{const r=ce('div');r.innerHTML=`<span><b>${esc(t)}</b><small>${esc(tr)}</small></span><span class="tuAct"><em class="tuSc"></em><button type="button" class="x" aria-label="Ouvir">🔊</button><button type="button" class="x" aria-label="Repetir em voz alta">🎤</button></span>`;const[o,m]=qa('button',r),sc=q('.tuSc',r);o.onclick=()=>say(t,LANGS[k][1]);
  m.onclick=()=>hear(LANGS[k][1],alts=>{const best=Math.max(...alts.map(a=>dice(a,t))),p=Math.round(best*100);sc.textContent=p+'%';sc.className='tuSc '+(p>=85?'ok':p>=60?'mid':'low');sc.title='Entendi: '+alts[0];msg((p>=85?'Excelente, senhor! ':p>=60?'Quase lá. ':'Vamos de novo, com calma. ')+'Entendi: "'+alts[0]+'" ('+p+'%)');X.sfx(p>=85?'ok':'tick')},null,m);el.append(r)})}
rPh();

/* ---------- voz (comandos em português) ---------- */
const NM={ingles:'en',espanhol:'es',frances:'fr',italiano:'it',alemao:'de',japones:'ja'};
X.addCmd((s,n)=>{let m;
 if(m=n.match(/(?:aula|aulas|praticar|treinar|me ensin\w*|quero aprender|vamos praticar|conversar em|falar)\s+(?:de |o |a |em )?(ingles|espanhol|frances|italiano|alemao|japones)\b/)){X.tutorStart(NM[m[1]]);return'Aula de '+LANGS[NM[m[1]]][0].toLowerCase()+' iniciada, senhor. Responda falando no botão 🎤 da aula ou escrevendo.'}
 if(/^(?:abr\w*|mostr\w*)\s+(?:o |a )?(?:tutor de idiomas|idiomas|aba de idiomas)$/.test(n)){X.labPane('lang');return'Tutor de idiomas aberto.'}
 if(on&&/^(sair da aula|encerr\w* (?:a )?aula|termin\w* (?:a )?aula|fim da aula)$/.test(n)){end(false);return'Aula encerrada. Belo progresso hoje, senhor.'}
 return null});
X.addSys(()=>on?'AULA DE IDIOMA ATIVA: o senhor está praticando '+L()[0]+' na aba Lab › Idiomas.':'');
})();
