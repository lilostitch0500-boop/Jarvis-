/* Spotify do usuário (login seguro PKCE direto no navegador; nenhuma senha passa pelo Jarvis). */
(function(){
const SC='user-read-playback-state user-modify-playback-state user-read-currently-playing playlist-read-private playlist-read-collaborative';
const RED=location.origin+'/jarvis/index.html';
const G=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))??d}catch{return d}},S=(k,v)=>{try{v==null?localStorage.removeItem(k):localStorage.setItem(k,JSON.stringify(v))}catch{}};
const b64u=b=>btoa(String.fromCharCode(...new Uint8Array(b))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
let tk=G('jv_sp',null);
async function tokenReq(p){const r=await fetch('https://accounts.spotify.com/api/token',{method:'POST',headers:{'content-type':'application/x-www-form-urlencoded'},body:new URLSearchParams(p)});const j=await r.json().catch(()=>({}));if(!r.ok)throw Error('Spotify recusou o acesso: '+(j.error_description||j.error||r.status));tk={a:j.access_token,r:j.refresh_token||tk?.r,e:Date.now()+(j.expires_in||3600)*1e3};S('jv_sp',tk);return tk}
async function access(){if(!tk)throw Error('Spotify não conectado. Conecte em Config → Spotify.');if(Date.now()>tk.e-6e4)await tokenReq({grant_type:'refresh_token',refresh_token:tk.r,client_id:SP.cid()});return tk.a}
async function api(m,p,body,retry){const r=await fetch('https://api.spotify.com/v1'+p,{method:m,headers:{authorization:'Bearer '+await access(),...(body?{'content-type':'application/json'}:{})},body:body?JSON.stringify(body):undefined});
 if(r.status===401&&!retry){tk.e=0;return api(m,p,body,1)}
 if(r.status===204||r.status===202)return null;const j=await r.json().catch(()=>null);
 if(!r.ok){const reason=j?.error?.reason||'',msg=j?.error?.message||'';const e=Error(reason==='NO_ACTIVE_DEVICE'||r.status===404&&/device/i.test(msg)?'Não há nenhum aparelho com o Spotify aberto. Abra o Spotify no celular ou no computador e tente de novo.':reason==='PREMIUM_REQUIRED'||/premium/i.test(msg)?'Controlar a reprodução exige Spotify Premium.':r.status===403?'O Spotify não permitiu esta ação ('+(msg||'403')+'). Se o app do Spotify estiver em modo de desenvolvimento, seu e-mail precisa estar na lista de usuários dele.':'Spotify: '+(msg||r.status));e.code=reason||r.status;throw e}
 return j}
const SP={
 cid:()=>G('jv_sp_cid',''),setCid:v=>S('jv_sp_cid',String(v||'').trim()),redirect:RED,
 connected:()=>!!tk,
 async login(){const cid=SP.cid();if(!/^[0-9a-f]{32}$/i.test(cid))throw Error('Cole primeiro o Client ID do seu app do Spotify (32 caracteres).');const v=b64u(crypto.getRandomValues(new Uint8Array(48))),ch=b64u(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(v))),st=b64u(crypto.getRandomValues(new Uint8Array(12)));sessionStorage.setItem('jv_sp_v',v);sessionStorage.setItem('jv_sp_s',st);location.href='https://accounts.spotify.com/authorize?'+new URLSearchParams({response_type:'code',client_id:cid,scope:SC,redirect_uri:RED,code_challenge_method:'S256',code_challenge:ch,state:st})},
 async handle(){const q=new URLSearchParams(location.search),code=q.get('code'),st=q.get('state'),er=q.get('error');if(!code&&!er)return null;if(!st||st!==sessionStorage.getItem('jv_sp_s'))return null;history.replaceState(null,'',location.pathname);if(er)return{ok:false,msg:'Conexão com o Spotify cancelada ('+er+').'};try{await tokenReq({grant_type:'authorization_code',code,redirect_uri:RED,client_id:SP.cid(),code_verifier:sessionStorage.getItem('jv_sp_v')});const me=await SP.me();return{ok:true,msg:'Spotify conectado à conta '+(me.display_name||me.id)+(me.product==='premium'?' (Premium).':'. Aviso: sem Premium, o Spotify não deixa controlar a reprodução; posso pesquisar e abrir músicas.')}}catch(e){return{ok:false,msg:e.message}}},
 logout(){tk=null;S('jv_sp',null)},
 me:()=>api('GET','/me'),
 async search(q,type){const j=await api('GET','/search?'+new URLSearchParams({q,type:type||'track',limit:'5',market:'from_token'}));return j},
 async playTrack(q){const j=await SP.search(q,'track'),t=j?.tracks?.items?.[0];if(!t)throw Error('Não encontrei "'+q+'" no Spotify.');try{await api('PUT','/me/player/play',{uris:[t.uri]});return{t,played:true}}catch(e){if(e.code==='PREMIUM_REQUIRED'||e.code==='NO_ACTIVE_DEVICE'||e.code===404||e.code===403)return{t,played:false,err:e.message};throw e}},
 async playlists(){const j=await api('GET','/me/playlists?limit=50');return j?.items||[]},
 async playPlaylist(q){const n=s=>s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');let p=(await SP.playlists()).find(x=>n(x.name).includes(n(q)));let mine=!!p;if(!p){const j=await SP.search(q,'playlist');p=(j?.playlists?.items||[]).filter(Boolean)[0]}if(!p)throw Error('Não encontrei a playlist "'+q+'".');try{await api('PUT','/me/player/play',{context_uri:p.uri});return{p,mine,played:true}}catch(e){return{p,mine,played:false,err:e.message}}},
 pause:()=>api('PUT','/me/player/pause'),resume:()=>api('PUT','/me/player/play'),
 next:()=>api('POST','/me/player/next'),prev:()=>api('POST','/me/player/previous'),
 volume:v=>api('PUT','/me/player/volume?volume_percent='+Math.max(0,Math.min(100,v|0))),
 now:()=>api('GET','/me/player/currently-playing')
};
window.SP=SP;
})();
