/* Mini-player do Spotify no HUD: mostra a música tocando e permite voltar, pausar e avançar.
   Só aparece quando o Spotify está conectado em Config. */
(function(){
'use strict';
const X=window.JVX;if(!X||!window.SP)return;const {q,ce}=X;
const st=q('#stage');if(!st)return;
const el=ce('div','',`<img alt="" hidden><div class="mt"><b>Spotify</b><small>—</small></div><button type="button" data-a="prev" aria-label="Música anterior">⏮</button><button type="button" data-a="pp" aria-label="Pausar ou tocar">⏯</button><button type="button" data-a="next" aria-label="Próxima música">⏭</button><button type="button" data-a="x" aria-label="Esconder mini-player">✕</button>`);
el.id='jxMini';el.hidden=true;st.append(el);
let playing=false,hideUntil=+sessionStorage.getItem('jv_mini_x')||0,t=0;
function set(j){const it=j&&j.item;if(!it){el.hidden=true;return}const im=q('img',el),src=(it.album&&it.album.images||[]).slice(-1)[0];im.hidden=!src;if(src)im.src=src.url;q('b',el).textContent=it.name||'—';q('small',el).textContent=(it.artists||[]).map(a=>a.name).join(', ')||(it.show&&it.show.name)||'';playing=!!j.is_playing;q('[data-a=pp]',el).textContent=playing?'⏸':'▶';el.classList.toggle('on',playing);el.hidden=Date.now()<hideUntil}
async function poll(){clearTimeout(t);t=setTimeout(poll,15000);if(!SP.connected()||document.hidden){el.hidden=true;return}try{set(await SP.now())}catch(e){el.hidden=true}}
el.onclick=async e=>{const a=e.target.closest('[data-a]')?.dataset.a;if(!a)return;if(a==='x'){hideUntil=Date.now()+36e5;sessionStorage.setItem('jv_mini_x',hideUntil);el.hidden=true;return}
 try{if(a==='pp')await(playing?SP.pause():SP.resume());else if(a==='next')await SP.next();else await SP.prev();setTimeout(poll,700)}catch(er){try{toast(er.message)}catch{}}};
document.addEventListener('visibilitychange',()=>{if(!document.hidden)poll()});
X.miniShow=()=>{hideUntil=0;sessionStorage.removeItem('jv_mini_x');poll()};
X.addCmd((s,n)=>{if(/^(?:mostr\w*|abr\w*)\s+(?:o )?(?:mini ?player|player)$/.test(n)){if(!SP.connected())return'O Spotify não está conectado, senhor. Conecte em Config › Spotify.';X.miniShow();return'Mini-player no HUD.'}return null});
setTimeout(poll,2500);
})();
