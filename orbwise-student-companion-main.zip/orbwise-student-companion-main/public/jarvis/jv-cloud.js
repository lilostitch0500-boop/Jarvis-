/* Conta, agenda, memória, preferências e notificações do J.A.R.V.I.S. (Lovable Cloud). */
(function(){
const URL_='https://qdfobqsognzxtryqhacp.supabase.co',KEY='sb_publishable_50JgpUedkA0FWhmde1SI3w_4ztLhFve';
const sb=window.supabase.createClient(URL_,KEY,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:false},global:{fetch:(i,o={})=>{const h=new Headers(o.headers);if(h.get('Authorization')==='Bearer '+KEY)h.delete('Authorization');h.set('apikey',KEY);return fetch(i,{...o,headers:h})}}});
let user=null;
const ok=r=>{if(r.error)throw Error(r.error.message);return r.data};
const JV={sb,
 get user(){return user},
 ready:(async()=>{const{data}=await sb.auth.getUser().catch(()=>({data:{}}));if(!data||!data.user){const s=(await sb.auth.getSession()).data.session;if(s&&!navigator.onLine){user=s.user;return user}location.replace('/entrar');throw Error('sem sessão')}user=data.user;return user})(),
 async token(){const{data}=await sb.auth.getSession();return data.session?.access_token||''},
 async hdr(){return{'content-type':'application/json',authorization:'Bearer '+await JV.token()}},
 async api(path,body){return fetch(path,{method:body===undefined?'GET':'POST',headers:await JV.hdr(),body:body===undefined?undefined:JSON.stringify(body)})},
 signOut(){location.href='/entrar?sair=1'},
 events:{
  list:async()=>ok(await sb.from('events').select('*').eq('status','ativo').gte('starts_at',new Date(Date.now()-864e5).toISOString()).order('starts_at').limit(300)),
  create:async e=>ok(await sb.from('events').insert({title:e.title,starts_at:e.starts_at,remind_minutes:e.remind_minutes??10,notes:e.notes||null}).select().single()),
  update:async(id,p)=>ok(await sb.from('events').update(p).eq('id',id).select().single()),
  cancel:async id=>ok(await sb.from('events').update({status:'cancelado'}).eq('id',id).select().single())},
 mem:{
  list:async()=>ok(await sb.from('memories').select('*').order('created_at')),
  add:async(kind,content,source)=>ok(await sb.from('memories').insert({kind,content:String(content).slice(0,1000),source:source||'texto'}).select().single()),
  update:async(id,content)=>ok(await sb.from('memories').update({content}).eq('id',id).select().single()),
  remove:async id=>{ok(await sb.from('memories').delete().eq('id',id).select());return true},
  clear:async()=>{ok(await sb.from('memories').delete().eq('user_id',user.id).select());return true}},
 settings:{
  get:async()=>{const d=ok(await sb.from('user_settings').select('prefs').maybeSingle());return d?d.prefs:{}},
  set:async prefs=>ok(await sb.from('user_settings').upsert({user_id:user.id,prefs}).select().single())},
 push:{
  supported:()=>'serviceWorker'in navigator&&'PushManager'in window&&'Notification'in window,
  async status(){if(!JV.push.supported())return'indisponível neste navegador';const r=await navigator.serviceWorker.getRegistration();const s=r&&await r.pushManager.getSubscription();if(!s)return Notification.permission==='denied'?'bloqueadas no navegador':'desligadas';const d=ok(await sb.from('push_subscriptions').select('id').eq('endpoint',s.endpoint));return d.length?'ativas neste aparelho':'desligadas'},
  async enable(){if(!JV.push.supported())throw Error('Este navegador não aceita notificações push. No iPhone, instale o app na tela inicial primeiro.');if(window.top!==window.self)throw Error('Aqui dentro do Lovable o navegador não deixa ativar notificações. Abra o Jarvis no Chrome (ou o app instalado) e ative por lá.');const BLK='As notificações estão bloqueadas neste aparelho. Para liberar: no Chrome, toque no ícone ao lado do endereço do site › Permissões › Notificações › Permitir. Se o Jarvis está instalado, segure o ícone dele › Informações do app › Notificações › Permitir. Depois toque em Ativar de novo.';if(Notification.permission==='denied')throw Error(BLK);const p=await Notification.requestPermission();if(p==='denied')throw Error(BLK);if(p!=='granted')throw Error('O pedido de permissão foi fechado sem resposta. Toque em Ativar de novo e escolha Permitir.');const reg=await navigator.serviceWorker.ready;const kr=await fetch('/api/public/push-key',{cache:'no-store'});const kj=await kr.json();if(!kr.ok)throw Error(kj.error||'chave indisponível');const k=kj.publicKey.replace(/-/g,'+').replace(/_/g,'/'),raw=atob(k+'='.repeat((4-k.length%4)%4)),key=Uint8Array.from(raw,c=>c.charCodeAt(0));let s=await reg.pushManager.getSubscription();if(s&&s.options&&s.options.applicationServerKey){const a=new Uint8Array(s.options.applicationServerKey);if(a.length!==key.length||a.some((v,i)=>v!==key[i])){await s.unsubscribe();s=null}}s=s||await reg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:key});const j=s.toJSON();ok(await sb.from('push_subscriptions').upsert({user_id:user.id,endpoint:j.endpoint,p256dh:j.keys.p256dh,auth:j.keys.auth},{onConflict:'endpoint'}).select());return true},
  async disable(){const r=await navigator.serviceWorker.getRegistration();const s=r&&await r.pushManager.getSubscription();if(s){await sb.from('push_subscriptions').delete().eq('endpoint',s.endpoint);await s.unsubscribe()}return true},
  async test(){const r=await JV.api('/api/public/push-test',{});const j=await r.json();if(!r.ok)throw Error(j.error||r.status);return j}}
};
window.JV=JV;
})();
