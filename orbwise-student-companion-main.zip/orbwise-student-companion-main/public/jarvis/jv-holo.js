/* Mesa Holográfica Interativa: abrir foto (galeria, busca ou voz), mover, zoom, giro e inclinação 3D,
   corte a mão livre, arrastar para a lixeira, remover fundo, raio-X, desfazer, salvar e baixar. */
(function(){
'use strict';
const X=window.JVX;if(!X)return;const {q,qa,ce,LSg,LSs}=X;
const body=X.sheet('sHo','MESA HOLOGRÁFICA','nHo','◈','Holo');
body.innerHTML=`<div class="jxrow"><label class="x" style="cursor:pointer">📁 Galeria<input type="file" accept="image/*" id="hoFile" hidden></label>
<form id="hoSF" class="jxrow grow" style="flex:1"><input class="t grow" id="hoQ" placeholder="Buscar imagem: Mark 42, árvore…" autocomplete="off"><button class="x">🔎 Buscar</button></form></div>
<div class="jxthumbs" id="hoThumbs"></div>
<div class="jxrow" style="margin:4px 0 8px"><button class="x" type="button" id="hoCut" aria-pressed="false">✂ Cortar</button><button class="x" type="button" id="hoBg">🪄 Remover fundo</button><button class="x" type="button" id="ho3d" aria-pressed="false">◇ 3D</button><button class="x" type="button" id="hoXr" aria-pressed="false">☢ Raio-X</button><button class="x" type="button" id="hoUndo">↶ Desfazer</button><button class="x" type="button" id="hoFit">⌖ Centralizar</button><button class="x" type="button" id="hoSave">💾 Salvar</button><button class="x" type="button" id="hoExp">⬇ Baixar</button><button class="x" type="button" id="hoClr">✕ Limpar</button></div>
<div id="hoStage"><div id="hoGrid"></div><div id="hoPlane" class="empty"><canvas id="hoBase"></canvas></div><canvas id="hoLasso"></canvas><div id="hoTrash">🗑<small>LIXEIRA</small></div><div id="hoMode">MOVER</div><div id="hoHint">Abra uma foto da galeria ou busque uma imagem para projetar na mesa.</div><div id="hoScan"></div></div>
<div class="hint" id="hoInfo" style="margin-top:6px">Um dedo move · dois dedos dão zoom e giram · ✂ Cortar: contorne com o dedo o que não quer e arraste a parte para a lixeira.</div>
<h2>Projetos salvos</h2><div class="jxthumbs" id="hoSaved"></div>`;
const stg=q('#hoStage'),pl=q('#hoPlane'),base=q('#hoBase'),bx=base.getContext('2d',{willReadFrequently:true}),la=q('#hoLasso'),lx=la.getContext('2d'),trash=q('#hoTrash'),hint=q('#hoHint'),modeT=q('#hoMode');
let V={x:0,y:0,s:1,r:0,tilt:0},W=0,H=0,cutOn=false,pieces=[],undo=[],name='',busyL=false;
const apply=()=>{pl.style.width=W+'px';pl.style.height=H+'px';pl.style.transform=`translate(-50%,-50%) translate(${V.x}px,${V.y}px) rotateX(${V.tilt}deg) rotate(${V.r}deg) scale(${V.s})`;persist()};
let needFit=false,pT=0,restoring=false;
const fit=()=>{if(!W)return;const r=stg.getBoundingClientRect();if(r.width<60||r.height<60){needFit=true;return}needFit=false;V.s=Math.min((r.width-30)/W,(r.height-30)/H,2);V.x=V.y=0;V.r=0;apply()};
const msg=t=>{try{toast(t)}catch{}};
const setCut=on=>{cutOn=on;const b=q('#hoCut');b.setAttribute('aria-pressed',String(on));modeT.textContent=on?'CORTE LIVRE':'MOVER';if(on&&V.tilt){V.tilt=0;q('#ho3d').setAttribute('aria-pressed','false');apply()}};

/* ---------- carregar ---------- */
async function loadBlob(blob,nm,auto,quiet){const bmp=await createImageBitmap(blob);const k=Math.min(1,1100/Math.max(bmp.width,bmp.height));W=Math.max(1,Math.round(bmp.width*k));H=Math.max(1,Math.round(bmp.height*k));base.width=W;base.height=H;bx.clearRect(0,0,W,H);bx.drawImage(bmp,0,0,W,H);
 qa('.hoPc',pl).forEach(e=>e.remove());pieces=[];undo=[];name=nm||'imagem';pl.classList.remove('empty');hint.hidden=true;setCut(false);fit();const sc=q('#hoScan');sc.classList.remove('on');void sc.offsetWidth;sc.classList.add('on');if(!quiet)X.sfx('boot');
 let bg=false;if(auto)bg=removeBg(true);persist();return{bg}}
async function loadUrl(u,nm,auto){if(!navigator.onLine)throw Error('estou sem internet agora');const r=await JV.api('/api/public/img',{url:u});if(!r.ok){let j={};try{j=await r.json()}catch{}throw Error(j.error||('HTTP '+r.status))}return loadBlob(await r.blob(),nm,auto)}
X.holoBlob=(b,nm)=>{X.open('sHo');return loadBlob(b,nm)};
X.holoUrl=(u,nm)=>{X.open('sHo');return loadUrl(u,nm).catch(e=>msg('Não consegui projetar essa imagem: '+e.message))};
async function search(qq,auto){const th=q('#hoThumbs');th.innerHTML='<span class="hint">Procurando imagens…</span>';const r=await JV.api('/api/public/search',{q:qq,kind:'images'}),j=await r.json().catch(()=>({}));if(!r.ok)throw Error(j.error||('HTTP '+r.status));const L=(j.images||[]).slice(0,8);th.innerHTML='';
 L.forEach((x,i)=>{const b=ce('button');b.type='button';b.title=x.title||'';const g=new Image();g.src=x.img;g.alt=x.title||'Imagem '+(i+1);g.referrerPolicy='no-referrer';g.loading='lazy';b.append(g);b.onclick=async()=>{qa('button',th).forEach(y=>y.classList.remove('on'));b.classList.add('on');try{await tryLoad(x,qq,false)}catch(e){msg('Essa imagem não abriu: '+e.message)}};th.append(b)});
 if(!L.length)throw Error('nenhuma imagem encontrada');let ok=null,err=null;for(let i=0;i<Math.min(3,L.length)&&!ok;i++){try{ok=await tryLoad(L[i],qq,auto);qa('button',th)[i].classList.add('on');ok.src=L[i]}catch(e){err=e}}if(!ok)throw err||Error('as imagens não abriram');return ok}
async function tryLoad(x,qq,auto){try{return await loadUrl(x.full||x.img,qq,auto)}catch(e){if(x.img&&x.img!==x.full)return loadUrl(x.img,qq,auto);throw e}}
q('#hoFile').onchange=e=>{const f=e.target.files[0];if(f)loadBlob(f,f.name.replace(/\.\w+$/,'')).catch(er=>msg('Não consegui abrir a foto: '+er.message));e.target.value=''};
q('#hoSF').onsubmit=e=>{e.preventDefault();const v=q('#hoQ').value.trim();if(!v)return;search(v,true).then(o=>msg(o.bg?'Projetado. Removi o fundo; se cortou demais, toque em Desfazer.':'Projetado na mesa.')).catch(er=>{q('#hoThumbs').innerHTML='';msg('Busca falhou: '+er.message)})};

/* ---------- coordenadas ---------- */
const toLocal=(cx,cy)=>{const r=stg.getBoundingClientRect(),dx=cx-(r.left+r.width/2+V.x),dy=cy-(r.top+r.height/2+V.y),a=-V.r*Math.PI/180,c=Math.cos(a),s=Math.sin(a);return[(dx*c-dy*s)/V.s+W/2,(dx*s+dy*c)/V.s/Math.max(.2,Math.cos(V.tilt*Math.PI/180))+H/2]};
const toLocalD=(dx,dy)=>{const a=-V.r*Math.PI/180,c=Math.cos(a),s=Math.sin(a);return[(dx*c-dy*s)/V.s,(dx*s+dy*c)/V.s/Math.max(.2,Math.cos(V.tilt*Math.PI/180))]};
const overTrash=(x,y)=>{const r=trash.getBoundingClientRect();return x>r.left-14&&x<r.right+14&&y>r.top-14&&y<r.bottom+14};

/* ---------- gestos da mesa ---------- */
const P=new Map();let g0=null,lasso=null;
const sizeLa=()=>{const r=stg.getBoundingClientRect(),d=Math.min(devicePixelRatio||1,2);la.width=r.width*d;la.height=r.height*d;lx.setTransform(d,0,0,d,0,0)};
stg.addEventListener('pointerdown',e=>{if(e.target.closest('.hoPc')||!W)return;stg.setPointerCapture(e.pointerId);P.set(e.pointerId,{x:e.clientX,y:e.clientY});
 if(cutOn&&P.size===1){sizeLa();const r=stg.getBoundingClientRect();lasso=[[e.clientX,e.clientY]];lx.clearRect(0,0,r.width,r.height);return}
 lasso=null;lx.clearRect(0,0,la.width,la.height);g0=snap()});
stg.addEventListener('pointermove',e=>{const p=P.get(e.pointerId);if(!p)return;p.x=e.clientX;p.y=e.clientY;
 if(lasso&&P.size===1){lasso.push([e.clientX,e.clientY]);drawLasso();return}
 if(!g0)return;const s=snap();if(P.size===1&&g0.n===1){V.x=g0.V.x+(s.cx-g0.cx);V.y=g0.V.y+(s.cy-g0.cy)}else if(P.size>=2&&g0.n>=2){V.s=Math.max(.1,Math.min(8,g0.V.s*s.d/g0.d));V.r=g0.V.r+(s.a-g0.a)*180/Math.PI;V.x=g0.V.x+(s.cx-g0.cx);V.y=g0.V.y+(s.cy-g0.cy)}else g0=s;apply()});
const end=e=>{if(!P.has(e.pointerId))return;P.delete(e.pointerId);if(lasso&&!P.size){const L=lasso;lasso=null;finishLasso(L)}g0=P.size?snap():null};
stg.addEventListener('pointerup',end);stg.addEventListener('pointercancel',end);
stg.addEventListener('wheel',e=>{if(!W)return;e.preventDefault();V.s=Math.max(.1,Math.min(8,V.s*(e.deltaY<0?1.1:.9)));apply()},{passive:false});
function snap(){const a=[...P.values()],n=a.length,cx=a.reduce((s,p)=>s+p.x,0)/n,cy=a.reduce((s,p)=>s+p.y,0)/n,o={n,cx,cy,V:{...V},d:1,a:0};if(n>=2){o.d=Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y)||1;o.a=Math.atan2(a[1].y-a[0].y,a[1].x-a[0].x)}return o}
function drawLasso(){const r=stg.getBoundingClientRect();lx.clearRect(0,0,r.width,r.height);if(!lasso||lasso.length<2)return;lx.save();lx.strokeStyle=X.color||'#a6ecff';lx.shadowColor=lx.strokeStyle;lx.shadowBlur=10;lx.lineWidth=2.5;lx.setLineDash([8,6]);lx.lineDashOffset=-Date.now()/40;lx.beginPath();lasso.forEach(([x,y],i)=>lx[i?'lineTo':'moveTo'](x-r.left,y-r.top));lx.closePath();lx.stroke();lx.fillStyle='rgba('+(X.rgb||'166,236,255')+',.12)';lx.fill();lx.restore()}

/* ---------- corte ---------- */
function finishLasso(L){const r=stg.getBoundingClientRect();lx.clearRect(0,0,r.width,r.height);if(L.length<6)return;const pts=L.map(([x,y])=>toLocal(x,y));let x0=Infinity,y0=Infinity,x1=-Infinity,y1=-Infinity;pts.forEach(([x,y])=>{x0=Math.min(x0,x);y0=Math.min(y0,y);x1=Math.max(x1,x);y1=Math.max(y1,y)});
 x0=Math.max(0,Math.floor(x0));y0=Math.max(0,Math.floor(y0));x1=Math.min(W,Math.ceil(x1));y1=Math.min(H,Math.ceil(y1));const w=x1-x0,h=y1-y0;if(w<4||h<4){msg('O contorno ficou fora da imagem.');return}
 const pc=ce('canvas','hoPc sel');pc.width=w;pc.height=h;const px=pc.getContext('2d',{willReadFrequently:true});px.beginPath();pts.forEach(([x,y],i)=>px[i?'lineTo':'moveTo'](x-x0,y-y0));px.closePath();px.clip();px.drawImage(base,-x0,-y0);
 const d=px.getImageData(0,0,w,h).data;let any=0;for(let i=3;i<d.length;i+=16)if(d[i]>10){any=1;break}if(!any){msg('Nada para cortar aí: essa área já está vazia.');return}
 undo.push({t:'cut',img:bx.getImageData(0,0,W,H),pc});if(undo.length>8)undo.shift();
 bx.save();bx.globalCompositeOperation='destination-out';bx.beginPath();pts.forEach(([x,y],i)=>bx[i?'lineTo':'moveTo'](x,y));bx.closePath();bx.fill();bx.restore();
 const o={el:pc,x:x0,y:y0};addPiece(o);persist();X.sfx('laser');msg('Parte recortada. Arraste para a lixeira para descartar.')}
function addPiece(o){o.el.style.left=o.x+'px';o.el.style.top=o.y+'px';o.el.style.width=o.el.width+'px';o.el.style.height=o.el.height+'px';pl.append(o.el);pieces.push(o);pieceDrag(o)}
function pieceDrag(o){const el=o.el;let st=null;
 el.onpointerdown=e=>{e.stopPropagation();el.setPointerCapture(e.pointerId);st={cx:e.clientX,cy:e.clientY,x:o.x,y:o.y};el.classList.add('drag');qa('.hoPc',pl).forEach(p=>p.classList.toggle('sel',p===el))};
 el.onpointermove=e=>{if(!st)return;const[dx,dy]=toLocalD(e.clientX-st.cx,e.clientY-st.cy);o.x=st.x+dx;o.y=st.y+dy;el.style.left=o.x+'px';el.style.top=o.y+'px';trash.classList.toggle('hot',overTrash(e.clientX,e.clientY))};
 el.onpointerup=el.onpointercancel=e=>{if(!st)return;st=null;el.classList.remove('drag');const hot=overTrash(e.clientX,e.clientY);trash.classList.remove('hot');if(hot)discard(o);persist()}}
function discard(o){if(!o||!pieces.includes(o))return false;burst(o.el);o.el.remove();pieces=pieces.filter(p=>p!==o);undo.push({t:'trash',o});X.sfx('trash');persist();return true}
X.holoDiscard=()=>{const o=pieces.find(p=>p.el.classList.contains('sel'))||pieces[pieces.length-1];if(!o)return'Não há nenhuma seleção na mesa, senhor. Use ✂ Cortar e contorne a parte.';discard(o);return'Seleção desintegrada e enviada para a lixeira.'};

/* ---------- desintegração ---------- */
let fx=null,fxx=null,parts=[],fxOn=false;
function burst(el){if(!fx){fx=ce('canvas');fx.id='jxFx';document.body.append(fx);fxx=fx.getContext('2d')}fx.width=innerWidth;fx.height=innerHeight;const r=el.getBoundingClientRect(),tr=trash.getBoundingClientRect(),w=el.width,h=el.height;let d;try{d=el.getContext('2d').getImageData(0,0,w,h).data}catch{return}const step=Math.max(3,Math.round(Math.sqrt(w*h/1400)));
 for(let y=0;y<h;y+=step)for(let x=0;x<w;x+=step){const i=(y*w+x)*4;if(d[i+3]<40)continue;const sx=r.left+x/w*r.width,sy=r.top+y/h*r.height;parts.push({x:sx,y:sy,vx:(Math.random()-.5)*4,vy:(Math.random()-.5)*4-1,tx:tr.left+tr.width/2,ty:tr.top+tr.height/2,c:`rgba(${d[i]},${d[i+1]},${d[i+2]},`,l:1,s:Math.max(1.5,step*r.width/w*.9),dl:Math.random()*12})}
 if(!fxOn){fxOn=true;requestAnimationFrame(fxLoop)}}
function fxLoop(){fxx.clearRect(0,0,fx.width,fx.height);parts=parts.filter(p=>p.l>0);parts.forEach(p=>{if(p.dl>0){p.dl--}else{p.vx+=(p.tx-p.x)*.012;p.vy+=(p.ty-p.y)*.012;p.vx*=.9;p.vy*=.9;p.x+=p.vx;p.y+=p.vy;p.l-=.022}fxx.fillStyle=p.c+Math.max(0,p.l)+')';fxx.fillRect(p.x,p.y,p.s,p.s)});if(parts.length)requestAnimationFrame(fxLoop);else{fxOn=false;fxx.clearRect(0,0,fx.width,fx.height)}}

/* ---------- remover fundo (cores parecidas a partir das bordas) ---------- */
function removeBg(auto){if(!W)return false;const im=bx.getImageData(0,0,W,H),d=im.data,N=W*H,B=[];
 const push=i=>{if(d[i*4+3]>20)B.push(i)};for(let x=0;x<W;x+=2){push(x);push((H-1)*W+x)}for(let y=0;y<H;y+=2){push(y*W);push(y*W+W-1)}if(B.length<20)return false;
 const ch=k=>B.map(i=>d[i*4+k]).sort((a,b)=>a-b)[B.length>>1],m=[ch(0),ch(1),ch(2)],dist=(i,c)=>Math.abs(d[i]-c[0])+Math.abs(d[i+1]-c[1])+Math.abs(d[i+2]-c[2]);
 const near=B.filter(i=>dist(i*4,m)<70).length/B.length;if(auto&&near<.6)return false;
 undo.push({t:'bg',img:bx.getImageData(0,0,W,H)});if(undo.length>8)undo.shift();
 const seen=new Uint8Array(N),Q=new Int32Array(N);let h=0,t=0;for(let x=0;x<W;x++){[x,(H-1)*W+x].forEach(i=>{if(!seen[i]&&d[i*4+3]>20&&dist(i*4,m)<70){seen[i]=1;Q[t++]=i}})}for(let y=0;y<H;y++){[y*W,y*W+W-1].forEach(i=>{if(!seen[i]&&d[i*4+3]>20&&dist(i*4,m)<70){seen[i]=1;Q[t++]=i}})}
 while(h<t){const i=Q[h++],x=i%W,y=(i/W)|0,p=i*4;const nb=[x>0?i-1:-1,x<W-1?i+1:-1,y>0?i-W:-1,y<H-1?i+W:-1];for(const j of nb){if(j<0||seen[j])continue;const q4=j*4;if(d[q4+3]<=20){seen[j]=1;continue}const loc=Math.abs(d[q4]-d[p])+Math.abs(d[q4+1]-d[p+1])+Math.abs(d[q4+2]-d[p+2]);if(loc<30&&dist(q4,m)<130){seen[j]=1;Q[t++]=j}}}
 let removed=0;for(let i=0;i<N;i++)if(seen[i]){d[i*4+3]=0;removed++}
 for(let y=1;y<H-1;y++)for(let x=1;x<W-1;x++){const i=y*W+x;if(seen[i])continue;if(seen[i-1]||seen[i+1]||seen[i-W]||seen[i+W])d[i*4+3]=Math.round(d[i*4+3]*.55)}
 if(removed<N*.02){undo.pop();return false}bx.putImageData(im,0,0);X.sfx('laser');persist();return true}

/* ---------- botões ---------- */
q('#hoCut').onclick=()=>{if(!W)return msg('Abra uma imagem primeiro.');setCut(!cutOn);msg(cutOn?'Corte livre: contorne com o dedo o que quer separar.':'Modo mover.')};
q('#hoBg').onclick=()=>{if(!W)return msg('Abra uma imagem primeiro.');msg(removeBg(false)?'Fundo removido. Se cortou demais, toque em Desfazer.':'Não achei um fundo liso para remover. Use ✂ Cortar e descarte as partes na lixeira.')};
q('#ho3d').onclick=e=>{V.tilt=V.tilt?0:52;e.currentTarget.setAttribute('aria-pressed',String(!!V.tilt));if(V.tilt&&cutOn)setCut(false);apply()};
q('#hoXr').onclick=e=>{const on=pl.classList.toggle('xr');e.currentTarget.setAttribute('aria-pressed',String(on));persist()};
q('#hoUndo').onclick=()=>{const u=undo.pop();if(!u)return msg('Nada para desfazer.');if(u.t==='cut'){bx.putImageData(u.img,0,0);const o=pieces.find(p=>p.el===u.pc);if(o){o.el.remove();pieces=pieces.filter(p=>p!==o)}}else if(u.t==='bg')bx.putImageData(u.img,0,0);else if(u.t==='trash'){pl.append(u.o.el);pieces.push(u.o)}X.sfx('ok');persist()};
q('#hoFit').onclick=fit;
q('#hoClr').onclick=()=>{W=H=0;pieces=[];undo=[];qa('.hoPc',pl).forEach(e=>e.remove());pl.classList.add('empty');hint.hidden=false;q('#hoThumbs').innerHTML='';persist()};
function compose(max){const k=Math.min(1,(max||4000)/Math.max(W,H)),c=ce('canvas');c.width=Math.round(W*k);c.height=Math.round(H*k);const x=c.getContext('2d');x.scale(k,k);x.drawImage(base,0,0);pieces.forEach(p=>x.drawImage(p.el,p.x,p.y));return c}
const safe=s=>(s||'holograma').toLowerCase().normalize('NFD').replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,40)||'holograma';
q('#hoExp').onclick=()=>{if(!W)return msg('A mesa está vazia.');compose().toBlob(b=>{const a=ce('a');a.href=URL.createObjectURL(b);a.download='holograma-'+safe(name)+'.png';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),4000);msg('Imagem baixada.')},'image/png')};
q('#hoSave').onclick=()=>{if(!W)return msg('A mesa está vazia.');const L=LSg('jv_holo',[]),img=compose(900).toDataURL('image/webp',.85);L.unshift({t:Date.now(),n:name,img});let k=L.length;while(k>0&&!LSs('jv_holo',L.slice(0,k)))k--;rSaved();msg(k?'Projeto salvo neste aparelho.':'Sem espaço para salvar. Apague projetos antigos.')};
function rSaved(){const el=q('#hoSaved'),L=LSg('jv_holo',[]);el.innerHTML=L.length?'':'<span class="hint">Nenhum projeto salvo ainda.</span>';L.forEach((p,i)=>{const b=ce('button');b.type='button';b.title=p.n+' · '+new Date(p.t).toLocaleString('pt-BR');const g=new Image();g.src=p.img;g.alt=p.n;const x=ce('span','del','✕');x.setAttribute('role','button');x.setAttribute('aria-label','Apagar projeto');b.append(g,x);b.onclick=async e=>{if(e.target===x){const M=LSg('jv_holo',[]);M.splice(i,1);LSs('jv_holo',M);rSaved();return}loadBlob(await (await fetch(p.img)).blob(),p.n)};el.append(b)})}
rSaved();
q('#sHo').addEventListener('jx-open',()=>setTimeout(()=>{if(W&&(needFit||V.s<=0))fit()},60));

/* ---------- a bancada fica guardada: recarregar ou trocar de aba não perde nada ---------- */
const toBlob=c=>new Promise(r=>c.toBlob(r,'image/png'));
function persist(){if(restoring||!X.idb)return;clearTimeout(pT);pT=setTimeout(async()=>{try{if(!W){await X.idb.del('holo_cur');return}const pcs=[];for(const p of pieces)pcs.push({x:p.x,y:p.y,b:await toBlob(p.el),sel:p.el.classList.contains('sel')});await X.idb.set('holo_cur',{n:name,V:{...V},xr:pl.classList.contains('xr'),base:await toBlob(base),pcs,t:Date.now()})}catch(e){console.warn('holo: não salvou',e)}},800)}
(async()=>{let s=null;try{s=await X.idb.get('holo_cur')}catch{}if(!s||!s.base)return;restoring=true;try{await loadBlob(s.base,s.n,false,true);
 for(const p of s.pcs||[]){const bm=await createImageBitmap(p.b),c=ce('canvas','hoPc');c.width=bm.width;c.height=bm.height;c.getContext('2d',{willReadFrequently:true}).drawImage(bm,0,0);if(p.sel)c.classList.add('sel');addPiece({el:c,x:p.x,y:p.y})}
 if(s.xr){pl.classList.add('xr');q('#hoXr').setAttribute('aria-pressed','true')}
 if(s.V&&s.V.s>0){Object.assign(V,s.V);needFit=false}if(V.tilt)q('#ho3d').setAttribute('aria-pressed','true');restoring=false;apply()}catch(e){console.warn('holo: não restaurou',e)}finally{restoring=false}})();

/* ---------- voz ---------- */
const open=()=>q('#sHo').classList.contains('show');
X.addCmd((s,n)=>{let m;
 if(/^(?:abr\w*|mostr\w*|ir para|ativ\w*|lig\w*)\s+(?:a |o )?(?:mesa holografica|holograma|mesa|bancada)$/.test(n)){X.open('sHo');return'Mesa holográfica pronta, senhor.'}
 const pick=it=>{it=it.trim().replace(/[.!?]+$/,'');const k=X.nz(it);let m2;if(m2=k.match(/^(?:a |o )?(?:armadura )?mark (\d{1,2})$/))return'Iron Man Mark '+m2[1]+' armor';if(/^(?:a |o )?armadura(?: do homem de ferro| do iron man| do tony stark)?$/.test(k))return'Iron Man armor';return it};
 if((m=s.match(/^(?:me\s+)?(?:abr\w*|abre|projet\w*|coloc\w*|carreg\w*|jog\w*|bot\w*|p[oõ]e|ponha|mostr\w*|traz|traga|exib\w*|quero ver)\s+(?:a |uma |o |um )?(?:imagem|foto|figura|holograma|modelo)\s+(?:da |do |de |das |dos |d[eo]\s)?(.+?)(?:\s+(?:no holograma|na mesa(?: holográfica| holografica)?|na bancada))?[.!?]*$/i))||(m=s.match(/^(?:me\s+)?(?:quero ver|mostr\w*|projet\w*|bot\w*|coloc\w*|p[oõ]e)\s+(?:a |o )?((?:armadura\b.*)|(?:mark \d{1,2}))[.!?]*$/i))||(m=s.match(/^(?:projet\w*|bot\w*|coloc\w*|p[oõ]e|jog\w*)\s+(?:a |o |uma |um )?(.+?)\s+(?:no holograma|na mesa(?: holográfica| holografica)?|na bancada)[.!?]*$/i))){const said=m[1].trim(),it=pick(said);if(/^\d+$/.test(said)||said.length<2)return null;X.open('sHo');q('#hoQ').value=said;
  return search(it,true).then(o=>'Projetado na mesa: '+said+'.'+(o.bg?' Removi o fundo para isolar o item.':'')+' Toque em ✂ Cortar, contorne o que não quiser e arraste para a lixeira.').catch(e=>'Não consegui projetar "'+said+'": '+e.message+'.')}
 if(!open())return null;
 if(/^(descart\w*|jog\w* (?:no |na |pro |para o )?(?:lixo|lixeira)|apag\w* (?:a |essa |esta )?selecao|desintegr\w*)/.test(n))return X.holoDiscard();
 if(/^(desfaz\w*|volt\w* atras)/.test(n)){q('#hoUndo').click();return'Desfeito.'}
 if(/(remov\w*|tir\w*|apag\w*) (?:o )?fundo/.test(n))return removeBg(false)?'Fundo removido, senhor.':'Não achei um fundo liso para remover. Contorne com o dedo e descarte na lixeira.';
 if(/^(?:modo )?corte|^cortar|^recort/.test(n)){setCut(true);return'Corte livre ativado. Contorne com o dedo.'}
 if(/raio ?x/.test(n)){q('#hoXr').click();return'Visão raio-X '+(pl.classList.contains('xr')?'ligada.':'desligada.')}
 if(/^(ampli\w*|aproxim\w*|zoom|aument\w*)/.test(n)){V.s=Math.min(8,V.s*1.5);apply();return'Ampliado.'}
 if(/^(diminu\w*|afast\w*|reduz\w*)/.test(n)){V.s=Math.max(.1,V.s/1.5);apply();return'Reduzido.'}
 if(/^gir\w*/.test(n)){V.r+=/esquerda/.test(n)?-45:45;apply();return'Girado 45 graus.'}
 if(/^(centraliz\w*|resetar|reset)/.test(n)){fit();return'Centralizado.'}
 if(/^(salv\w*)/.test(n)){q('#hoSave').click();return'Salvando o projeto neste aparelho.'}
 if(/^(baix\w*|export\w*)/.test(n)){q('#hoExp').click();return'Baixando a imagem.'}
 if(m=n.match(/^(isol\w*|selecion\w*|separ\w*)\s+(.+)/))return'Ainda não reconheço partes da imagem pelo nome, senhor. Toque em ✂ Cortar e contorne "'+m[2]+'" com o dedo que eu separo na hora.';
 return null});
})();
