/* Banco único de protocolos: lido pela aba Protocolos e pelo J.A.R.V.I.S.
   status: 'ativo' = executa; 'requer' = depende de algo configurado (campo requer); 'indisponivel' = registrado, mas não executável.
   confirmar: pede "sim" antes de executar. */
window.JV_PROTOCOLOS=[
 {id:'casa-limpa',nome:'Casa Limpa',aliases:['casa limpa','clean slate','limpeza'],desc:'Apaga os registros da conversa desta sessão (a memória fica)',status:'ativo',confirmar:true},
 {id:'festa',nome:'Festa',aliases:['festa','house party'],desc:'Toca uma playlist de festa no Spotify',status:'requer',requer:'spotify'},
 {id:'combate',nome:'Modo de combate',aliases:['combate','modo de combate','defesa','batalha'],desc:'Interface em alerta vermelho por 8 segundos',status:'ativo'},
 {id:'furtivo',nome:'Modo furtivo',aliases:['furtivo','modo furtivo','silencio','silencioso','stealth'],desc:'Silencia o celular pela automação (MacroDroid/Tasker)',status:'requer',requer:'automacao'},
 {id:'foco',nome:'Foco total',aliases:['foco total','concentracao'],desc:'Pomodoro de 25 minutos e pausa a música',status:'ativo'},
 {id:'bom-dia',nome:'Bom dia',aliases:['bom dia','despertar','briefing'],desc:'Hora, clima, compromissos e tarefas do dia',status:'ativo'},
 {id:'diagnostico',nome:'Diagnóstico',aliases:['diagnostico','diagnostico completo','status'],desc:'Abre o relatório dos sistemas do aparelho',status:'ativo'},
 {id:'repouso',nome:'Modo repouso',aliases:['repouso','modo repouso','dormir'],desc:'Desliga a escuta por voz e as conversas proativas',status:'ativo'},
 {id:'veronica',nome:'Veronica',aliases:['veronica','hulkbuster'],desc:'Armadura Hulkbuster em órbita',status:'indisponivel',motivo:'exige um satélite que o senhor, por enquanto, não possui'},
 {id:'mark-42',nome:'Mark 42',aliases:['mark 42','armadura','armaduras'],desc:'Chamar a armadura remotamente',status:'indisponivel',motivo:'não há armadura conectada a este aparelho'}
];
window.JV_norm=s=>String(s||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[?!.,]/g,' ').replace(/\s+/g,' ').trim();
window.JV_findProto=q=>{const n=JV_norm(q).replace(/^(o |a |do |da )/,'');return JV_PROTOCOLOS.find(p=>p.aliases.some(a=>n===a||n.startsWith(a+' ')||n.endsWith(' '+a)))||null};
