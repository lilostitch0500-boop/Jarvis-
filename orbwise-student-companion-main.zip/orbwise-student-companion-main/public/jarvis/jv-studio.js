/* Estúdio Stark: quadro laser (desenho livre, formas, borracha, desenho feito pelo Jarvis),
   slides (gerados pelo Jarvis ou à mão, apresentação, vídeo e arquivo para baixar),
   fotos (filtros, legenda, criação por IA) e diário de bordo. */
(function(){
'use strict';
const X=window.JVX;if(!X||!X.labPaneEl)return;const {q,qa,ce,LSg,LSs}=X,esc=X.esc,safe=X.safe;
const msg=t=>{try{toast(t)}catch{}};
const P=X.labPaneEl('studio');
P.innerHTML=`<div class="jxtabs stT"><button type="button" data-s="qd" class="on">✎ QUADRO</button><button type="button" data-s="sl">▣ SLIDES E VÍDEO</button><button type="button" data-s="ft">◐ FOTOS</button><button type="button" data-s="db">☰ DIÁRIO</button></div>
<section class="stSec" data-s="qd">
<div class="jxrow"><div class="qdCols" id="qdCols"></div><select id="qdW" aria-label="Espessura"><option value="3">Fino</option><option value="6" selected>Médio</option><option value="12">Grosso</option><option value="22">Marcador</option></select></div>
<div class="jxrow qdTools" style="margin:6px 0"><button class="x" type="button" data-tool="free" aria-pressed="true">✎ Livre</button><button class="x" type="button" data-tool="line" aria-pressed="false">╱ Linha</button><button class="x" type="button" data-tool="rect" aria-pressed="false">▢ Retângulo</button><button class="x" type="button" data-tool="circ" aria-pressed="false">◯ Círculo</button><button class="x" type="button" data-tool="er" aria-pressed="false">⌫ Borracha</button><button class="x" type="button" id="qdUndo">↶ Desfazer</button><button class="x" type="button" id="qdClr">✕ Limpar</button></div>
<canvas id="qd" aria-label="Quadro de desenho laser"></canvas>
<form id="qdAiF" class="jxrow" style="margin-top:8px"><input class="t grow" id="qdAi" placeholder="Peça um desenho ao Jarvis: armadura Mark 42, planta de uma casa…" autocomplete="off"><button class="x">✨ Desenhar</button></form>
<div class="jxrow" style="margin-top:6px"><button class="x" type="button" id="qdSave">💾 Guardar planta</button><button class="x" type="button" id="qdDl">⬇ Baixar PNG</button><button class="x" type="button" id="qdHo">◈ Mandar para a Mesa</button></div>
<h2>Plantas técnicas</h2><div class="jxthumbs" id="qdSaved"></div></section>
<section class="stSec" data-s="sl" hidden>
<div class="jxrow"><input class="t grow" id="slTopic" placeholder="Tema: Sistema Solar, Revolução Industrial…" autocomplete="off"><select id="slN" aria-label="Quantidade de slides"><option>4</option><option selected>6</option><option>8</option><option>10</option></select><button class="x" type="button" id="slGen">✨ Gerar com Jarvis</button></div>
<div class="jxrow" style="margin:6px 0 8px"><input class="t grow" id="slTitle" placeholder="Título da apresentação" autocomplete="off"><button class="x" type="button" id="slAdd">✚ Slide</button><button class="x" type="button" id="slImgs">🖼 Imagens automáticas</button></div>
<div class="jxrow" style="margin-bottom:8px"><button class="x" type="button" id="slPlay">▶ Apresentar</button><button class="x" type="button" id="slVid">🎬 Gerar vídeo</button><button class="x" type="button" id="slHtml">⬇ Baixar apresentação</button><button class="x" type="button" id="slSv">💾 Salvar</button><button class="x" type="button" id="slClr">✕ Limpar</button></div>
<div class="hint" id="slSt" role="status"></div><div id="slList"></div><h2>Apresentações salvas</h2><div id="slSaved"></div></section>
<section class="stSec" data-s="ft" hidden>
<div class="jxrow"><label class="x" style="cursor:pointer">📁 Abrir foto<input type="file" accept="image/*" id="ftFile" hidden></label><label class="x" style="cursor:pointer">📷 Câmera<input type="file" accept="image/*" capture="environment" id="ftCam" hidden></label></div>
<form id="ftAiF" class="jxrow" style="margin:6px 0"><input class="t grow" id="ftAi" placeholder="Criar imagem: Homem de Ferro voando sobre São Paulo à noite" autocomplete="off"><button class="x">✨ Criar com IA</button></form>
<div class="ftWrap"><canvas id="ft" aria-label="Foto em edição"></canvas><div id="ftHint">Abra uma foto, tire uma com a câmera ou peça para o Jarvis criar uma.</div></div>
<div class="jxrow ftFx" id="ftFx"></div>
<div class="ftSl"><label>Brilho <input type="range" id="ftB" min="50" max="150" value="100"></label><label>Contraste <input type="range" id="ftC" min="50" max="160" value="100"></label><label>Cor <input type="range" id="ftS" min="0" max="200" value="100"></label></div>
<div class="jxrow"><input class="t grow" id="ftTx" placeholder="Legenda na foto (opcional)" autocomplete="off"><select id="ftPos" aria-label="Posição da legenda"><option value="b">Embaixo</option><option value="t">Em cima</option><option value="c">Centro</option></select></div>
<div class="jxrow" style="margin-top:6px"><button class="x" type="button" id="ftDl">⬇ Baixar</button><button class="x" type="button" id="ftHo">◈ Mesa Holográfica</button><button class="x" type="button" id="ftQd">✎ Desenhar por cima</button><button class="x" type="button" id="ftRs">↺ Original</button></div></section>
<section class="stSec" data-s="db" hidden>
<form id="dbF" class="jxrow"><input class="t grow" id="dbIn" placeholder="Registrar no diário de bordo…" autocomplete="off"><button class="x">Registrar</button></form>
<div class="hint">Também por voz: "Jarvis, diário: terminei o projeto da feira".</div><div id="dbList" style="margin-top:8px"></div></section>`;
const sec=k=>q('.stSec[data-s="'+k+'"]',P);
const showSec=k=>{qa('.stT button',P).forEach(b=>b.classList.toggle('on',b.dataset.s===k));qa('.stSec',P).forEach(s=>s.hidden=s.dataset.s!==k);if(k==='qd')render();if(k==='db')rDb();if(k==='ft')ftRender()};
X.studio=k=>{X.labPane('studio');showSec(k)};
q('.stT',P).onclick=e=>{const b=e.target.closest('button');if(b)showSec(b.dataset.s)};
P.addEventListener('jx-show',()=>render());

/* =================== QUADRO LASER =================== */
const QW=1600,QH=1000,qd=q('#qd',P),qx=qd.getContext('2d');qd.width=QW;qd.height=QH;
const ink=ce('canvas');ink.width=QW;ink.height=QH;const ix=ink.getContext('2d');
const COLS=['theme','#ffffff','#ff7b7b','#ffe36b','#7cf5a8','#d39bff','#ffb36b'];
let strokes=[],cur=null,col='theme',tool='free';
const cOf=c=>c==='theme'?(X.color||'#a6ecff'):c;
q('#qdCols',P).innerHTML=COLS.map((c,i)=>`<button type="button" data-c="${c}" aria-label="Cor ${i+1}" class="${i?'':'on'}" style="--k:${c==='theme'?'var(--c)':c}"></button>`).join('');
q('#qdCols',P).onclick=e=>{const b=e.target.closest('button');if(!b)return;col=b.dataset.c;qa('#qdCols button',P).forEach(x=>x.classList.toggle('on',x===b));if(tool==='er')setTool('free')};
const setTool=t=>{tool=t;qa('[data-tool]',P).forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.tool===t)))};
qa('[data-tool]',P).forEach(b=>b.onclick=()=>setTool(b.dataset.tool));
function grid(x){x.fillStyle='#020b14';x.fillRect(0,0,QW,QH);const rgb=X.rgb||'166,236,255';x.lineWidth=1;for(let i=0;i<=QW;i+=50){x.strokeStyle=`rgba(${rgb},${i%250?.06:.14})`;x.beginPath();x.moveTo(i+.5,0);x.lineTo(i+.5,QH);x.stroke()}for(let j=0;j<=QH;j+=50){x.strokeStyle=`rgba(${rgb},${j%250?.06:.14})`;x.beginPath();x.moveTo(0,j+.5);x.lineTo(QW,j+.5);x.stroke()}}
function path(x,s){const p=s.pts;x.beginPath();if(s.k==='line'){x.moveTo(p[0][0],p[0][1]);x.lineTo(p[1][0],p[1][1])}else if(s.k==='rect'){x.rect(p[0][0],p[0][1],p[1][0]-p[0][0],p[1][1]-p[0][1])}else if(s.k==='circ'){x.ellipse((p[0][0]+p[1][0])/2,(p[0][1]+p[1][1])/2,Math.abs(p[1][0]-p[0][0])/2,Math.abs(p[1][1]-p[0][1])/2,0,0,Math.PI*2)}else{x.moveTo(p[0][0],p[0][1]);if(p.length<3)x.lineTo(p[0][0]+.1,p[0][1]+.1);for(let i=1;i<p.length-1;i++){const mx=(p[i][0]+p[i+1][0])/2,my=(p[i][1]+p[i+1][1])/2;x.quadraticCurveTo(p[i][0],p[i][1],mx,my)}if(p.length>1)x.lineTo(p[p.length-1][0],p[p.length-1][1])}}
function drawS(x,s){if(s.img){const im=s.img,k=Math.min(QW/im.width,QH/im.height);x.drawImage(im,(QW-im.width*k)/2,(QH-im.height*k)/2,im.width*k,im.height*k);return}
 x.save();x.lineCap=x.lineJoin='round';if(s.k==='er'){x.globalCompositeOperation='destination-out';x.lineWidth=s.w*3;x.strokeStyle='#000';path(x,s);x.stroke()}
 else{x.shadowColor=s.c;x.shadowBlur=s.w*2.5;x.strokeStyle=s.c;x.lineWidth=s.w;path(x,s);x.stroke();x.shadowBlur=0;x.strokeStyle='rgba(255,255,255,.8)';x.lineWidth=Math.max(1,s.w*.3);path(x,s);x.stroke()}x.restore()}
function rebuild(){ix.clearRect(0,0,QW,QH);strokes.forEach(s=>drawS(ix,s));render()}
function render(){grid(qx);qx.drawImage(ink,0,0);if(cur){if(cur.k==='er'){const t=ce('canvas');t.width=QW;t.height=QH;const tx=t.getContext('2d');tx.drawImage(ink,0,0);drawS(tx,cur);grid(qx);qx.drawImage(t,0,0)}else drawS(qx,cur)}}
const pt=e=>{const r=qd.getBoundingClientRect();return[(e.clientX-r.left)/r.width*QW,(e.clientY-r.top)/r.height*QH]};
qd.addEventListener('pointerdown',e=>{qd.setPointerCapture(e.pointerId);const p=pt(e);cur={k:tool,c:cOf(col),w:+q('#qdW',P).value,pts:tool==='free'||tool==='er'?[p]:[p,p]};if(tool!=='er')X.sfx('tick');render()});
qd.addEventListener('pointermove',e=>{if(!cur)return;const p=pt(e);if(cur.k==='free'||cur.k==='er'){const l=cur.pts[cur.pts.length-1];if(Math.hypot(p[0]-l[0],p[1]-l[1])>2)cur.pts.push(p)}else cur.pts[1]=p;render()});
const endS=()=>{if(!cur)return;strokes.push(cur);drawS(ix,cur);cur=null;render()};
qd.addEventListener('pointerup',endS);qd.addEventListener('pointercancel',endS);
q('#qdUndo',P).onclick=()=>{if(!strokes.length)return msg('Nada para desfazer.');strokes.pop();rebuild()};
q('#qdClr',P).onclick=()=>{if(strokes.length&&!confirm('Limpar o quadro?'))return;strokes=[];rebuild()};
const qdBlob=()=>new Promise(r=>qd.toBlob(r,'image/png'));
q('#qdDl',P).onclick=async()=>{render();X.download(await qdBlob(),'planta-'+Date.now()+'.png');msg('Desenho baixado.')};
q('#qdHo',P).onclick=async()=>{render();const b=await qdBlob();if(X.holoBlob)X.holoBlob(b,'planta');else msg('A Mesa Holográfica não está disponível.')};
function rSaved(){const el=q('#qdSaved',P),L=LSg('jv_quadros',[]);el.innerHTML=L.length?'':'<span class="hint">Nenhuma planta guardada ainda.</span>';L.forEach((p,i)=>{const b=ce('button');b.type='button';b.title=new Date(p.t).toLocaleString('pt-BR');const g=new Image();g.src=p.img;g.alt='Planta '+(i+1);const x=ce('span','del','✕');x.setAttribute('role','button');x.setAttribute('aria-label','Apagar planta');b.append(g,x);b.onclick=e=>{if(e.target===x){const M=LSg('jv_quadros',[]);M.splice(i,1);LSs('jv_quadros',M);rSaved();return}const im=new Image();im.onload=()=>{strokes=[{img:im}];rebuild();msg('Planta aberta no quadro.')};im.src=p.img};el.append(b)})}
q('#qdSave',P).onclick=()=>{render();const c=ce('canvas');c.width=960;c.height=600;c.getContext('2d').drawImage(qd,0,0,960,600);const L=LSg('jv_quadros',[]);L.unshift({t:Date.now(),img:c.toDataURL('image/webp',.85)});let k=L.length;while(k>0&&!LSs('jv_quadros',L.slice(0,k)))k--;rSaved();msg(k?'Planta guardada neste aparelho.':'Sem espaço. Apague plantas antigas.');X.sfx('ok')};
X.boardImage=src=>{const im=new Image();im.onload=()=>{strokes.push({img:im});rebuild()};im.src=src};
const clean=svg=>svg.replace(/<script[\s\S]*?<\/script>/gi,'').replace(/<foreignObject[\s\S]*?<\/foreignObject>/gi,'').replace(/\son\w+\s*=\s*("[^"]*"|'[^']*')/gi,'').replace(/(href\s*=\s*["'])(?!#)[^"']*/gi,'$1#');
async function aiDraw(what){if(!what)return;const st=q('#qdAi',P);st.disabled=true;msg('Desenhando "'+what+'", senhor…');const c=cOf(col);
 try{const t=await X.tutorAsk([{role:'user',content:'Desenhe: '+what}],'Você é J.A.R.V.I.S. e desenha em SVG no estilo de planta técnica holográfica. Responda APENAS com um único elemento <svg> válido, com xmlns="http://www.w3.org/2000/svg" e viewBox="0 0 1600 1000", fundo transparente, traços (stroke) na cor '+c+' com stroke-width entre 2 e 6, quase tudo com fill="none" (pode usar preenchimentos com opacity baixa), muitos detalhes reconhecíveis, centralizado. Pode incluir rótulos técnicos curtos em <text> com fill="'+c+'" e font-family="monospace". Sem scripts, sem imagens externas, sem explicação fora do SVG.');
  const m=t.match(/<svg[\s\S]*<\/svg>/i);if(!m)throw Error('a resposta não veio como desenho');let svg=clean(m[0]);if(!/xmlns=/.test(svg))svg=svg.replace(/<svg/i,'<svg xmlns="http://www.w3.org/2000/svg"');
  const u=URL.createObjectURL(new Blob([svg],{type:'image/svg+xml'})),im=new Image();await new Promise((res,rej)=>{im.onload=res;im.onerror=()=>rej(Error('o desenho veio com defeito'));im.src=u});
  const cv=ce('canvas');cv.width=QW;cv.height=QH;cv.getContext('2d').drawImage(im,0,0,QW,QH);URL.revokeObjectURL(u);const fin=new Image();fin.src=cv.toDataURL();await new Promise(r=>fin.onload=r);strokes.push({img:fin});rebuild();X.sfx('laser');msg('Desenho pronto. Pode riscar por cima, senhor.');return'Desenho de '+what+' projetado no quadro, senhor.'}
 catch(e){msg('Não consegui desenhar: '+e.message);return'Não consegui desenhar agora: '+e.message}finally{st.disabled=false}}
q('#qdAiF',P).onsubmit=e=>{e.preventDefault();const v=q('#qdAi',P).value.trim();if(v)aiDraw(v)};
rSaved();
addEventListener('resize',()=>{if(!sec('qd').hidden)render()});

/* =================== SLIDES =================== */
let deck=LSg('jv_deck',{title:'',slides:[]});
const saveDeck=()=>LSs('jv_deck',deck);
const slSt=t=>{q('#slSt',P).textContent=t||''};
q('#slTitle',P).value=deck.title||'';q('#slTitle',P).oninput=e=>{deck.title=e.target.value;saveDeck()};
function rSl(){const el=q('#slList',P);el.innerHTML=deck.slides.length?'':'<div class="hint">Nenhum slide ainda. Digite um tema e toque em ✨ Gerar com Jarvis, ou crie à mão com ✚ Slide.</div>';
 deck.slides.forEach((s,i)=>{const d=ce('div','slRow');d.innerHTML=`<header><span>SLIDE ${String(i+1).padStart(2,'0')}</span><span><button type="button" class="x" data-a="up" aria-label="Subir">↑</button><button type="button" class="x" data-a="dn" aria-label="Descer">↓</button><button type="button" class="x" data-a="im" aria-label="Buscar imagem">🖼</button><button type="button" class="x" data-a="rm" aria-label="Apagar slide">✕</button></span></header><input class="t" value="${esc(s.t||'')}" placeholder="Título do slide"><textarea rows="3" placeholder="Texto (um tópico por linha)">${esc(s.x||'')}</textarea>${s.img?`<div class="slImg"><img src="${esc(s.img)}" alt="" referrerpolicy="no-referrer"><button type="button" class="x" data-a="ni">Tirar imagem</button></div>`:''}`;
  const[ti,tx]=[q('input',d),q('textarea',d)];ti.oninput=()=>{s.t=ti.value;saveDeck()};tx.oninput=()=>{s.x=tx.value;saveDeck()};
  d.onclick=async e=>{const a=e.target.closest('[data-a]')?.dataset.a;if(!a)return;if(a==='up'&&i>0){deck.slides.splice(i-1,0,deck.slides.splice(i,1)[0])}else if(a==='dn'&&i<deck.slides.length-1){deck.slides.splice(i+1,0,deck.slides.splice(i,1)[0])}else if(a==='rm'){deck.slides.splice(i,1)}else if(a==='ni'){delete s.img;delete s.full}else if(a==='im'){e.target.disabled=true;try{await slideImg(s)}catch(er){msg('Imagem não encontrada: '+er.message)}}saveDeck();rSl()};el.append(d)})}
async function slideImg(s){const qq=[deck.title,s.t].filter(Boolean).join(' ').slice(0,120)||'tecnologia';const r=await JV.api('/api/public/search',{q:qq,kind:'images'}),j=await r.json().catch(()=>({}));if(!r.ok)throw Error(j.error||('HTTP '+r.status));const x=(j.images||[])[0];if(!x)throw Error('nenhuma imagem');s.img=x.img;s.full=x.full||x.img;s.src=x.page||x.full||''}
q('#slAdd',P).onclick=()=>{deck.slides.push({t:'',x:''});saveDeck();rSl();const r=q('#slList',P).lastElementChild;r&&q('input',r).focus()};
q('#slClr',P).onclick=()=>{if(deck.slides.length&&!confirm('Apagar todos os slides atuais?'))return;deck={title:'',slides:[]};q('#slTitle',P).value='';saveDeck();rSl()};
q('#slImgs',P).onclick=async()=>{if(!deck.slides.length)return msg('Crie os slides primeiro.');let ok=0;for(let i=0;i<deck.slides.length;i++){const s=deck.slides[i];if(s.img)continue;slSt('Buscando imagem '+(i+1)+' de '+deck.slides.length+'…');try{await slideImg(s);ok++}catch{}}saveDeck();rSl();slSt(ok?'Imagens colocadas em '+ok+' slide(s). As fontes ficam salvas no arquivo baixado.':'Não encontrei imagens novas.')};
async function genSlides(topic,n){topic=String(topic||'').trim();if(!topic)return msg('Digite o tema da apresentação.');q('#slTopic',P).value=topic;slSt('O Jarvis está montando a apresentação sobre "'+topic+'"…');q('#slGen',P).disabled=true;
 try{const t=await X.tutorAsk([{role:'user',content:'Crie uma apresentação de '+n+' slides sobre: '+topic}],'Você é J.A.R.V.I.S. e cria apresentações de slides claras e corretas em português do Brasil. Responda SOMENTE com JSON válido, sem texto fora dele, no formato {"titulo":"título da apresentação","slides":[{"t":"título curto do slide","x":"3 a 4 tópicos curtos, cada um numa linha começando com • "}]}. O primeiro slide é a capa (x com uma frase de subtítulo) e o último é a conclusão. Use informações verdadeiras; se não tiver certeza de um dado, não invente números.');
  const m=t.match(/\{[\s\S]*\}/);if(!m)throw Error('a resposta não veio no formato de slides');const j=JSON.parse(m[0]);const L=(j.slides||[]).filter(s=>s&&(s.t||s.x)).slice(0,14).map(s=>({t:String(s.t||'').slice(0,120),x:String(s.x||'').slice(0,800)}));if(!L.length)throw Error('nenhum slide veio na resposta');
  deck={title:String(j.titulo||topic).slice(0,120),slides:L};q('#slTitle',P).value=deck.title;saveDeck();rSl();slSt(L.length+' slides prontos. Toque em 🖼 Imagens automáticas, ▶ Apresentar ou 🎬 Gerar vídeo.');X.sfx('ok');return'Apresentação "'+deck.title+'" pronta com '+L.length+' slides, senhor.'}
 catch(e){slSt('Não consegui gerar: '+e.message);return'Não consegui gerar os slides agora: '+e.message}finally{q('#slGen',P).disabled=false}}
q('#slGen',P).onclick=()=>genSlides(q('#slTopic',P).value,+q('#slN',P).value);
/* apresentação em tela cheia */
let show=null,si=0;
function present(start){if(!deck.slides.length){msg('Crie os slides primeiro.');return false}if(!show){show=ce('div');show.id='slShow';show.setAttribute('role','dialog');show.setAttribute('aria-label','Apresentação');show.innerHTML='<div class="slC"><h1></h1><img alt="" referrerpolicy="no-referrer" hidden><p></p></div><div class="nav"><button type="button" aria-label="Anterior">‹</button><span></span><button type="button" aria-label="Próximo">›</button><button type="button" aria-label="Fechar apresentação">✕</button></div>';document.body.append(show);const[b1,b2,b3]=qa('.nav button',show);b1.onclick=()=>go(-1);b2.onclick=()=>go(1);b3.onclick=closeShow;let sx=null;show.addEventListener('pointerdown',e=>{if(!e.target.closest('button'))sx=e.clientX});show.addEventListener('pointerup',e=>{if(sx==null)return;const d=e.clientX-sx;sx=null;if(Math.abs(d)>50)go(d<0?1:-1);else if(!e.target.closest('button'))go(1)})}
 si=start||0;show.hidden=false;paintShow();try{show.requestFullscreen?.().catch(()=>{})}catch{}return true}
function paintShow(){const s=deck.slides[si];q('h1',show).textContent=s.t||'';q('p',show).textContent=s.x||'';const im=q('img',show);im.hidden=!s.img;if(s.img)im.src=s.full||s.img;q('.nav span',show).textContent=(si+1)+' / '+deck.slides.length;const c=q('.slC',show);c.classList.remove('in');void c.offsetWidth;c.classList.add('in');X.sfx('click')}
function go(d){if(!show||show.hidden)return;si=Math.max(0,Math.min(deck.slides.length-1,si+d));paintShow()}
function closeShow(){if(show)show.hidden=true;if(document.fullscreenElement)document.exitFullscreen?.().catch(()=>{})}
addEventListener('keydown',e=>{if(!show||show.hidden)return;if(e.key==='ArrowRight'||e.key===' '||e.key==='PageDown'){e.preventDefault();go(1)}else if(e.key==='ArrowLeft'||e.key==='PageUp')go(-1);else if(e.key==='Escape')closeShow()});
q('#slPlay',P).onclick=()=>present(0);
/* vídeo */
async function proxImg(u){const r=await JV.api('/api/public/img',{url:u});if(!r.ok)throw Error('HTTP '+r.status);return createImageBitmap(await r.blob())}
function wrap(x,t,w){const out=[];String(t||'').split('\n').forEach(par=>{const ws=par.split(' ');let l='';ws.forEach(word=>{const tt=l?l+' '+word:word;if(x.measureText(tt).width>w&&l){out.push(l);l=word}else l=tt});out.push(l)});return out}
function drawSlide(x,s,im,k,i,n,title){const W=1280,H=720,rgb=X.rgb||'166,236,255',c=X.color||'#a6ecff';const g=x.createRadialGradient(W*.5,H*.35,50,W*.5,H*.5,W*.75);g.addColorStop(0,`rgba(${rgb},.20)`);g.addColorStop(1,'#020a12');x.fillStyle='#020a12';x.fillRect(0,0,W,H);x.fillStyle=g;x.fillRect(0,0,W,H);
 x.strokeStyle=`rgba(${rgb},.07)`;x.lineWidth=1;for(let a=0;a<W;a+=40){x.beginPath();x.moveTo(a,0);x.lineTo(a,H);x.stroke()}for(let b=0;b<H;b+=40){x.beginPath();x.moveTo(0,b);x.lineTo(W,b);x.stroke()}
 const fade=Math.min(1,k/.12),out=k>.92?Math.max(0,(1-k)/.08):1,al=Math.min(fade,out);x.globalAlpha=al;const hasI=!!im,tw=hasI?620:1080,tx=hasI?70:100;
 if(hasI){const z=1+k*.06,bw=500,bh=440,ix=W-bw-60,iy=(H-bh)/2;x.save();x.beginPath();x.rect(ix,iy,bw,bh);x.clip();const kk=Math.max(bw/im.width,bh/im.height)*z;x.drawImage(im,ix+bw/2-im.width*kk/2,iy+bh/2-im.height*kk/2,im.width*kk,im.height*kk);x.restore();x.strokeStyle=c;x.lineWidth=2;x.shadowColor=c;x.shadowBlur=14;x.strokeRect(ix,iy,bw,bh);x.shadowBlur=0}
 x.fillStyle=c;x.shadowColor=c;x.shadowBlur=18;x.font='700 '+(i===0?56:46)+'px "Space Grotesk",system-ui,sans-serif';const tl=wrap(x,s.t,tw);let y=i===0&&!hasI?H/2-tl.length*30-30:150;tl.slice(0,3).forEach(l=>{x.fillText(l,tx,y+(1-fade)*20);y+=58});x.shadowBlur=0;
 x.fillStyle='#e8f8ff';x.font='400 28px "Space Grotesk",system-ui,sans-serif';y+=22;wrap(x,s.x,tw).slice(0,9).forEach(l=>{x.fillText(l,tx,y);y+=42});
 x.globalAlpha=1;x.fillStyle=`rgba(${rgb},.7)`;x.font='700 16px "JetBrains Mono",monospace';x.fillText('J.A.R.V.I.S. // '+String(title||'').toUpperCase().slice(0,50),40,H-30);x.fillText(String(i+1).padStart(2,'0')+'/'+String(n).padStart(2,'0'),W-110,H-30);x.fillStyle=c;x.fillRect(0,H-4,W*((i+k)/n),4)}
let vidBusy=false;
async function makeVideo(){if(vidBusy)return'O vídeo já está sendo gerado.';if(!deck.slides.length){msg('Crie os slides primeiro.');return'Crie os slides primeiro, senhor.'}if(!window.MediaRecorder||!HTMLCanvasElement.prototype.captureStream){msg('Este navegador não grava vídeo. Use o Chrome.');return'Este navegador não consegue gravar vídeo.'}
 vidBusy=true;const b=q('#slVid',P);b.disabled=true;try{const n=deck.slides.length;slSt('Preparando as imagens…');const imgs=await Promise.all(deck.slides.map(s=>s.img?proxImg(s.full||s.img).catch(()=>proxImg(s.img)).catch(()=>null):null));
  const c=ce('canvas');c.width=1280;c.height=720;const x=c.getContext('2d'),mime=['video/mp4;codecs=avc1','video/mp4','video/webm;codecs=vp9','video/webm;codecs=vp8','video/webm'].find(m=>MediaRecorder.isTypeSupported(m));if(!mime)throw Error('formato de vídeo indisponível');
  const st=c.captureStream(30),rec=new MediaRecorder(st,{mimeType:mime,videoBitsPerSecond:5e6}),ch=[];rec.ondataavailable=e=>{if(e.data&&e.data.size)ch.push(e.data)};const D=4500,T=D*n;drawSlide(x,deck.slides[0],imgs[0],0,0,n,deck.title);rec.start(250);const t0=performance.now();
  await new Promise(res=>{const step=()=>{const t=performance.now()-t0;if(t>=T)return res();const i=Math.min(n-1,Math.floor(t/D));drawSlide(x,deck.slides[i],imgs[i],(t%D)/D,i,n,deck.title);slSt('🎬 Gravando o vídeo… '+Math.round(t/T*100)+'% (mantenha esta tela aberta)');setTimeout(step,33)};step()});
  await new Promise(r=>{rec.onstop=r;rec.stop()});st.getTracks().forEach(t=>t.stop());const ext=mime.includes('mp4')?'mp4':'webm',bl=new Blob(ch,{type:mime.split(';')[0]});X.download(bl,safe(deck.title||'apresentacao')+'.'+ext);slSt('Vídeo pronto ('+Math.round(T/1000)+' s, '+ext.toUpperCase()+') e baixado no aparelho.');X.sfx('ok');return'Vídeo da apresentação gerado e baixado, senhor.'}
 catch(e){slSt('Não consegui gerar o vídeo: '+e.message);return'Não consegui gerar o vídeo: '+e.message}finally{vidBusy=false;b.disabled=false}}
q('#slVid',P).onclick=makeVideo;
q('#slHtml',P).onclick=()=>{if(!deck.slides.length)return msg('Crie os slides primeiro.');const data=JSON.stringify({title:deck.title,c:X.color||'#a6ecff',rgb:X.rgb||'166,236,255',slides:deck.slides.map(s=>({t:s.t,x:s.x,img:s.full||s.img||'',src:s.src||''}))}).replace(/</g,'\\u003c');
 const html=`<!DOCTYPE html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(deck.title||'Apresentação')}</title><style>html,body{margin:0;height:100%;background:#020a12;color:#eef9ff;font-family:system-ui,sans-serif;overflow:hidden}.s{position:absolute;inset:0;display:none;flex-direction:column;justify-content:center;padding:6vh 8vw;background:radial-gradient(ellipse at 50% 30%,rgba(var(--r),.2),#020a12 70%)}.s.on{display:flex;animation:i .5s ease}@keyframes i{from{opacity:0;transform:translateY(12px)}}h1{color:var(--c);font-size:clamp(28px,6vw,64px);margin:0 0 3vh;text-shadow:0 0 24px var(--c)}p{white-space:pre-wrap;font-size:clamp(17px,2.8vw,30px);line-height:1.5;max-width:60ch;margin:0}img{max-height:40vh;max-width:80vw;object-fit:contain;border:2px solid var(--c);border-radius:8px;margin:0 0 3vh;align-self:flex-start}small{position:absolute;bottom:2vh;left:8vw;opacity:.6}nav{position:fixed;bottom:2vh;right:3vw;display:flex;gap:8px}button{width:48px;height:48px;border-radius:10px;border:1px solid var(--c);background:#020a12cc;color:var(--c);font-size:20px}</style></head><body><div id="d"></div><nav><button onclick="g(-1)" aria-label="Anterior">‹</button><button onclick="g(1)" aria-label="Próximo">›</button></nav><script>var D=${data},i=0;document.body.style.setProperty('--c',D.c);document.body.style.setProperty('--r',D.rgb);var d=document.getElementById('d');D.slides.forEach(function(s,k){var e=document.createElement('section');e.className='s';var h=document.createElement('h1');h.textContent=s.t;e.appendChild(h);if(s.img){var m=document.createElement('img');m.src=s.img;m.referrerPolicy='no-referrer';m.alt='';e.appendChild(m)}var p=document.createElement('p');p.textContent=s.x;e.appendChild(p);var f=document.createElement('small');f.textContent=(k+1)+' / '+D.slides.length+(s.src?' · imagem: '+s.src:'');e.appendChild(f);d.appendChild(e)});function g(n){var L=d.children;L[i].classList.remove('on');i=Math.max(0,Math.min(L.length-1,i+n));L[i].classList.add('on')}d.children[0].classList.add('on');addEventListener('keydown',function(e){if(e.key=='ArrowRight'||e.key==' ')g(1);if(e.key=='ArrowLeft')g(-1)});<\/script></body></html>`;
 X.download(new Blob([html],{type:'text/html'}),safe(deck.title||'apresentacao')+'.html');msg('Apresentação baixada: abre em qualquer navegador.')};
function rSlSaved(){const el=q('#slSaved',P),L=LSg('jv_decks',[]);el.innerHTML=L.length?'':'<div class="hint">Nenhuma apresentação salva.</div>';L.forEach((d,i)=>{const r=ce('div','lbPr');r.innerHTML=`<button type="button" class="x lbPrO"><b>${esc(d.title||'Sem título')}</b><small>${d.slides.length} slides · ${new Date(d.t).toLocaleDateString('pt-BR')}</small></button><button type="button" class="x" aria-label="Apagar apresentação">✕</button>`;const[o,x]=qa('button',r);o.onclick=()=>{deck={title:d.title,slides:JSON.parse(JSON.stringify(d.slides))};q('#slTitle',P).value=deck.title||'';saveDeck();rSl();msg('Apresentação aberta.')};x.onclick=()=>{if(!confirm('Apagar esta apresentação?'))return;const M=LSg('jv_decks',[]);M.splice(i,1);LSs('jv_decks',M);rSlSaved()};el.append(r)})}
q('#slSv',P).onclick=()=>{if(!deck.slides.length)return msg('Nada para salvar.');const L=LSg('jv_decks',[]).filter(d=>d.title!==deck.title||!deck.title);L.unshift({t:Date.now(),...deck});LSs('jv_decks',L.slice(0,20))?msg('Apresentação salva.'):msg('Sem espaço para salvar.');rSlSaved()};
rSl();rSlSaved();

/* =================== FOTOS =================== */
const ft=q('#ft',P),fx=ft.getContext('2d');let src=null,fxK='orig',srcName='foto';
const FX=[['orig','Original',''],['holo','Holograma','grayscale(1) brightness(1.1) contrast(1.25)'],['pb','Preto e branco','grayscale(1) contrast(1.1)'],['sepia','Sépia','sepia(.85) contrast(1.05)'],['viv','Vívido','saturate(1.6) contrast(1.12)'],['noite','Visão noturna','grayscale(1) brightness(1.35) contrast(1.2)'],['rx','Raio-X','invert(1) grayscale(1) contrast(1.35)'],['retro','Retrô','sepia(.35) saturate(1.4) contrast(.92) brightness(1.05)']];
q('#ftFx',P).innerHTML=FX.map(f=>`<button type="button" class="x" data-f="${f[0]}" aria-pressed="${f[0]==='orig'}">${f[1]}</button>`).join('');
q('#ftFx',P).onclick=e=>{const b=e.target.closest('[data-f]');if(!b)return;fxK=b.dataset.f;qa('[data-f]',P).forEach(x=>x.setAttribute('aria-pressed',String(x===b)));ftRender()};
['#ftB','#ftC','#ftS','#ftTx','#ftPos'].forEach(s=>q(s,P).addEventListener('input',ftRender));
function ftRender(){const has=!!src;q('#ftHint',P).hidden=has;ft.hidden=!has;if(!has)return;const k=Math.min(1,1600/Math.max(src.width,src.height)),W=Math.round(src.width*k),H=Math.round(src.height*k);ft.width=W;ft.height=H;const f=FX.find(x=>x[0]===fxK)||FX[0];
 fx.filter=(f[2]+` brightness(${q('#ftB',P).value/100}) contrast(${q('#ftC',P).value/100}) saturate(${q('#ftS',P).value/100})`).trim();fx.drawImage(src,0,0,W,H);fx.filter='none';
 const tint=c=>{fx.save();fx.globalCompositeOperation='multiply';fx.fillStyle=c;fx.fillRect(0,0,W,H);fx.restore()};
 if(fxK==='holo'){tint(X.color||'#a6ecff');fx.save();fx.globalCompositeOperation='screen';fx.fillStyle='rgba('+(X.rgb||'166,236,255')+',.12)';fx.fillRect(0,0,W,H);fx.restore();fx.fillStyle='rgba(0,0,0,.18)';for(let y=0;y<H;y+=4)fx.fillRect(0,y,W,1)}
 if(fxK==='noite'){tint('#4dff88');const g=fx.createRadialGradient(W/2,H/2,Math.min(W,H)*.3,W/2,H/2,Math.max(W,H)*.7);g.addColorStop(0,'rgba(0,0,0,0)');g.addColorStop(1,'rgba(0,0,0,.75)');fx.fillStyle=g;fx.fillRect(0,0,W,H)}
 if(fxK==='rx')tint('#9fd8ff');
 if(fxK==='retro'){const g=fx.createRadialGradient(W/2,H/2,Math.min(W,H)*.35,W/2,H/2,Math.max(W,H)*.75);g.addColorStop(0,'rgba(0,0,0,0)');g.addColorStop(1,'rgba(40,20,0,.55)');fx.fillStyle=g;fx.fillRect(0,0,W,H)}
 const t=q('#ftTx',P).value.trim();if(t){const fs=Math.max(22,Math.round(W/16));fx.font=`800 ${fs}px "Space Grotesk",system-ui,sans-serif`;fx.textAlign='center';const pos=q('#ftPos',P).value,y=pos==='t'?fs*1.4:pos==='c'?H/2+fs/3:H-fs*.8;fx.lineWidth=Math.max(3,fs/9);fx.strokeStyle='rgba(0,0,0,.75)';fx.strokeText(t,W/2,y,W*.92);fx.fillStyle='#fff';fx.shadowColor='rgba(0,0,0,.5)';fx.shadowBlur=8;fx.fillText(t,W/2,y,W*.92);fx.shadowBlur=0;fx.textAlign='start'}}
async function ftLoad(blob,nm){src=await createImageBitmap(blob);srcName=nm||'foto';ftRender();X.sfx('boot')}
const onFile=e=>{const f=e.target.files[0];e.target.value='';if(f)ftLoad(f,f.name.replace(/\.\w+$/,'')).catch(er=>msg('Não consegui abrir a foto: '+er.message))};
q('#ftFile',P).onchange=onFile;q('#ftCam',P).onchange=onFile;
q('#ftRs',P).onclick=()=>{fxK='orig';['#ftB','#ftC','#ftS'].forEach(s=>q(s,P).value=100);q('#ftTx',P).value='';qa('[data-f]',P).forEach(x=>x.setAttribute('aria-pressed',String(x.dataset.f==='orig')));ftRender()};
const ftBlob=()=>new Promise(r=>ft.toBlob(r,'image/jpeg',.92));
q('#ftDl',P).onclick=async()=>{if(!src)return msg('Abra uma foto primeiro.');X.download(await ftBlob(),safe(srcName)+'-jarvis.jpg');msg('Foto baixada.')};
q('#ftHo',P).onclick=async()=>{if(!src)return msg('Abra uma foto primeiro.');X.holoBlob&&X.holoBlob(await ftBlob(),srcName)};
q('#ftQd',P).onclick=()=>{if(!src)return msg('Abra uma foto primeiro.');strokes=[];X.boardImage(ft.toDataURL('image/jpeg',.9));showSec('qd');msg('Foto no quadro. Desenhe por cima com o laser.')};
/* criação de imagem por IA (servidor do Jarvis) */
async function imagine(prompt){prompt=String(prompt||'').trim();if(!prompt)return msg('Descreva a imagem.');if(!navigator.onLine){msg('Estou sem internet agora.');return'Estou sem internet agora, senhor.'}
 const b=q('#ftAiF button',P);b.disabled=true;q('#ftHint',P).textContent='Criando a imagem, senhor… isso leva alguns segundos.';q('#ftHint',P).hidden=false;ft.classList.add('gen');
 const send=stream=>JV.hdr().then(h=>fetch('/api/public/imagine',{method:'POST',headers:h,body:JSON.stringify({prompt,stream})}));
 const fail=async r=>{let j={};try{j=await r.json()}catch{}const m=j.error?.message||j.error||j.message||('HTTP '+r.status);return Error(r.status===402||/credit/i.test(m)?'os créditos de IA do Jarvis acabaram. Eles renovam no início do mês.':r.status===429?'muitos pedidos seguidos; tente de novo em alguns segundos.':m)};
 const show=async(b64,fin)=>{const bl=await (await fetch('data:image/png;base64,'+b64)).blob();await ftLoad(bl,safe(prompt).slice(0,30));ft.classList.toggle('gen',!fin)};
 try{const r=await send(true);if(!r.ok||!r.body)throw await fail(r);const rd=r.body.pipeThrough(new TextDecoderStream()).getReader();let buf='',any=false,done=false,err='';
  for(;;){const{value,done:d}=await rd.read();if(d)break;buf+=value;let i;while((i=buf.indexOf('\n\n'))>=0){const blk=buf.slice(0,i);buf=buf.slice(i+2);let ev='',data='';blk.split('\n').forEach(l=>{if(l.startsWith('event:'))ev=l.slice(6).trim();else if(l.startsWith('data:'))data+=l.slice(5).trim()});if(!data||data==='[DONE]')continue;let p;try{p=JSON.parse(data)}catch{continue}const ty=ev||p.type;if(ev==='error'||p.type==='error'){any=true;err=p.error?.message||'falha ao criar a imagem';continue}if(/partial_image|completed/.test(ty||'')&&p.b64_json){any=true;const fin=/completed/.test(ty);await show(p.b64_json,fin);if(fin)done=true}}}
  if(err)throw Error(err);if(!any){const r2=await send(false);if(!r2.ok)throw await fail(r2);const j=await r2.json();const b64=j.data?.[0]?.b64_json;if(!b64)throw Error('a imagem não veio');await show(b64,true);done=true}
  if(!done)throw Error('a criação parou no meio');ft.classList.remove('gen');X.sfx('ok');msg('Imagem criada. Pode aplicar filtros, legenda ou mandar para a Mesa.');return'Imagem criada no Estúdio, senhor.'}
 catch(e){ft.classList.remove('gen');q('#ftHint',P).textContent='Não consegui criar a imagem: '+e.message;q('#ftHint',P).hidden=false;if(src){ft.hidden=false;q('#ftHint',P).hidden=true;msg('Não consegui criar a imagem: '+e.message)}return'Não consegui criar a imagem: '+e.message}finally{b.disabled=false}}
q('#ftAiF',P).onsubmit=e=>{e.preventDefault();imagine(q('#ftAi',P).value)};
ftRender();

/* =================== DIÁRIO =================== */
const fdt=t=>new Date(t).toLocaleString('pt-BR',{weekday:'short',day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'});
function rDb(){const el=q('#dbList',P);if(!X.diary){el.textContent='Diário indisponível.';return}const L=X.diary.list();el.innerHTML=L.length?'':'<div class="hint">O diário está vazio.</div>';L.forEach((d,i)=>{const r=ce('div','dbItem');r.innerHTML=`<small>${esc(fdt(d.t))}</small>`;const t=ce('span');t.textContent=d.x;const x=ce('button','x','✕');x.type='button';x.setAttribute('aria-label','Apagar registro');x.style.float='right';x.onclick=()=>{X.diary.del(i)};r.prepend(x);r.append(t);el.append(r)})}
addEventListener('jx-diary',rDb);
q('#dbF',P).onsubmit=e=>{e.preventDefault();const v=q('#dbIn',P).value.trim();if(!v||!X.diary)return;X.diary.add(v);q('#dbIn',P).value='';msg('Registrado no diário de bordo.')};

/* =================== VOZ =================== */
X.addCmd((s,n)=>{let m;
 if(/^(?:abr\w*|mostr\w*|ir para|ativ\w*)\s+(?:o |a )?(?:estudio(?: de midia)?|quadro(?: laser)?|lousa)$/.test(n)){X.studio('qd');return'Estúdio aberto no quadro laser, senhor.'}
 if(/^(?:abr\w*|mostr\w*)\s+(?:os |as )?(?:slides|apresentac\w*)$/.test(n)){X.studio('sl');return'Slides abertos.'}
 if(/^(?:abr\w*|mostr\w*)\s+(?:o )?editor de fotos?$/.test(n)){X.studio('ft');return'Editor de fotos aberto.'}
 if(m=s.match(/^(?:crie|cria|criar|fa[cç]a|faz|fazer|gere|gera|gerar|monte|monta|prepare)\s+(?:uns |umas |os |as |uma |um )?(?:slides?|apresenta[cç](?:ão|ao|ões|oes))\s+(?:sobre|de|do|da|dos|das)\s+(.{2,})$/i)){X.studio('sl');return genSlides(m[1].replace(/[.!?]+$/,''),6)}
 if(m=s.match(/^(?:crie|cria|criar|gere|gera|gerar|fa[cç]a|faz|fazer|invente)\s+(?:uma |um )?(?:imagem|foto|figura|ilustra[cç][aã]o|arte)\s+(?:de |do |da |dos |das |com |sobre )?(.{2,})$/i)){X.studio('ft');q('#ftAi',P).value=m[1];return imagine(m[1].replace(/[.!?]+$/,''))}
 if(m=s.match(/^(?:desenhe|desenha|desenhar|rabisque|esboce)\s+(?:uma |um |o |a )?(.{2,})$/i)){X.studio('qd');q('#qdAi',P).value=m[1];return aiDraw(m[1].replace(/[.!?]+$/,''))}
 if(/^(?:iniciar |inicie |comecar |comece |abrir |abra )?(?:a )?apresentacao$|^apresent(ar|e)(?: os slides)?$/.test(n)){return present(0)?'Apresentando, senhor. Deslize para o lado ou use as setas.':'Ainda não há slides. Diga "crie slides sobre" e o tema.'}
 if(/(gere|gera|gerar|faca|faz|fazer|crie|criar|grave|gravar)\s+(?:o |um )?video(?: (?:dos|da|com os) (?:slides|apresentacao))?$/.test(n)){X.studio('sl');return makeVideo()}
 if(show&&!show.hidden){if(/^(proximo|avanc\w*|seguinte)(?: slide)?$/.test(n)){go(1);return'Próximo.'}if(/^(anterior|volt\w*)(?: slide)?$/.test(n)){go(-1);return'Voltando.'}if(/^(fech\w*|encerr\w*|sair)/.test(n)){closeShow();return'Apresentação encerrada.'}}
 return null});
})();
