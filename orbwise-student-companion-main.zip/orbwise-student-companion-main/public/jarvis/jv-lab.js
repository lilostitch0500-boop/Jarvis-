/* Laboratório Stark: editor de código com o celular ao lado (site/app ao vivo, JavaScript e Python),
   Professor J.A.R.V.I.S., aulas rápidas, projetos salvos, abrir arquivo, baixar e testar fora do app.
   Também cria a aba com as seções Estúdio e Idiomas (preenchidas por jv-studio.js e jv-lang.js). */
(function(){
'use strict';
const X=window.JVX;if(!X)return;const {q,qa,ce,LSg,LSs}=X;
const msg=t=>{try{toast(t)}catch{}};
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
X.esc=esc;
const safe=s=>(s||'projeto').toLowerCase().normalize('NFD').replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,40)||'projeto';
X.safe=safe;
X.download=(blob,name)=>{const a=ce('a');a.href=URL.createObjectURL(blob);a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),5000)};

/* ---------- aba e seções ---------- */
const body=X.sheet('sLb','LABORATÓRIO STARK','nLb','⌨','Lab');
body.innerHTML=`<div class="jxtabs" role="tablist" aria-label="Seções do laboratório"><button type="button" role="tab" data-p="code" class="on">⌨ CÓDIGO</button><button type="button" role="tab" data-p="studio">✎ ESTÚDIO</button><button type="button" role="tab" data-p="lang">🌐 IDIOMAS</button></div><div class="lbPane" data-p="code"></div><div class="lbPane" data-p="studio" hidden></div><div class="lbPane" data-p="lang" hidden></div>`;
const pane=k=>q('.lbPane[data-p="'+k+'"]',body);
X.labPaneEl=pane;
const showPane=k=>{qa('.jxtabs[role=tablist] button',body).forEach(b=>{b.classList.toggle('on',b.dataset.p===k);b.setAttribute('aria-selected',String(b.dataset.p===k))});qa('.lbPane',body).forEach(p=>p.hidden=p.dataset.p!==k);pane(k).dispatchEvent(new Event('jx-show'));LSs('jv_lab_pane',k)};
X.labPane=k=>{if(!q('#sLb').classList.contains('show'))X.open('sLb');showPane(k)};
q('.jxtabs',body).onclick=e=>{const b=e.target.closest('button');if(b)showPane(b.dataset.p)};
q('#sLb').addEventListener('jx-open',()=>setTimeout(()=>showPane(LSg('jv_lab_pane','code')),30));

/* ---------- cérebro do professor (chaves próprias primeiro, depois o núcleo do Jarvis) ---------- */
X.tutorAsk=async(msgs,sy)=>{const er=[];
 try{if(typeof cfg!=='undefined'&&typeof keysOf==='function'&&typeof ask==='function')for(const p of cfg.order||[])for(const k of keysOf(p)){try{const t=await ask(p,k,msgs,sy);if(t&&t.trim())return t}catch(e){er.push(e.message)}}}catch{}
 if(!navigator.onLine)throw Error('estou sem internet agora, senhor');
 const r=await JV.api('/api/public/chat',{system:sy,messages:msgs.slice(-12),mode:'tutor'}),j=await r.json().catch(()=>({}));
 if(r.ok&&j.text)return j.text;throw Error(j.error||er[0]||('HTTP '+r.status))};
X.speakShort=t=>{try{if(cfg.speak===false)return;const s=String(t).replace(/```[\s\S]*?```/g,' ').replace(/[*#`_>]/g,'').replace(/\s+/g,' ').trim();if(s)speak(s.slice(0,420))}catch{}};

/* ---------- modelos e aulas ---------- */
const TPL={
 web:`<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<title>Meu app</title>
<style>
  body{margin:0;min-height:100vh;display:grid;place-items:center;
    background:#04121f;color:#a6ecff;font-family:system-ui,sans-serif}
  button{padding:14px 26px;font-size:18px;border-radius:12px;
    border:2px solid #a6ecff;background:transparent;color:#a6ecff}
</style>
</head>
<body>
  <div style="text-align:center">
    <h1>Olá, senhor!</h1>
    <p id="msg">Toque no botão.</p>
    <button onclick="contar()">Ativar</button>
  </div>
<script>
  let vezes = 0;
  function contar(){
    vezes++;
    document.getElementById('msg').textContent = 'Ativado ' + vezes + ' vez(es)';
    console.log('cliques:', vezes);
  }
</script>
</body>
</html>`,
 js:`// JavaScript puro: o resultado aparece na tela do celular.
const nome = 'senhor';
console.log('Olá, ' + nome + '!');

for (let i = 1; i <= 5; i++) {
  console.log('Contagem:', i);
}

const dobro = n => n * 2;
console.log('O dobro de 21 é', dobro(21));`,
 py:`# Python: o resultado aparece na tela do celular.
nome = "senhor"
print(f"Olá, {nome}!")

for i in range(1, 6):
    print("Contagem:", i)

def dobro(n):
    return n * 2

print("O dobro de 21 é", dobro(21))`};
const LES=[
 {lg:'py',t:'Python 1 · Mostrar mensagens',d:'O print() mostra texto na tela. Textos ficam entre aspas. Mude a frase e toque em Rodar.',c:'print("Olá, senhor!")\nprint("Eu estou aprendendo Python.")\nprint(2 + 3)'},
 {lg:'py',t:'Python 2 · Variáveis e contas',d:'Variáveis guardam valores com um nome. Aqui guardamos números e fazemos contas com eles.',c:'idade = 15\nanos_futuro = 10\nprint("Daqui a", anos_futuro, "anos terei", idade + anos_futuro)\n\npreco = 19.90\nquantidade = 3\nprint("Total:", preco * quantidade)'},
 {lg:'py',t:'Python 3 · Decisões com if',d:'O if escolhe um caminho. Repare nos dois pontos e no recuo de 4 espaços: em Python isso é obrigatório.',c:'nota = 7\n\nif nota >= 6:\n    print("Aprovado, senhor!")\nelse:\n    print("Precisa estudar mais.")'},
 {lg:'py',t:'Python 4 · Repetição e listas',d:'Listas guardam vários itens. O for passa por cada um. Experimente colocar suas armaduras favoritas.',c:'armaduras = ["Mark 3", "Mark 42", "Mark 50", "Mark 85"]\n\nfor a in armaduras:\n    print("Armadura pronta:", a)\n\nprint("Total:", len(armaduras))'},
 {lg:'py',t:'Python 5 · Perguntar ao usuário',d:'O input() pergunta algo. Escreva a resposta na caixa "Entradas" abaixo do editor antes de rodar.',c:'nome = input("Qual é o seu nome? ")\nprint("Muito prazer,", nome)'},
 {lg:'web',t:'Site 1 · Primeira página',d:'HTML monta a estrutura: h1 é o título, p é um parágrafo. O celular ao lado mostra o resultado na hora.',c:'<!DOCTYPE html>\n<html lang="pt-BR">\n<head>\n<meta charset="utf-8">\n</head>\n<body>\n  <h1>Minha primeira página</h1>\n  <p>Feita no laboratório do Jarvis.</p>\n</body>\n</html>'},
 {lg:'web',t:'Site 2 · Cores e estilo (CSS)',d:'CSS deixa bonito: cor, fundo, tamanho e bordas. Troque as cores e veja o celular mudar ao vivo.',c:'<!DOCTYPE html>\n<html lang="pt-BR">\n<head>\n<meta charset="utf-8">\n<style>\n  body{background:#101820;color:#ffe36b;font-family:sans-serif;padding:20px}\n  .card{border:2px solid #ffe36b;border-radius:16px;padding:16px}\n</style>\n</head>\n<body>\n  <div class="card">\n    <h2>Cartão estilizado</h2>\n    <p>Mude as cores no CSS.</p>\n  </div>\n</body>\n</html>'},
 {lg:'web',t:'Site 3 · Botão que reage (JS)',d:'JavaScript dá vida: quando o botão é tocado, a função muda o texto e a cor do fundo.',c:'<!DOCTYPE html>\n<html lang="pt-BR">\n<head>\n<meta charset="utf-8">\n<style>body{font-family:sans-serif;text-align:center;padding-top:60px;transition:background .4s}</style>\n</head>\n<body>\n  <h1 id="t">Modo normal</h1>\n  <button onclick="alertar()">Modo alerta</button>\n<script>\n  function alertar(){\n    document.body.style.background = "#ff6b6b";\n    document.getElementById("t").textContent = "ALERTA ATIVO";\n  }\n</script>\n</body>\n</html>'},
 {lg:'web',t:'Site 4 · Lista de tarefas',d:'Um mini app de verdade: digite uma tarefa e toque em Adicionar. Usa input, botão e criação de elementos.',c:'<!DOCTYPE html>\n<html lang="pt-BR">\n<head>\n<meta charset="utf-8">\n<style>\n  body{font-family:sans-serif;padding:16px;background:#04121f;color:#eef}\n  input{padding:10px;width:60%}\n  button{padding:10px}\n  li{padding:6px 0}\n</style>\n</head>\n<body>\n  <h2>Tarefas</h2>\n  <input id="c" placeholder="Nova tarefa">\n  <button onclick="add()">Adicionar</button>\n  <ul id="l"></ul>\n<script>\n  function add(){\n    const c = document.getElementById("c");\n    if(!c.value) return;\n    const li = document.createElement("li");\n    li.textContent = c.value;\n    li.onclick = () => li.remove();\n    document.getElementById("l").append(li);\n    c.value = "";\n  }\n</script>\n</body>\n</html>'},
 {lg:'js',t:'JavaScript 1 · Variáveis e funções',d:'let e const guardam valores. Funções são receitas que você chama pelo nome.',c:'const nome = "senhor";\nlet energia = 100;\n\nfunction usar(qtd){\n  energia = energia - qtd;\n  console.log("Energia restante:", energia + "%");\n}\n\nusar(20);\nusar(35);'},
 {lg:'js',t:'JavaScript 2 · Listas e repetição',d:'Arrays são listas. forEach passa por cada item, e map cria uma nova lista transformada.',c:'const notas = [7, 9, 5, 10];\n\nnotas.forEach((n, i) => console.log("Prova", i + 1, ":", n));\n\nconst media = notas.reduce((a, b) => a + b) / notas.length;\nconsole.log("Média:", media);'}];

/* ---------- interface do código ---------- */
const P=pane('code');
P.innerHTML=`<div class="jxrow lbBar"><select id="lbLg" aria-label="Linguagem"><option value="web">🌐 Site / App (HTML·CSS·JS)</option><option value="js">⚡ JavaScript</option><option value="py">🐍 Python</option></select>
<input class="t grow" id="lbName" placeholder="Nome do projeto" autocomplete="off" style="max-width:220px">
<button class="x lbRunB" type="button" id="lbRun">▶ Rodar</button><button class="x" type="button" id="lbStop" hidden>■ Parar</button><button class="x lbSw" type="button" id="lbSw">📱 Ver celular</button></div>
<div class="jxrow" style="margin:2px 0 8px"><button class="x" type="button" id="lbNew">✚ Novo</button><button class="x" type="button" id="lbSave">💾 Salvar</button><label class="x" style="cursor:pointer">📂 Abrir arquivo<input type="file" id="lbFile" hidden accept=".html,.htm,.js,.py,.txt,.css,.json"></label><button class="x" type="button" id="lbDl">⬇ Baixar</button><button class="x" type="button" id="lbOutB">↗ Testar fora</button><label class="hint" style="display:flex;gap:6px;align-items:center;margin:0 0 0 6px"><input type="checkbox" id="lbLive" checked> Ao vivo</label></div>
<div class="lbSplit" id="lbSplit"><div class="lbLeft"><div class="lbEd"><div class="lbGut" id="lbGut">1</div><div class="lbIn"><pre id="lbHl" aria-hidden="true"></pre><textarea id="lbCode" spellcheck="false" autocapitalize="off" autocomplete="off" autocorrect="off" aria-label="Editor de código" wrap="off"></textarea></div></div>
<div class="lbKeys" aria-label="Teclas rápidas">${['⇥','{ }','( )','[ ]','< >','" "',':',';','=','/','#','.'].map(k=>`<button type="button" data-k="${esc(k)}">${esc(k)}</button>`).join('')}</div>
<div id="lbInW" hidden><label class="hint" for="lbStdin">Entradas para o input() — uma por linha</label><textarea id="lbStdin" rows="2" placeholder="Murilo"></textarea></div>
<div class="lbConH"><span>CONSOLE</span><button type="button" class="x" id="lbClr">limpar</button></div><div class="lbCon" id="lbCon" role="log" aria-live="polite"></div></div>
<div class="lbPh"><div class="phone"><div class="notch"></div><iframe id="lbFr" sandbox="allow-scripts allow-modals allow-forms allow-popups" title="Celular simulado"></iframe><pre id="lbTerm" hidden></pre><div class="lbStat" id="lbStat"></div></div></div></div>
<h2>Professor J.A.R.V.I.S.</h2>
<div class="jxrow"><button class="x" type="button" data-t="explica">💡 Explicar o código</button><button class="x" type="button" data-t="erro">🩺 Achar o erro</button><button class="x" type="button" data-t="desafio">🎯 Me dê um desafio</button><button class="x" type="button" data-t="melhora">✨ Melhorar o projeto</button><select id="lbLvl" aria-label="Seu nível"><option value="iniciante">Iniciante</option><option value="intermediário">Intermediário</option><option value="avançado">Avançado</option></select></div>
<form id="lbAskF" class="jxrow" style="margin-top:8px"><input class="t grow" id="lbAsk" placeholder="Pergunte: como faço um botão que muda de cor?" autocomplete="off"><button class="x">Perguntar</button></form>
<div id="lbOut"></div>
<h2>Aulas rápidas</h2><div class="lbLes" id="lbLes"></div>
<h2>Meus projetos</h2><div id="lbProj"></div>`;
const ed=q('#lbCode',P),hlEl=q('#lbHl',P),gut=q('#lbGut',P),lgS=q('#lbLg',P),nameI=q('#lbName',P),con=q('#lbCon',P),fr=q('#lbFr',P),term=q('#lbTerm',P),stat=q('#lbStat',P),out=q('#lbOut',P),split=q('#lbSplit',P);
let lg='web',errs=[],hist=[],liveT=0;

/* ---------- destaque de sintaxe ---------- */
const KW={js:'break case catch class const continue default delete do else export extends finally for function if import in instanceof let new return switch this throw try typeof var void while yield async await of true false null undefined console document window',py:'and as assert async await break class continue def del elif else except False finally for from global if import in is lambda None nonlocal not or pass raise return True try while with yield print input range len int str float list dict self'};
const KS={js:new Set(KW.js.split(' ')),py:new Set(KW.py.split(' '))};
const RPY=/(#[^\n]*)|("""[\s\S]*?"""|'''[\s\S]*?'''|"(?:\\.|[^"\\\n])*"|'(?:\\.|[^'\\\n])*')|(\b\d+(?:\.\d+)?\b)|([A-Za-z_]\w*)/g;
const RWB=/(<!--[\s\S]*?-->|\/\*[\s\S]*?\*\/|(?<![:"'])\/\/[^\n]*)|("(?:\\.|[^"\\\n])*"|'(?:\\.|[^'\\\n])*'|`(?:\\.|[^`\\])*`)|(\b\d+(?:\.\d+)?\b)|(<\/?[A-Za-z][\w-]*|\/?>)|([A-Za-z_$][\w$-]*)/g;
function hl(s){const py=lg==='py',re=py?RPY:RWB,kw=py?KS.py:KS.js;re.lastIndex=0;let o='',i=0,m;
 while((m=re.exec(s))){o+=esc(s.slice(i,m.index));const t=m[0];let c='';if(m[1])c='cm';else if(m[2])c='st';else if(m[3])c='nu';else if(!py&&m[4])c='tg';else{const w=py?m[4]:m[5];if(kw.has(w))c='kw';else if(s[re.lastIndex]==='(')c='fn';else if(!py&&s[re.lastIndex]==='='&&/<[^>]*$/.test(s.slice(Math.max(0,m.index-200),m.index)))c='at'}o+=c?`<span class="${c}">${esc(t)}</span>`:esc(t);i=re.lastIndex}
 return o+esc(s.slice(i))+'\n'}
function paint(){const v=ed.value;hlEl.innerHTML=hl(v);const n=v.split('\n').length;let g='';for(let i=1;i<=n;i++)g+=i+'\n';gut.textContent=g;syncScroll()}
function syncScroll(){hlEl.scrollTop=ed.scrollTop;hlEl.scrollLeft=ed.scrollLeft;gut.scrollTop=ed.scrollTop}
ed.addEventListener('scroll',syncScroll);
const autosave=()=>LSs('jv_lab_cur',{lg,c:ed.value,n:nameI.value});
ed.addEventListener('input',()=>{paint();autosave();if(lg==='web'&&q('#lbLive',P).checked){clearTimeout(liveT);liveT=setTimeout(run,700)}});
nameI.addEventListener('input',autosave);
function insert(t,back){const a=ed.selectionStart,b=ed.selectionEnd;ed.setRangeText(t,a,b,'end');if(back){ed.selectionStart=ed.selectionEnd=a+t.length-back}ed.dispatchEvent(new Event('input'))}
ed.addEventListener('keydown',e=>{
 if(e.key==='Tab'){e.preventDefault();insert(lg==='py'?'    ':'  ');return}
 if(e.key==='Enter'&&!e.isComposing){const a=ed.selectionStart,line=ed.value.slice(0,a).split('\n').pop(),ind=(line.match(/^\s*/)||[''])[0],more=/[{(\[:]\s*$/.test(line)||/<(?!\/)[a-z][^>]*>\s*$/i.test(line)&&!/<(meta|br|img|input|link|hr)\b/i.test(line)?(lg==='py'?'    ':'  '):'';e.preventDefault();insert('\n'+ind+more)}
 if((e.ctrlKey||e.metaKey)&&e.key==='Enter'){e.preventDefault();run()}
 if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='s'){e.preventDefault();saveProj()}});
q('.lbKeys',P).addEventListener('pointerdown',e=>{const b=e.target.closest('button');if(!b)return;e.preventDefault();const k=b.dataset.k;if(k==='⇥')insert(lg==='py'?'    ':'  ');else if(k.length===3&&k[1]===' ')insert(k[0]+k[2],1);else insert(k);ed.focus()});

/* ---------- console e celular ---------- */
const clip=s=>String(s).length>2000?String(s).slice(0,2000)+'…':String(s);
function log(t,m){if(t==='error'){errs.push(String(m));if(errs.length>10)errs.shift()}const d=ce('div','lbL '+t);d.textContent=(t==='error'?'✖ ':t==='warn'?'⚠ ':'› ')+clip(m);con.append(d);while(con.children.length>200)con.firstChild.remove();con.scrollTop=con.scrollHeight;if(lg!=='web'&&t!=='status'){term.textContent+=(t==='error'?'✖ ':'')+clip(m)+(String(m).endsWith('\n')?'':'\n');term.scrollTop=term.scrollHeight}}
q('#lbClr',P).onclick=()=>{con.innerHTML='';errs=[]};
const setStat=(t,cls)=>{stat.textContent=t||'';stat.className='lbStat'+(cls?' '+cls:'');stat.hidden=!t};
addEventListener('message',e=>{const d=e.data;if(!d||!d.jvlab||e.source!==fr.contentWindow)return;log(d.t,d.m)});
const HOOK='<script>(function(){function P(t,a){try{parent.postMessage({jvlab:1,t:t,m:[].map.call(a,function(x){try{return x&&typeof x==="object"?JSON.stringify(x):String(x)}catch(e){return String(x)}}).join(" ")},"*")}catch(e){}}["log","info","warn","error"].forEach(function(k){var o=console[k];console[k]=function(){P(k==="info"?"log":k,arguments);try{o.apply(console,arguments)}catch(e){}}});addEventListener("error",function(e){P("error",[e.message+(e.lineno?" (linha "+e.lineno+")":"")])});addEventListener("unhandledrejection",function(e){P("error",["Promessa recusada: "+(e.reason&&e.reason.message||e.reason)])})})()<\/script>';
const VP='<meta name="viewport" content="width=device-width,initial-scale=1">';
function webDoc(src){const add=HOOK+(/name=["']?viewport/i.test(src)?'':VP);if(/<head[^>]*>/i.test(src))return src.replace(/<head[^>]*>/i,m=>m+add);if(/<html[^>]*>/i.test(src))return src.replace(/<html[^>]*>/i,m=>m+add);if(/^\s*<!doctype[^>]*>/i.test(src))return src.replace(/^\s*<!doctype[^>]*>/i,m=>m+add);return add+src}

/* ---------- executores (JS e Python rodam isolados, com tempo limite) ---------- */
const JSW=`self.onmessage=function(e){var S=function(t,a){postMessage({t:t,m:[].map.call(a,function(x){try{return x&&typeof x==="object"?JSON.stringify(x,null,1):String(x)}catch(_){return String(x)}}).join(" ")})};["log","info","warn","error"].forEach(function(k){console[k]=function(){S(k==="info"?"log":k,arguments)}});self.prompt=function(){return null};self.alert=function(x){S("log",["[alerta] "+x])};try{var r=(0,eval)(e.data);Promise.resolve(r).then(function(){postMessage({t:"done"})},function(er){S("error",[String(er)]);postMessage({t:"done"})})}catch(er){var ln=(String(er.stack||"").match(/<anonymous>:(\\d+)/)||[])[1];S("error",[er.name+": "+er.message+(ln?" (linha "+ln+")":"")]);postMessage({t:"done"})}}`;
const PYV='0.26.4',PYW=`importScripts('https://cdn.jsdelivr.net/pyodide/v${PYV}/full/pyodide.js');var py=null;
self.onmessage=async function(e){var code=e.data.code,L=(e.data.stdin||'').split('\\n'),i=0;try{if(!py){postMessage({t:'status',m:'Carregando o Python (só na primeira vez, uns segundos)…'});py=await loadPyodide({indexURL:'https://cdn.jsdelivr.net/pyodide/v${PYV}/full/'});}
postMessage({t:'status',m:'Rodando Python…'});py.setStdout({batched:function(s){postMessage({t:'log',m:s})}});py.setStderr({batched:function(s){postMessage({t:'error',m:s})}});py.setStdin({stdin:function(){if(i<L.length){var v=L[i++];return v}return null},isatty:false});
try{await py.loadPackagesFromImports(code)}catch(_){}await py.runPythonAsync(code);postMessage({t:'done'})}catch(er){var s=String(er&&er.message||er).split('\\n').filter(function(x){return x.trim()});var k=s.findIndex(function(x){return /File "<exec>"/.test(x)});postMessage({t:'error',m:(k>=0?s.slice(k):s.slice(-4)).join('\\n').replace(/File "<exec>", /g,'')});postMessage({t:'done'})}}`;
let wk=null,wkT=0,pyW=null;
const blobW=src=>new Worker(URL.createObjectURL(new Blob([src],{type:'text/javascript'})));
function stopRun(why){clearTimeout(wkT);if(wk){wk.terminate();wk=null}if(why&&pyW){pyW.terminate();pyW=null}q('#lbStop',P).hidden=true;if(why){log('error',why);setStat('PARADO','err')}}
q('#lbStop',P).onclick=()=>stopRun('Execução interrompida pelo senhor.');
function run(){errs=[];const src=ed.value;stopRun();
 if(lg==='web'){term.hidden=true;fr.hidden=false;con.innerHTML='';fr.srcdoc=webDoc(src);setStat('');return}
 fr.hidden=true;term.hidden=false;term.textContent='';con.innerHTML='';q('#lbStop',P).hidden=false;
 if(lg==='js'){setStat('RODANDO');wk=blobW(JSW);wk.onmessage=e=>{if(e.data.t==='done'){setStat('OK','ok');setTimeout(()=>{if(wk)stopRun()},4000)}else log(e.data.t,e.data.m)};wk.onerror=e=>{log('error',e.message);stopRun()};wk.postMessage(src);wkT=setTimeout(()=>stopRun('Parei o programa: passou de 8 segundos (talvez um laço infinito, senhor).'),8000);return}
 if(!navigator.onLine&&!pyW){log('error','O Python precisa de internet na primeira vez para carregar.');q('#lbStop',P).hidden=true;return}
 if(!pyW){pyW=blobW(PYW);pyW.onerror=e=>{log('error','Não consegui iniciar o Python: '+(e.message||'erro'));pyW=null;q('#lbStop',P).hidden=true}}
 setStat('PYTHON…');const w=pyW,t0=Date.now();let loaded=!!w.ready;
 w.onmessage=e=>{const d=e.data;if(d.t==='status'){setStat(d.m.startsWith('Carregando')?'CARREGANDO':'RODANDO');if(d.m.startsWith('Rodando')){w.ready=1;if(!loaded){loaded=true;clearTimeout(wkT);wkT=setTimeout(()=>stopRun('Parei o programa: passou de 15 segundos (talvez um laço infinito, senhor).'),15000)}}else log('status',d.m);return}if(d.t==='done'){clearTimeout(wkT);q('#lbStop',P).hidden=true;setStat(errs.length?'ERRO':'OK',errs.length?'err':'ok');return}log(d.t,d.m)};
 w.postMessage({code:src,stdin:q('#lbStdin',P).value});clearTimeout(wkT);wkT=setTimeout(()=>stopRun(loaded?'Parei o programa: passou de 15 segundos (talvez um laço infinito, senhor).':'O Python demorou demais para carregar. Verifique a internet e tente de novo.'),loaded?15000:60000)}
X.labRun=run;
q('#lbRun',P).onclick=()=>{run();if(innerWidth<=760&&!split.classList.contains('ph'))toggleView(true)};

/* ---------- linguagem, celular, arquivos ---------- */
function setLg(v,code){lg=v;lgS.value=v;q('#lbInW',P).hidden=v!=='py';q('#lbLive',P).parentElement.hidden=v!=='web';if(code!=null)ed.value=code;paint();autosave();if(v==='web')run();else{fr.hidden=true;term.hidden=false;term.textContent=v==='py'?'🐍 Toque em ▶ Rodar para executar o Python.':'⚡ Toque em ▶ Rodar para executar.';setStat('')}}
lgS.onchange=()=>{const v=lgS.value,cur=ed.value.trim();const isTpl=!cur||Object.values(TPL).some(t=>t.trim()===cur);if(!isTpl)stash();setLg(v,isTpl?TPL[v]:(confirm('Trocar a linguagem e começar um código novo? (o atual fica salvo em Meus projetos)')?TPL[v]:ed.value))};
function toggleView(ph){split.classList.toggle('ph',ph);q('#lbSw',P).textContent=ph?'✎ Ver código':'📱 Ver celular'}
q('#lbSw',P).onclick=()=>toggleView(!split.classList.contains('ph'));
const EXT={web:'html',js:'js',py:'py'};
function stash(){const c=ed.value.trim();if(!c||Object.values(TPL).some(t=>t.trim()===c))return;const L=LSg('jv_lab',[]);if(L[0]&&L[0].c===ed.value)return;L.unshift({t:Date.now(),n:(nameI.value||'Rascunho')+' (automático)',lg,c:ed.value});LSs('jv_lab',L.slice(0,40));rProj()}
function saveProj(){const c=ed.value;if(!c.trim())return msg('O editor está vazio.');const n=nameI.value.trim()||'Projeto '+new Date().toLocaleString('pt-BR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'});nameI.value=n;const L=LSg('jv_lab',[]).filter(p=>p.n!==n);L.unshift({t:Date.now(),n,lg,c});LSs('jv_lab',L.slice(0,40))?msg('Projeto "'+n+'" salvo neste aparelho.'):msg('Sem espaço para salvar. Apague projetos antigos.');rProj();autosave();X.sfx('ok')}
q('#lbSave',P).onclick=saveProj;
q('#lbNew',P).onclick=()=>{stash();nameI.value='';setLg(lg,TPL[lg]);msg('Projeto novo. O anterior ficou em Meus projetos.')};
q('#lbFile',P).onchange=async e=>{const f=e.target.files[0];e.target.value='';if(!f)return;if(f.size>500000)return msg('Arquivo grande demais para o editor (máx. 500 KB).');stash();const t=await f.text(),ext=(f.name.split('.').pop()||'').toLowerCase();nameI.value=f.name.replace(/\.\w+$/,'');setLg(ext==='py'?'py':ext==='js'?'js':'web',t);msg('Arquivo "'+f.name+'" aberto.')};
function dl(){const c=ed.value;if(!c.trim())return msg('O editor está vazio.');const nm=safe(nameI.value)+'.'+EXT[lg];X.download(new Blob([c],{type:lg==='web'?'text/html':'text/plain'}),nm);log('status','Baixado: '+nm+(lg==='web'?' — abra o arquivo no navegador do celular ou do computador.':lg==='py'?' — rode no computador com "python '+nm+'" ou no celular pelo app Pydroid 3.':' — rode com Node.js: "node '+nm+'".'));msg('Arquivo '+nm+' baixado.');return nm}
q('#lbDl',P).onclick=dl;
q('#lbOutB',P).onclick=()=>{const c=ed.value;if(lg==='web'){const u=URL.createObjectURL(new Blob([c],{type:'text/html'})),w=open(u,'_blank');if(!w)msg('O navegador bloqueou a nova aba. Use ⬇ Baixar e abra o arquivo.');else msg('Projeto aberto numa aba separada, fora do Jarvis.');setTimeout(()=>URL.revokeObjectURL(u),60000)}else{dl();out.prepend(card('a',lg==='py'?'Para testar fora do Jarvis, senhor:\n1. No celular: instale o app "Pydroid 3", abra o arquivo baixado e toque em ▶.\n2. No computador: instale o Python (python.org) e rode no terminal: python '+safe(nameI.value)+'.py':'Para testar fora: instale o Node.js (nodejs.org) e rode no terminal: node '+safe(nameI.value)+'.js'))}};
function rProj(){const el=q('#lbProj',P),L=LSg('jv_lab',[]);el.innerHTML=L.length?'':'<div class="hint">Nenhum projeto salvo ainda. Toque em 💾 Salvar.</div>';L.forEach((p,i)=>{const d=ce('div','lbPr');d.innerHTML=`<button type="button" class="x lbPrO"><b>${esc(p.n)}</b><small>${{web:'Site/App',js:'JavaScript',py:'Python'}[p.lg]||p.lg} · ${new Date(p.t).toLocaleString('pt-BR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'})}</small></button><button type="button" class="x" aria-label="Apagar projeto ${esc(p.n)}">✕</button>`;const[o,x]=qa('button',d);o.onclick=()=>{stash();nameI.value=p.n.replace(/ \(automático\)$/,'');setLg(p.lg,p.c);msg('Projeto aberto.');P.scrollTo?.(0,0);q('#sLb').scrollTo({top:0,behavior:'smooth'})};x.onclick=()=>{if(!confirm('Apagar o projeto "'+p.n+'"?'))return;const M=LSg('jv_lab',[]);M.splice(i,1);LSs('jv_lab',M);rProj()};el.append(d)})}

/* ---------- professor ---------- */
const LGN={web:'HTML, CSS e JavaScript (página web)',js:'JavaScript',py:'Python'};
function card(who,text,isErr){const d=ce('div','lbMsg'+(isErr?' err':''));if(who==='u'){d.classList.add('u');d.textContent=text;return d}
 const parts=String(text).split(/```([\w+-]*)\n?([\s\S]*?)```/g);for(let i=0;i<parts.length;i+=3){const tx=parts[i].replace(/\*\*(.+?)\*\*/g,'$1').replace(/^#+\s*/gm,'').replace(/`([^`]+)`/g,'$1').trim();if(tx){const p=ce('div');p.textContent=tx;d.append(p)}
  if(i+2<parts.length){const tag=(parts[i+1]||'').toLowerCase(),code=parts[i+2].replace(/\s+$/,''),pre=ce('pre');pre.textContent=code;const row=ce('div','jxrow'),use=ce('button','x','↳ Usar no editor'),cp=ce('button','x','⧉ Copiar');use.type=cp.type='button';
   const tl=/py/.test(tag)?'py':/html|xml/.test(tag)||/<html|<body|<div|<!doctype/i.test(code)?'web':/js|javascript|node/.test(tag)?(lg==='web'&&!/console\.log/.test(code)?'web':'js'):lg;
   use.onclick=()=>{stash();if(tl==='web'&&lg==='web'&&!/<html|<body|<!doctype/i.test(code)&&/<script|<style|<\w+/.test(code)===false){ed.value=ed.value.replace(/<\/script>/i,'\n'+code+'\n</script>')}else setLg(tl,code);paint();autosave();if(tl==='web')run();msg('Código colocado no editor. Toque em ▶ Rodar.');q('#sLb').scrollTo({top:0,behavior:'smooth'})};
   cp.onclick=()=>{navigator.clipboard?.writeText(code).then(()=>msg('Copiado.'),()=>msg('Não consegui copiar.'))};row.append(use,cp);d.append(pre,row)}}
 return d}
X.labCard=card;
async function teach(kind,free){const code=ed.value.slice(0,7000),lvl=q('#lbLvl',P).value,er=errs.slice(-5).join('\n');
 const ask_={explica:'Explique, passo a passo e de forma simples, o que este código faz. Aponte 1 conceito importante para eu aprender.',erro:'Encontre os erros deste código e explique a causa de forma simples. Depois mande o código completo corrigido num bloco.'+(er?'\nErros que apareceram no console:\n'+er:''),desafio:'Me dê UM desafio curto e prático para fazer em cima deste código, adequado ao meu nível, com uma dica. Não dê a resposta.',melhora:'Sugira 2 melhorias para este projeto e mande o código completo já melhorado num bloco, comentando as partes novas.'}[kind]||free;
 const um=(ask_)+'\n\nLinguagem: '+LGN[lg]+'. Meu código atual:\n```'+({web:'html',js:'javascript',py:'python'}[lg])+'\n'+code+'\n```';
 const sy='Você é J.A.R.V.I.S., professor particular de programação e informática do senhor (nível '+lvl+'). Ensine em português do Brasil, com paciência e frases curtas, como um mentor de laboratório: explique o porquê, use analogias simples e incentive. Quando mandar código, mande completo e funcional num bloco ```'+({web:'html',js:'javascript',py:'python'}[lg])+'```, pronto para rodar no simulador do app (páginas web num arquivo HTML único; Python sem bibliotecas que precisem de janela). Termine com uma sugestão do que testar em seguida. Nunca diga que rodou ou testou o código.';
 out.prepend(card('u',free||({explica:'💡 Explicar o código',erro:'🩺 Achar o erro',desafio:'🎯 Me dê um desafio',melhora:'✨ Melhorar o projeto'}[kind])));const wait=card('a','Analisando o código, senhor…');wait.classList.add('wait');out.prepend(wait);
 hist.push({role:'user',content:um});hist=hist.slice(-8);
 try{const t=await X.tutorAsk(hist.map((m,i)=>i<hist.length-1&&m.role==='user'?{...m,content:m.content.replace(/```[\s\S]*```/,'[código anterior]')}:m),sy);hist.push({role:'assistant',content:t});wait.replaceWith(card('a',t));X.speakShort(t)}
 catch(e){hist.pop();wait.replaceWith(card('a','Não consegui falar com o professor agora: '+e.message+(/cr[eé]dito/i.test(e.message)?' Enquanto isso, as Aulas rápidas abaixo funcionam sem IA.':''),1))}}
X.labTeach=teach;
qa('[data-t]',P).forEach(b=>b.onclick=()=>teach(b.dataset.t));
q('#lbAskF',P).onsubmit=e=>{e.preventDefault();const v=q('#lbAsk',P).value.trim();if(!v)return;q('#lbAsk',P).value='';teach('',v)};

/* ---------- aulas ---------- */
const les=q('#lbLes',P);
LES.forEach(l=>{const b=ce('button','x');b.type='button';b.innerHTML=`<b>${esc(l.t)}</b><small>${esc(l.d)}</small>`;b.onclick=()=>openLesson(l);les.append(b)});
function openLesson(l){stash();nameI.value=l.t.replace(/ · /,' - ');setLg(l.lg,l.c);if(l.lg!=='web')run();out.prepend(card('a','📘 '+l.t+'\n'+l.d+'\nQuando terminar, toque em 🎯 Me dê um desafio.'));X.speakShort(l.d);q('#sLb').scrollTo({top:0,behavior:'smooth'})}

/* ---------- inicial ---------- */
const cur=LSg('jv_lab_cur',null);if(cur&&cur.c){nameI.value=cur.n||'';setLg(cur.lg||'web',cur.c)}else setLg('web',TPL.web);rProj();
pane('code').addEventListener('jx-show',()=>{paint();if(lg==='web'&&!fr.srcdoc)run()});

/* ---------- voz ---------- */
const isOpen=()=>q('#sLb').classList.contains('show')&&!pane('code').hidden;
X.addCmd((s,n)=>{let m;
 if(/^(?:abr\w*|mostr\w*|ir para|entrar no|entre no|ativ\w*)\s+(?:o |a )?(?:laboratorio(?: dev| de codigo)?|lab|editor(?: de codigo)?|aba de codigos?|codigos?|programacao)$/.test(n)){X.labPane('code');return'Laboratório aberto, senhor. Editor à esquerda, celular à direita.'}
 if(m=n.match(/^(?:me )?(?:ensin\w*|quero aprender|aula de|vamos aprender|me de uma aula de)\s+(?:a programar em |a programar |programacao em |sobre )?(python|javascript|js|html|css|site|sites|programar|programacao)\b/)){const k=m[1],L=/python/.test(k)?'py':/javascript|^js/.test(k)?'js':'web';X.labPane('code');openLesson(LES.find(x=>x.lg===L));return'Vamos lá, senhor. Comecei pela primeira aula de '+({py:'Python',js:'JavaScript',web:'sites'}[L])+'. O código já está no editor.'}
 if(!isOpen())return null;
 if(/^(rod\w*|execut\w*|test\w*|roda)(?: o)?(?: codigo| programa| projeto)?$/.test(n)){run();return'Executando, senhor. Veja o resultado no celular.'}
 if(/^(baix\w*|export\w*|salv\w* no (?:celular|aparelho))(?: o| este| esse)?(?: codigo| projeto| arquivo)?$/.test(n)){const nm=dl();return nm?'Baixei o arquivo '+nm+'.':'O editor está vazio.'}
 if(/^salv\w*(?: o)?(?: codigo| projeto)?$/.test(n)){saveProj();return'Projeto salvo neste aparelho.'}
 if(/^(?:me )?expli\w*(?: o| este| esse)?(?: codigo)?$/.test(n)){teach('explica');return'Analisando o código, senhor.'}
 if(/(ach\w*|encontr\w*|corrij\w*|arrum\w*)(?: o)? erro/.test(n)){teach('erro');return'Procurando o erro, senhor.'}
 if(/desafio/.test(n)){teach('desafio');return'Preparando um desafio à sua altura, senhor.'}
 if(/^(mostr\w*|ver)(?: o)? celular$/.test(n)){toggleView(true);return'Mostrando o celular.'}
 if(/^(mostr\w*|ver)(?: o)? codigo$/.test(n)){toggleView(false);return'Mostrando o código.'}
 return null});
})();
