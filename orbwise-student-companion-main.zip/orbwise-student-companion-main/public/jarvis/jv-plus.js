/* J.A.R.V.I.S. — recursos extras: cores do arco-íris, modos do núcleo em lista, interromper,
   vídeo minimizado, tela cheia, sons de interface, teletipo, pomodoro no anel, diagnóstico,
   diário de bordo e a base das abas novas (Holograma e Laboratório).
   Usa as funções globais do index.html (cfg, save, sh, setS, add, speak, toast, foco…). */
(function(){
'use strict';
const q=(s,r)=>(r||document).querySelector(s),qa=(s,r)=>[...(r||document).querySelectorAll(s)];
const ce=(t,c,h)=>{const e=document.createElement(t);if(c)e.className=c;if(h!=null)e.innerHTML=h;return e};
const nz=s=>window.JV_norm?JV_norm(s):String(s||'').toLowerCase();
const LSg=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))??d}catch{return d}},LSs=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v));return true}catch{return false}};
const X=window.JVX={cmds:[],sys:[],LSg,LSs,ce,q,qa,nz};
X.addCmd=f=>X.cmds.push(f);X.addSys=f=>X.sys.push(f);
X.cmd=raw=>{const s=String(raw).replace(/^\s*j[aá]rvis[,\s]*/i,'').trim(),n=nz(s);for(const f of X.cmds){try{const r=f(s,n,raw);if(r)return r}catch(e){console.error(e)}}return null};
X.sysExtra=()=>X.sys.map(f=>{try{return f()||''}catch{return''}}).filter(Boolean).map(x=>'\n'+x).join('');

/* ---------- cores: troca o ciano fixo do visual por uma variável ---------- */
qa('style').forEach(st=>{const t=st.textContent,n=t.replace(/143,\s*220,\s*255/g,'var(--rgb)').replace(/42,\s*218,\s*255/g,'var(--rgb)').replace(/34,\s*220,\s*245/g,'var(--rgb)').replace(/(?<!--c:)#8fdcff/gi,'var(--c)');if(n!==t)st.textContent=n});
const CORES=[
 ['ciano','Ciano Stark','#a6ecff','#8cc4e0','166,236,255',0,1],
 ['azul','Azul','#8cb8ff','#7d9fd6','140,184,255',22,1],
 ['anil','Anil','#a29bff','#8f8ad6','162,155,255',48,1],
 ['violeta','Violeta','#d39bff','#b38ad6','211,155,255',80,1],
 ['rosa','Rosa','#ff9be0','#d68abd','255,155,224',122,1],
 ['vermelho','Vermelho','#ff7b7b','#d67f7f','255,123,123',162,1.1],
 ['laranja','Laranja','#ffb36b','#d69f6f','255,179,107',-168,1.2],
 ['amarelo','Amarelo','#ffe36b','#d6c46f','255,227,107',-148,1.2],
 ['verde','Verde','#7cf5a8','#72cf96','124,245,168',-55,1],
 ['branco','Branco','#eef6ff','#b9c6d6','238,246,255',0,.15]];
const ALIAS={ciano:'ciano',azul:'azul','azul claro':'ciano',celeste:'ciano',turquesa:'ciano',anil:'anil',indigo:'anil',roxo:'violeta',violeta:'violeta',lilas:'violeta',roxa:'violeta',rosa:'rosa',pink:'rosa',vermelho:'vermelho',vermelha:'vermelho',laranja:'laranja',amarelo:'amarelo',amarela:'amarelo',dourado:'amarelo',ouro:'amarelo',verde:'verde',branco:'branco',branca:'branco',prata:'branco'};
let rbT=null;
X.setColor=(k,keep)=>{const c=CORES.find(x=>x[0]===k)||CORES[0],r=document.documentElement.style;r.setProperty('--c',c[2]);r.setProperty('--d',c[3]);r.setProperty('--rgb',c[4]);r.setProperty('--orbh',c[5]+'deg');r.setProperty('--orbs',c[6]);X.rgb=c[4];X.color=c[2];if(!keep){clearInterval(rbT);rbT=null;cfg.theme=c[0];save()}qa('.jxsw button').forEach(b=>b.classList.toggle('on',b.dataset.k===(rbT?'arco':cfg.theme||'ciano')));const m=q('meta[name=theme-color]');if(m)m.content='#02070d';return c[1]};
X.rainbow=()=>{clearInterval(rbT);let i=0;rbT=setInterval(()=>{i=(i+1)%9;X.setColor(CORES[i][0],1)},2600);cfg.theme='arco';save();X.setColor(CORES[0][0],1);return'Modo arco-íris'};
const swHTML=()=>'<div class="jxsw">'+CORES.map(c=>`<button type="button" data-k="${c[0]}" title="${c[1]}" aria-label="Cor ${c[1]}" style="--k:${c[2]}"></button>`).join('')+'<button type="button" class="rb" data-k="arco" title="Arco-íris (troca sozinho)" aria-label="Arco-íris" style="--k:#fff"></button></div>';
document.addEventListener('click',e=>{const b=e.target.closest('.jxsw button');if(!b)return;const k=b.dataset.k;if(k==='arco'){X.rainbow();toast('Arco-íris: as cores vão girar sozinhas.')}else toast('Cor: '+X.setColor(k)+'.')});

/* ---------- modos do núcleo (lista) ---------- */
const MODOS=[['3d','◉','3D Holográfico','3D'],['2d','◎','2D Clássico','2D'],['pt','∴','Partículas Quânticas','PARTÍCULAS'],['arc','⟁','Reator Arc','REATOR'],['wave','≋','Ondas de Frequência','ONDAS'],['sphere','◍','Esfera Wireframe','ESFERA']];
X.mode=()=>cfg.orbX||(cfg.d3?'3d':cfg.pt?'pt':'2d');
X.setMode=k=>{const m=MODOS.find(x=>x[0]===k);if(!m)return'';cfg.orbX=['arc','wave','sphere'].includes(k)?k:'';cfg.d3=k==='3d';cfg.pt=k==='pt';save();try{d3u()}catch{}document.body.classList.toggle('ox',!!cfg.orbX);q('#d3b').textContent=m[3];qa('.jxmo').forEach(b=>b.classList.toggle('on',b.dataset.m===k));qa('select.jxModeSel').forEach(s=>s.value=k);sync();return m[2]};
const st=q('#stage'),cv=q('#orb'),ox=ce('canvas');ox.id='orbX';cv.after(ox);const ocx=ox.getContext('2d');
/* anel do pomodoro (criado antes do laço do núcleo para não quebrar a inicialização) */
const pm=ce('div','','<svg viewBox="0 0 100 100"><circle class="bg" cx="50" cy="50" r="49"/><circle class="fg" cx="50" cy="50" r="49" stroke-dasharray="307.9" stroke-dashoffset="0"/></svg><span></span>');pm.id='jxPomo';st.append(pm);
function pomoPos(){const el=(cfg.d3&&q('#orb3').offsetWidth)?q('#orb3'):cv;if(!el.offsetWidth)return;const w=el.offsetWidth*1.08;pm.style.width=pm.style.height=w+'px';pm.style.left=(el.offsetLeft+el.offsetWidth/2-w/2)+'px';pm.style.top=(el.offsetTop+el.offsetWidth/2-w/2)+'px'}
const menu=ce('div','',`<h4>MODO DO NÚCLEO</h4>${MODOS.map(m=>`<button type="button" class="jxmo" data-m="${m[0]}"><i>${m[1]}</i>${m[2]}</button>`).join('')}<h4 class="jxsep">COR DA INTERFACE</h4>${swHTML()}`);menu.id='jxMenu';menu.hidden=true;st.append(menu);
const d3b=q('#d3b');d3b.title='Escolher o modo do núcleo e a cor';d3b.onclick=e=>{e.stopPropagation();menu.hidden=!menu.hidden;X.sfx('tick')};
menu.addEventListener('click',e=>{const b=e.target.closest('.jxmo');if(b){toast('Modo: '+X.setMode(b.dataset.m)+'.');menu.hidden=true}});
document.addEventListener('pointerdown',e=>{if(!menu.hidden&&!menu.contains(e.target)&&e.target!==d3b)menu.hidden=true});
function sync(){if(!cv.offsetWidth)return;const d=Math.min(devicePixelRatio||1,2),w=cv.offsetWidth;ox.style.left=cv.offsetLeft+'px';ox.style.top=cv.offsetTop+'px';ox.style.width=ox.style.height=w+'px';if(ox.width!==Math.round(w*d))ox.width=ox.height=Math.round(w*d);pomoPos()}
addEventListener('resize',()=>setTimeout(sync,60));
const TAU=Math.PI*2;let T=0;
const col=a=>'rgba('+(X.rgb||'166,236,255')+','+a+')';
function arc(x,N,a){const c=N/2;x.translate(c,c);x.shadowColor=col(1);x.shadowBlur=N*.03;
 x.strokeStyle=col(.9);x.lineWidth=N*.012;x.beginPath();x.arc(0,0,N*.45,0,TAU);x.stroke();
 x.lineWidth=N*.004;x.strokeStyle=col(.5);x.beginPath();x.arc(0,0,N*.41,0,TAU);x.stroke();
 for(let i=0;i<10;i++){x.save();x.rotate(i/10*TAU+T*.15);x.fillStyle=col(.28+.45*a+.15*Math.sin(T*3+i));x.beginPath();x.moveTo(N*.26,-N*.045);x.lineTo(N*.39,-N*.07);x.lineTo(N*.39,N*.07);x.lineTo(N*.26,N*.045);x.closePath();x.fill();x.strokeStyle=col(.8);x.lineWidth=N*.003;x.stroke();x.restore()}
 x.save();x.rotate(-T*.5);x.setLineDash([N*.02,N*.015]);x.strokeStyle=col(.7);x.lineWidth=N*.006;x.beginPath();x.arc(0,0,N*.22,0,TAU);x.stroke();x.restore();
 x.save();x.rotate(T*.25);x.strokeStyle=col(.85);x.lineWidth=N*.008;x.beginPath();for(let i=0;i<3;i++){const g=i/3*TAU-Math.PI/2;x[i?'lineTo':'moveTo'](Math.cos(g)*N*.19,Math.sin(g)*N*.19)}x.closePath();x.stroke();x.restore();
 const r=N*(.12+.04*a+.008*Math.sin(T*4)),g=x.createRadialGradient(0,0,0,0,0,r*1.8);g.addColorStop(0,'rgba(255,255,255,.98)');g.addColorStop(.35,col(.9));g.addColorStop(1,col(0));x.fillStyle=g;x.beginPath();x.arc(0,0,r*1.8,0,TAU);x.fill()}
function wave(x,N,a){const c=N/2;x.translate(c,c);x.shadowColor=col(1);x.shadowBlur=N*.02;
 for(let i=0;i<72;i++){const g=i/72*TAU,v=.5+.5*Math.sin(i*.55+T*3.2)*Math.cos(i*.21-T*1.7),l=N*(.03+.13*v*(.35+a*1.4));x.strokeStyle=col(.45+.5*v);x.lineWidth=N*.008;x.beginPath();x.moveTo(Math.cos(g)*N*.3,Math.sin(g)*N*.3);x.lineTo(Math.cos(g)*(N*.3+l),Math.sin(g)*(N*.3+l));x.stroke()}
 x.save();x.beginPath();x.arc(0,0,N*.27,0,TAU);x.clip();for(let k=0;k<3;k++){x.strokeStyle=col(.9-k*.25);x.lineWidth=N*(.008-k*.002);x.beginPath();for(let px=-N*.3;px<=N*.3;px+=N*.01){const y=Math.sin(px/N*18+T*(3+k)+k)*N*(.03+.09*a)*(1-Math.abs(px)/(N*.3));x[px===-N*.3?'moveTo':'lineTo'](px,y)}x.stroke()}x.restore();
 x.strokeStyle=col(.6);x.lineWidth=N*.004;x.beginPath();x.arc(0,0,N*.27,0,TAU);x.stroke()}
function sphere(x,N,a){const c=N/2,R=N*(.36+.03*a),ry=T*.4,rx=.45,cs=Math.cos(ry),sn=Math.sin(ry),cx2=Math.cos(rx),sx=Math.sin(rx);x.translate(c,c);x.shadowColor=col(1);x.shadowBlur=N*.015;x.lineWidth=N*.004;
 const P=(la,lo)=>{let X1=Math.cos(la)*Math.cos(lo),Y=Math.sin(la),Z=Math.cos(la)*Math.sin(lo);const X2=X1*cs-Z*sn,Z2=X1*sn+Z*cs,Y2=Y*cx2-Z2*sx,Z3=Y*sx+Z2*cx2;return[X2*R,Y2*R,Z3]};
 const line=pts=>{for(let i=1;i<pts.length;i++){const p=pts[i-1],o=pts[i];x.strokeStyle=col(.18+.62*((p[2]+o[2])/2+1)/2);x.beginPath();x.moveTo(p[0],p[1]);x.lineTo(o[0],o[1]);x.stroke()}};
 for(let i=-3;i<=3;i++){const la=i/4*Math.PI/2,pts=[];for(let k=0;k<=40;k++)pts.push(P(la,k/40*TAU));line(pts)}
 for(let j=0;j<12;j++){const lo=j/12*TAU,pts=[];for(let k=0;k<=30;k++)pts.push(P(-Math.PI/2+k/30*Math.PI,lo));line(pts)}
 const g=x.createRadialGradient(0,0,0,0,0,R*.5);g.addColorStop(0,col(.35+.4*a));g.addColorStop(1,col(0));x.fillStyle=g;x.beginPath();x.arc(0,0,R*.5,0,TAU);x.fill()}
const DR={arc,wave,sphere};
(function loop(){requestAnimationFrame(loop);if(!cfg.orbX||document.hidden)return;if(ox.width!==Math.round(cv.offsetWidth*Math.min(devicePixelRatio||1,2))||ox.style.left!==cv.offsetLeft+'px')sync();T+=.016;const N=ox.width;if(!N)return;let a=0;try{a=Math.min(1,Math.max(0,amp||0))}catch{}ocx.setTransform(1,0,0,1,0,0);ocx.clearRect(0,0,N,N);ocx.save();(DR[cfg.orbX]||arc)(ocx,N,a);ocx.restore();ox.style.transform=cv.style.transform||''})();

/* ---------- sons de interface ---------- */
let AC=null;const ac=()=>{try{AC=AC||new(window.AudioContext||window.webkitAudioContext)();if(AC.state==='suspended')AC.resume();return AC}catch{return null}};
X.sfx=k=>{if(cfg.sfx===false)return;const a=ac();if(!a)return;const t=a.currentTime,o=a.createOscillator(),g=a.createGain();o.connect(g);g.connect(a.destination);
 const S={tick:[1600,1300,.025,.05,'square'],click:[900,1400,.04,.06,'triangle'],laser:[2400,500,.16,.08,'sawtooth'],boot:[180,980,.7,.09,'sine'],trash:[500,60,.35,.12,'sawtooth'],ok:[880,1320,.12,.07,'sine'],type:[2600,2200,.012,.02,'square']}[k]||[1000,1000,.03,.05,'sine'];
 o.type=S[4];o.frequency.setValueAtTime(S[0],t);o.frequency.exponentialRampToValueAtTime(S[1],t+S[2]);g.gain.setValueAtTime(S[3],t);g.gain.exponentialRampToValueAtTime(.0001,t+S[2]+.02);o.start(t);o.stop(t+S[2]+.03)};
document.addEventListener('pointerdown',e=>{const b=e.target.closest('button,nav button,.jxsw button');if(b&&!b.closest('#jxMenu .jxsw'))X.sfx(b.closest('nav')?'click':'tick')},true);
const go=q('#go');if(go)go.addEventListener('click',()=>X.sfx('boot'));

/* ---------- interromper ---------- */
const STOP=/^(j[aá]rvis[,\s]*)?(pare|para|para tudo|pare tudo|parar|sil[eê]ncio|fica quieto|fique quieto|cala a boca|cala-?se|chega|corta|cancela isso|stop|interromp\w*|basta|pode parar|j[aá] chega|t[aá] bom,? para)[.!\s]*$/i;
X.isStop=t=>{const x=String(t||'').trim();return STOP.test(x)||(!!X.clean&&STOP.test(X.clean(x)))};
X.cut=say=>{window.JVcut=Date.now();try{SY.cancel()}catch{}try{AU.pause();AU.currentTime=0}catch{}try{busy=false}catch{}try{setS('idle')}catch{}X.sfx('ok');if(say)try{add('n','Interrompido.')}catch{}try{setTimeout(resume,500)}catch{}stopBtn()};
const sb=ce('button','','<b></b>INTERROMPER');sb.id='jxStop';sb.type='button';sb.setAttribute('aria-label','Interromper a fala e a resposta');sb.onclick=e=>{e.stopPropagation();X.cut(true)};st.append(sb);
function stopBtn(){let s='idle';try{s=S}catch{}sb.classList.toggle('on',s==='speaking'||s==='thinking')}
setInterval(stopBtn,300);
st.addEventListener('pointerdown',e=>{let s='idle';try{s=S}catch{}if((s==='speaking'||s==='thinking')&&e.target.closest('#orb,#orb3')){e.stopPropagation();X.cut(true)}},true);
addEventListener('keydown',e=>{if(e.key!=='Escape')return;let s='idle';try{s=S}catch{}if(s==='speaking'||s==='thinking')X.cut(true)});

/* ---------- vídeo minimizado e envio de imagem para o holograma ---------- */
const vwEl=q('#vw'),vwH=q('#vwH'),vwX=q('#vwX');
if(vwEl&&vwH&&vwX){const mn=ce('button','jxvb','▁');mn.type='button';mn.id='vwMin';mn.setAttribute('aria-label','Minimizar em janela pequena');mn.title='Minimizar (o vídeo continua tocando)';
 const ho=ce('button','jxvb','◈');ho.type='button';ho.id='vwHo';ho.title='Abrir na Mesa Holográfica';ho.setAttribute('aria-label','Abrir na Mesa Holográfica');ho.hidden=true;
 vwX.before(ho,mn);
 const setMini=on=>{vwEl.classList.toggle('mini',on);vwEl.setAttribute('aria-modal',on?'false':'true');mn.textContent=on?'▢':'▁';mn.setAttribute('aria-label',on?'Voltar ao tamanho grande':'Minimizar em janela pequena');vwEl.style.left=vwEl.style.top='';vwEl.style.right=vwEl.style.bottom=''};
 X.vwMini=setMini;mn.onclick=()=>setMini(!vwEl.classList.contains('mini'));
 vwX.addEventListener('click',()=>setMini(false));
 ho.onclick=()=>{try{const it=VW.L[VW.i];const u=it&&(it.full||it.img||it.u);if(u&&X.holoUrl){setMini(false);try{vwClose()}catch{}X.holoUrl(u,it.title||'')}}catch{}};
 new MutationObserver(()=>{let k='';try{k=VW.k}catch{}ho.hidden=k!=='img';if(vwEl.hidden)vwEl.classList.remove('mini')}).observe(q('#vwB'),{childList:true});
 new MutationObserver(()=>{if(vwEl.hidden)setMini(false)}).observe(vwEl,{attributes:true,attributeFilter:['hidden']});
 let dr=null;vwH.addEventListener('pointerdown',e=>{if(!vwEl.classList.contains('mini')||e.target.closest('button'))return;const r=vwEl.getBoundingClientRect();dr={dx:e.clientX-r.left,dy:e.clientY-r.top};vwH.setPointerCapture(e.pointerId)});
 vwH.addEventListener('pointermove',e=>{if(!dr)return;const w=vwEl.offsetWidth,h=vwEl.offsetHeight;vwEl.style.right=vwEl.style.bottom='auto';vwEl.style.left=Math.max(4,Math.min(innerWidth-w-4,e.clientX-dr.dx))+'px';vwEl.style.top=Math.max(4,Math.min(innerHeight-h-4,e.clientY-dr.dy))+'px'});
 vwH.addEventListener('pointerup',()=>dr=null)}

/* ---------- tela cheia ---------- */
X.full=()=>{const d=document;if(d.fullscreenElement){d.exitFullscreen&&d.exitFullscreen();return'Saindo da tela cheia.'}const e=d.documentElement;if(!e.requestFullscreen)return'Este navegador não permite tela cheia. No celular, instale o app na tela inicial.';e.requestFullscreen().catch(()=>toast('O navegador não deixou entrar em tela cheia agora.'));return'Tela cheia ativada. Toque em ⛶ de novo para sair.'};
const meta=q('#meta');if(meta){const fb=ce('button','hb','⛶');fb.type='button';fb.id='jxFull';fb.title='Tela cheia';fb.setAttribute('aria-label','Tela cheia');fb.style.cssText='background:none;border:1px solid var(--ln);color:var(--c);border-radius:6px;padding:3px 7px;cursor:pointer;font-size:13px';fb.onclick=()=>toast(X.full());meta.append(fb)}

/* ---------- teletipo ---------- */
let teleOn=false;setTimeout(()=>teleOn=true,4000);
new MutationObserver(ms=>{if(!teleOn||cfg.tele===false||matchMedia('(prefers-reduced-motion:reduce)').matches)return;ms.forEach(m=>m.addedNodes.forEach(n=>{if(!(n instanceof HTMLElement)||!n.classList.contains('a')||n.classList.contains('gal')||n.classList.contains('vids'))return;const tn=n.firstChild;if(!tn||tn.nodeType!==3)return;const full=tn.nodeValue;if(!full||full==='…'||full.length<4)return;let i=0;const step=Math.max(1,Math.ceil(full.length/60));tn.nodeValue='';n.classList.add('jxtt');(function f(){if(tn.nodeValue!==full.slice(0,i)){tn.nodeValue=full;return}i=Math.min(full.length,i+step);tn.nodeValue=full.slice(0,i);if(i%(step*3)<step)X.sfx('type');if(i<full.length)requestAnimationFrame(f);else n.classList.remove('jxtt')})()}))}).observe(q('#log'),{childList:true});

/* ---------- pomodoro no anel do núcleo ---------- */
let fLast=null,fTot=1500,fChg=0;
setInterval(()=>{let v;try{v=fS}catch{return}const n=Date.now();if(fLast!==null&&v!==fLast){if(v>fLast||fLast-v>2){fTot=Math.max(v,1)}fChg=v<fLast?n:0}fLast=v;const run=fChg&&n-fChg<2600;pm.classList.toggle('on',!!run);if(run){pomoPos();q('.fg',pm).style.strokeDashoffset=String(307.9*(1-v/fTot));q('span',pm).textContent=String(Math.floor(v/60)).padStart(2,'0')+':'+String(v%60).padStart(2,'0')}},500);

/* ---------- diagnóstico animado ---------- */
const scan=ce('div');scan.id='jxScan';st.append(scan);
X.diag=()=>{document.body.classList.add('jxdiag');X.sfx('boot');setTimeout(()=>document.body.classList.remove('jxdiag'),3200)};

/* ---------- diário de bordo ---------- */
X.diary={list:()=>LSg('jv_diario',[]),add(t){const L=X.diary.list();L.unshift({t:Date.now(),x:String(t).trim().slice(0,1000)});LSs('jv_diario',L.slice(0,300));dispatchEvent(new Event('jx-diary'))},del(i){const L=X.diary.list();L.splice(i,1);LSs('jv_diario',L);dispatchEvent(new Event('jx-diary'))}};
const fdt=t=>new Date(t).toLocaleString('pt-BR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'});

/* ---------- abas novas: base ---------- */
const nav=q('nav'),navAfter=q('#nF');
X.sheet=(id,title,navId,ic,label)=>{const s=ce('div','sheet jxsheet');s.id=id;s.innerHTML=`<button class="x jxc" type="button">Fechar</button><h2>${title}</h2><div class="jxb"></div>`;document.body.append(s);q('.jxc',s).onclick=()=>sh();
 if(navId&&nav){const b=ce('button','jxn',label);b.type='button';b.id=navId;b.dataset.ic=ic;b.onclick=()=>X.open(id);(q('#nP')||navAfter).before(b)}
 new MutationObserver(()=>{if(!s.classList.contains('show')&&navId){const b=q('#'+navId);if(b)b.classList.remove('act')}try{X.saveTab()}catch{}}).observe(s,{attributes:true,attributeFilter:['class']});
 return q('.jxb',s)};
X.open=id=>{try{sh()}catch{}const s=q('#'+id);if(!s)return;s.classList.add('show');qa('nav button').forEach(b=>b.classList.remove('act'));const b=qa('nav .jxn').find(x=>x.onclick&&s.id&&x.id&&X._map[x.id]===id);if(b)b.classList.add('act');s.dispatchEvent(new Event('jx-open'))};
X._map={nHo:'sHo',nLb:'sLb'};
if(nav)nav.addEventListener('click',e=>{if(!e.target.closest('.jxn'))qa('nav .jxn').forEach(b=>b.classList.remove('act'))},true);

/* ---------- configurações extras ---------- */
const sC=q('#sC');if(sC){const c=ce('div','',`<h2>Estilo e extras</h2><div class="card"><b>Cor da interface</b><div class="hint">Toque numa cor ou diga "Jarvis, mude a cor para amarelo".</div>${swHTML()}</div>
<div class="card"><b>Modo do núcleo</b><div class="jxrow" style="margin-top:6px"><select class="jxModeSel grow">${MODOS.map(m=>`<option value="${m[0]}">${m[2]}</option>`).join('')}</select></div></div>
<div class="card"><label style="display:flex;gap:8px;align-items:center"><input type="checkbox" id="jxSfx"> Sons de interface (cliques e bipes)</label><label style="display:flex;gap:8px;align-items:center;margin-top:8px"><input type="checkbox" id="jxTele"> Efeito teletipo nas respostas</label><button class="x" id="jxFull2" type="button" style="margin-top:8px">⛶ Tela cheia</button></div>`);sC.append(c);
 const sf=q('#jxSfx',c),tl=q('#jxTele',c);sf.checked=cfg.sfx!==false;tl.checked=cfg.tele!==false;sf.onchange=()=>{cfg.sfx=sf.checked;save()};tl.onchange=()=>{cfg.tele=tl.checked;save()};q('#jxFull2',c).onclick=()=>toast(X.full());
 q('.jxModeSel',c).onchange=e=>toast('Modo: '+X.setMode(e.target.value)+'.')}

/* ---------- comandos de voz ---------- */
X.addCmd((s,n)=>{let m;
 if(m=n.match(/^(?:(?:mude|mudar|muda|troque|trocar|troca|coloque|coloca|deixe|deixa|altere|alterar|ponha|poe)\s+)?(?:a |o )?(?:cor|tema)(?:\s+(?:da interface|do hud|do jarvis|da tela|do sistema))?\s*(?:para|pra|em|de)?\s*(?:o |a )?([a-z ]+?)\s*$/)){const k=m[1].trim();if(/arco ?iris/.test(k))return X.rainbow()+' ligado: as cores vão girar sozinhas, senhor.';const c=ALIAS[k];if(c)return'Cor alterada para '+X.setColor(c).toLowerCase()+'. Combina com o senhor.';if(k)return'Não conheço a cor "'+k+'". Tenho: ciano, azul, anil, violeta, rosa, vermelho, laranja, amarelo, verde, branco e arco-íris.'}
 if(m=n.match(/^(?:ativar |ative |ligar |ligue |coloque |coloca |mude para |mudar para )?(?:o )?modo (3d|3 d|tres d|2d|2 d|dois d|plano|classico|particulas?|quantico|reator(?: arc)?|arc|ondas?|frequencia|esfera|wireframe)\b/)){const k=m[1],M=/3|tres/.test(k)?'3d':/2|dois|plano|classico/.test(k)?'2d':/partic|quant/.test(k)?'pt':/reator|arc/.test(k)?'arc':/onda|freq/.test(k)?'wave':'sphere';return'Núcleo em modo '+X.setMode(M)+'.'}
 if(/^(tela cheia|modo tela cheia|full hud|hud completo|sair da tela cheia)$/.test(n))return X.full();
 if(m=n.match(/^(?:inicie |iniciar |comece |comecar |ativar |ative )?(?:um |o )?(?:foco|pomodoro)\s+(?:de |por )?(\d{1,3})\s*min/)){const v=Math.max(1,Math.min(180,+m[1]));try{foco(v,'Foco total.')}catch{return null}return'Foco de '+v+' minutos iniciado. O anel do núcleo mostra o tempo, senhor.'}
 if(/diagnostico/.test(n))X.diag();
 if(m=s.match(/^(?:di[aá]rio(?:\s+de\s+bordo)?|registro\s+de\s+bordo|anote\s+no\s+di[aá]rio|registre\s+no\s+di[aá]rio)[:,]?\s+(.{2,})/i)){X.diary.add(m[1]);return'Registrado no diário de bordo às '+new Date().toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'})+'. Pode ver em Lab › Estúdio.'}
 if(/^(?:leia |ler |mostre |abra )?(?:o |meu )?diario(?: de bordo)?$/.test(n)){const L=X.diary.list();return L.length?'Últimos registros: '+L.slice(0,3).map(x=>fdt(x.t)+', '+x.x).join('; ')+'.':'O diário de bordo está vazio. Diga "diário:" e o que quer registrar.'}
 return null});
X.addSys(()=>'RECURSOS EXTRAS (o sistema executa por comando e confirma na tela): "mude a cor para amarelo" (ciano, azul, anil, violeta, rosa, vermelho, laranja, amarelo, verde, branco, arco-íris); "modo reator", "modo ondas", "modo esfera", "modo 3D", "modo 2D", "modo partículas"; "pare" ou "silêncio" interrompe a fala; "tela cheia"; "foco de 25 minutos"; "diário: texto" grava no diário de bordo; "abra a imagem da Mark 42" projeta na Mesa Holográfica; "abrir laboratório" (código com celular ao lado), "abrir estúdio" (quadro laser e slides), "aula de inglês" (tutor de idiomas). O vídeo aberto pode ser minimizado no botão ▁.');

/* ---------- entender frases faladas de jeito livre ---------- */
// Tira "Jarvis", "por favor", "você pode"… do começo/fim e corrige o que o reconhecimento de voz costuma errar.
const LEAD=/^\s*(?:ei|oi|ol[aá]|fala|j[aá]rvis|jarbas|por favor|por gentileza|faz (?:um )?favor(?: de)?|fa[cç]a (?:o |um )?favor(?: de)?|(?:voc[eê]|vc) (?:pode|poderia|consegue|conseguiria)|pode(?:ria)?|consegue|conseguiria|d[aá] (?:pra|para)|(?:eu )?(?:quero|queria|preciso) que (?:voc[eê]|vc)|agora|a[ií]|ent[aã]o|beleza|tipo)(?=[\s,!.?]|$)[\s,!.?]*/i;
X.clean=raw=>{let s=String(raw||'').trim(),p;
 do{p=s;s=s.replace(LEAD,'')}while(s!==p&&s);
 s=s.replace(/[\s,]*(?:por favor|por gentileza|pra mim|para mim|a[ií])[\s.!?]*$/i,'');
 s=s.replace(/\b(da|a|do|o|na|armadura)\s+(?:marca?|marc|marky|marque)\s+(\d{1,2})\b/gi,'$1 Mark $2').replace(/\bmark\s+quarenta e (?:dois|duas)\b/gi,'Mark 42').replace(/\bmark\s+oitenta e cinco\b/gi,'Mark 85').replace(/\bmark\s+cinquenta\b/gi,'Mark 50');
 s=s.replace(/\bholo ?grama\b/gi,'holograma').replace(/\bh[oó]lo\b/gi,'holograma').replace(/\blabor[aá]t[oó]rio\b/gi,'laboratório');
 return s.trim()||String(raw||'').trim()};

/* ---------- navegar pelas abas por voz ---------- */
const TABS=[[/^(?:agenda|calendario|compromissos|lembretes)$/,'#nA'],[/^(?:foco|pomodoro|habitos|rotina|notas)$/,'#nF'],[/^(?:config\w*|ajustes|preferencias)$/,'#nC'],[/^(?:celular|telefone|automacao)$/,'#nP'],[/^(?:holograma|mesa(?: holografica)?|bancada(?: holografica)?)$/,'ho'],[/^(?:laboratorio(?: dev| de codigo| stark)?|lab|editor(?: de codigo)?|codigos?|programacao|dev|aba de codigos?)$/,'code'],[/^(?:estudio|quadro(?: laser)?|slides?|desenhos?|lousa)$/,'studio'],[/^(?:idiomas?|linguas?|tutor(?: de idiomas)?|ingles|espanhol)$/,'lang'],[/^(?:inicio|tela inicial|home|nucleo|principal)$/,'home']];
X.addCmd((s,n)=>{const m=n.match(/^(?:abr\w*|abre|mostr\w*|exib\w*|ir (?:para|pro|pra|ao|a)|vai (?:para|pro|pra|ao)|vamos (?:para|pro|pra|ao)|bora (?:pro|pra)|entr\w* n[ao]|quero (?:ver|usar|abrir)|me leva (?:para|pro|pra|ao)|volt\w* (?:para|pro|pra|ao|a))\s+(?:o |a |os |as )?(?:aba |tela |pagina |area |parte )?(?:d[aoe] )?(.+)$/);
 if(!m)return null;const t=TABS.find(x=>x[0].test(m[1].trim()));if(!t)return null;const v=t[1];
 if(v==='home'){try{sh()}catch{}return'De volta ao núcleo, senhor.'}
 if(v==='ho'){X.open('sHo');return'Mesa holográfica pronta, senhor.'}
 if(v==='code'||v==='studio'||v==='lang'){if(!X.labPane)return null;X.labPane(v);return{code:'Laboratório aberto, senhor. Editor de um lado, celular do outro.',studio:'Estúdio aberto, senhor.',lang:'Tutor de idiomas aberto, senhor.'}[v]}
 const b=q(v);if(!b)return null;b.click();return'Aberto, senhor.'});
X.addCmd((s,n)=>{if(!/^(?:fech\w*|sai\w*)(?: d[aoe])?(?: (?:a |o |essa |esta )?(?:aba|tela|janela|painel|isso))?$/.test(n))return null;const v=q('#vw');if(v&&!v.hidden)return null;if(!q('.sheet.show'))return null;try{sh()}catch{}return'Fechado, senhor.'});

/* ---------- guardar tudo sozinho ---------- */
// banco local do aparelho para coisas grandes (imagens da mesa holográfica)
X.idb=(()=>{let dp=null;const db=()=>dp||(dp=new Promise((ok,no)=>{try{const r=indexedDB.open('jarvis',1);r.onupgradeneeded=()=>r.result.createObjectStore('kv');r.onsuccess=()=>ok(r.result);r.onerror=()=>no(r.error)}catch(e){no(e)}}));
 const tx=(m,f)=>db().then(d=>new Promise((ok,no)=>{const t=d.transaction('kv',m),r=f(t.objectStore('kv'));t.oncomplete=()=>ok(r&&r.result);t.onerror=()=>no(t.error)}));
 return{get:k=>tx('readonly',s=>s.get(k)),set:(k,v)=>tx('readwrite',s=>s.put(v,k)),del:k=>tx('readwrite',s=>s.delete(k))}})();
// aba aberta: volta para ela ao recarregar
const SHMAP={sA:'#nA',sF:'#nF',sP:'#nP',sC:'#nC',sJ:'#nJ',sHo:'#nHo',sLb:'#nLb'};let tabReady=false;
X.saveTab=()=>{if(!tabReady)return;const s=q('.sheet.show');LSs('jv_tab',s&&SHMAP[s.id]?s.id:'')};
qa('.sheet').forEach(s=>new MutationObserver(X.saveTab).observe(s,{attributes:true,attributeFilter:['class']}));
const afterBoot=()=>setTimeout(()=>{const id=LSg('jv_tab','');tabReady=true;if(id&&SHMAP[id]&&!q('.sheet.show')){const b=q(SHMAP[id]);if(b)b.click()}},700);
if(!document.getElementById('boot'))afterBoot();else new MutationObserver((_,o)=>{if(!document.getElementById('boot')){o.disconnect();afterBoot()}}).observe(document.body,{childList:true,subtree:true});
// texto que estava sendo digitado
const inp=q('#in'),bar=q('#bar');if(inp){const d=LSg('jv_draft','');if(d&&!inp.value)inp.value=d;inp.addEventListener('input',()=>LSs('jv_draft',inp.value));if(bar)bar.addEventListener('submit',()=>LSs('jv_draft',''),true)}
// conversa: quando muda, também vai para a conta (outro aparelho continua de onde parou)
let lastH=localStorage.getItem('jv_hist')||'[]';setInterval(()=>{const h=localStorage.getItem('jv_hist')||'[]';if(h!==lastH){lastH=h;LSs('jv_histAt',Date.now());try{syncPrefs()}catch{}}},4000);
// pomodoro continua contando mesmo depois de recarregar
try{const oF=foco,oS=fStop;foco=function(min,m){oF(min,m);LSs('jv_foco',{end:Date.now()+min*6e4,m})};fStop=function(){oS();LSs('jv_foco',null)};
 const f=LSg('jv_foco',null);if(f&&f.end>Date.now()+1500){oF(1,f.m||'Foco total.');fS=Math.round((f.end-Date.now())/1000);fTick()}else if(f)LSs('jv_foco',null)}catch(e){console.warn('foco',e)}

/* ---------- inicial ---------- */
if(cfg.theme==='arco')X.rainbow();else X.setColor(cfg.theme||'ciano',1);
X.setMode(X.mode());setTimeout(sync,300);setTimeout(sync,1500);
})();
