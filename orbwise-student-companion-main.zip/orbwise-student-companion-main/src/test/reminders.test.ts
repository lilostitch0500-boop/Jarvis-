import { describe, expect, it } from "vitest";
import { isReminderDue } from "@/lib/reminders";

const at = (iso: string) => new Date(iso).getTime();
const ev = (o: Partial<Parameters<typeof isReminderDue>[0]> = {}) => ({
  starts_at: "2026-10-23T15:00:00Z",
  remind_minutes: 10,
  notified_at: null,
  status: "ativo",
  ...o,
});

describe("lembretes da agenda", () => {
  it("dispara 10 minutos antes do compromisso", () => {
    expect(isReminderDue(ev(), at("2026-10-23T14:50:00Z"))).toBe(true);
    expect(isReminderDue(ev(), at("2026-10-23T14:49:00Z"))).toBe(false);
  });
  it("não dispara de novo depois de enviado", () => {
    expect(isReminderDue(ev({ notified_at: "2026-10-23T14:50:00Z" }), at("2026-10-23T14:55:00Z"))).toBe(false);
  });
  it("não dispara para compromisso cancelado", () => {
    expect(isReminderDue(ev({ status: "cancelado" }), at("2026-10-23T14:55:00Z"))).toBe(false);
  });
  it("não dispara sem lembrete definido", () => {
    expect(isReminderDue(ev({ remind_minutes: null }), at("2026-10-23T14:55:00Z"))).toBe(false);
  });
  it("antecipa até a janela da verificação periódica", () => {
    expect(isReminderDue(ev(), at("2026-10-23T14:48:00Z"), 150_000)).toBe(true);
  });
});
