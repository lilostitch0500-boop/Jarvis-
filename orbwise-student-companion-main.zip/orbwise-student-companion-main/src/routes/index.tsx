import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "J.A.R.V.I.S. — Assistente Pessoal" },
      {
        name: "description",
        content: "J.A.R.V.I.S. com voz masculina, HUD holográfico, protocolos e comandos de voz em português.",
      },
      { property: "og:title", content: "J.A.R.V.I.S. — Assistente Pessoal" },
      {
        property: "og:description",
        content: "Assistente de voz inspirado nos filmes, com HUD holográfico e protocolos.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  // Open the app directly (not inside a frame) so the browser allows the microphone.
  useEffect(() => {
    window.location.replace("/jarvis/index.html");
  }, []);
  return <div className="fixed inset-0 bg-background" />;
}
