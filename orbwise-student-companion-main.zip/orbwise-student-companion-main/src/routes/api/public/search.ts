import { createFileRoute } from "@tanstack/react-router";
import { requireUser } from "@/lib/server/auth";

const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130 Safari/537.36";

const ent = (s: string) =>
  s
    .replace(/<[^>]+>/g, "")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#x27;|&#39;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&nbsp;/g, " ")
    .replace(/\s+/g, " ")
    .trim();

const host = (u: string) => {
  try {
    return new URL(u).hostname.replace(/^www\./, "");
  } catch {
    return "";
  }
};

// Blocks local/private addresses so link checks can't reach internal services.
function safeUrl(u: string) {
  try {
    const x = new URL(u);
    if (x.protocol !== "https:" && x.protocol !== "http:") return false;
    const h = x.hostname;
    if (h === "localhost" || h.endsWith(".local") || h.endsWith(".internal")) return false;
    if (/^\d+\.\d+\.\d+\.\d+$/.test(h) || h.includes(":")) return false;
    return true;
  } catch {
    return false;
  }
}

async function timed(u: string, init: RequestInit = {}, ms = 7000) {
  const c = new AbortController();
  const t = setTimeout(() => c.abort(), ms);
  try {
    return await fetch(u, { ...init, signal: c.signal });
  } finally {
    clearTimeout(t);
  }
}

type Web = { url: string; title: string; snippet: string; verified: boolean; status: number | null; pageTitle?: string | undefined };
type Img = { img: string; full: string; page: string; title: string; source: string };

async function ddgWeb(q: string): Promise<Omit<Web, "verified" | "status">[]> {
  const r = await timed("https://html.duckduckgo.com/html/?kl=br-pt&q=" + encodeURIComponent(q), { headers: { "user-agent": UA } });
  if (!r.ok) throw new Error("busca " + r.status);
  const html = await r.text();
  const out: Omit<Web, "verified" | "status">[] = [];
  for (const block of html.split('class="result__body').slice(1)) {
    const a = /class="result__a"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/.exec(block);
    if (!a) continue;
    let href = (a[1] ?? "").replace(/&amp;/g, "&");
    const ud = /[?&]uddg=([^&]+)/.exec(href);
    if (ud?.[1]) href = decodeURIComponent(ud[1]);
    if (href.startsWith("//")) href = "https:" + href;
    if (!/^https?:\/\//.test(href) || /duckduckgo\.com\/y\.js/.test(href)) continue;
    const sn = /class="result__snippet"[^>]*>([\s\S]*?)<\/a>/.exec(block);
    out.push({ url: href, title: ent(a[2] ?? ""), snippet: sn ? ent(sn[1] ?? "") : "" });
    if (out.length >= 6) break;
  }
  return out;
}

async function wikiWeb(q: string): Promise<Omit<Web, "verified" | "status">[]> {
  const r = await timed(
    "https://pt.wikipedia.org/w/api.php?action=query&list=search&srlimit=4&format=json&srsearch=" + encodeURIComponent(q),
    { headers: { "user-agent": "JarvisApp/1.0" } },
  );
  const j = (await r.json()) as { query?: { search?: { title: string; snippet: string }[] } };
  return (j.query?.search ?? []).map((x) => ({
    url: "https://pt.wikipedia.org/wiki/" + encodeURIComponent(x.title.replace(/ /g, "_")),
    title: x.title + " — Wikipédia",
    snippet: ent(x.snippet),
  }));
}

// Opens each page now to confirm it exists; only confirmed pages are marked as verified.
async function verify(w: Omit<Web, "verified" | "status">): Promise<Web> {
  if (!safeUrl(w.url)) return { ...w, verified: false, status: null };
  try {
    const r = await timed(w.url, { headers: { "user-agent": UA, accept: "text/html,*/*" }, redirect: "follow" }, 6000);
    let pageTitle: string | undefined;
    if (r.ok && (r.headers.get("content-type") ?? "").includes("html")) {
      const txt = (await r.text()).slice(0, 60000);
      const m = /<title[^>]*>([\s\S]*?)<\/title>/i.exec(txt);
      if (m) pageTitle = ent(m[1] ?? "").slice(0, 140);
    } else {
      await r.body?.cancel();
    }
    return { ...w, verified: r.ok, status: r.status, pageTitle };
  } catch {
    return { ...w, verified: false, status: null };
  }
}

async function ddgImages(q: string): Promise<Img[]> {
  const p = await timed("https://duckduckgo.com/?iax=images&ia=images&q=" + encodeURIComponent(q), { headers: { "user-agent": UA } });
  const vqd = /vqd=["']?([\d-]+)/.exec(await p.text())?.[1];
  if (!vqd) throw new Error("sem token");
  const r = await timed(
    `https://duckduckgo.com/i.js?l=br-pt&o=json&f=,,,,,&p=1&q=${encodeURIComponent(q)}&vqd=${vqd}`,
    { headers: { "user-agent": UA, referer: "https://duckduckgo.com/" } },
  );
  if (!r.ok) throw new Error("imagens " + r.status);
  const j = (await r.json()) as { results?: { image: string; thumbnail: string; url: string; title: string; source?: string }[] };
  return (j.results ?? [])
    .filter((x) => /^https:/.test(x.thumbnail || x.image) && /^https?:/.test(x.url))
    .slice(0, 8)
    .map((x) => ({ img: x.thumbnail || x.image, full: x.image, page: x.url, title: ent(x.title || ""), source: host(x.url) }));
}

async function commonsImages(q: string): Promise<Img[]> {
  const r = await timed(
    "https://commons.wikimedia.org/w/api.php?action=query&generator=search&gsrnamespace=6&gsrlimit=8&prop=imageinfo&iiprop=url&iiurlwidth=520&format=json&gsrsearch=" +
      encodeURIComponent(q + " filetype:bitmap"),
    { headers: { "user-agent": "JarvisApp/1.0" } },
  );
  const j = (await r.json()) as { query?: { pages?: Record<string, { title: string; imageinfo?: { thumburl?: string; url?: string; descriptionurl?: string }[] }> } };
  return Object.values(j.query?.pages ?? {})
    .map((p) => ({ p, k: p.imageinfo?.[0] }))
    .filter(({ k }) => k?.thumburl)
    .map(({ p, k }) => ({ img: k!.thumburl!, full: k!.url ?? k!.thumburl!, page: k!.descriptionurl ?? "", title: p.title.replace(/^File:/, ""), source: "commons.wikimedia.org" }));
}

type Vid = { id: string; title: string; channel: string; duration: string; views: string; published: string; thumb: string; url: string };

const txt = (o: unknown): string => {
  const x = o as { simpleText?: string; runs?: { text?: string }[] } | undefined;
  return x?.simpleText ?? (x?.runs ?? []).map((r) => r.text ?? "").join("") ?? "";
};

// Reads the public YouTube results page and collects the listed videos.
async function ytVideos(q: string): Promise<Vid[]> {
  const r = await timed(
    "https://www.youtube.com/results?hl=pt-BR&gl=BR&search_query=" + encodeURIComponent(q),
    { headers: { "user-agent": UA, "accept-language": "pt-BR,pt;q=0.9", cookie: "SOCS=CAI; CONSENT=YES+1" } },
    9000,
  );
  if (!r.ok) throw new Error("youtube " + r.status);
  const html = await r.text();
  const i = html.indexOf("var ytInitialData = ");
  if (i < 0) throw new Error("sem dados");
  const j = html.indexOf(";</script>", i);
  const data = JSON.parse(html.slice(i + 20, j)) as unknown;
  const out: Vid[] = [];
  const seen = new Set<string>();
  const walk = (o: unknown, depth: number) => {
    if (out.length >= 8 || depth > 40 || !o || typeof o !== "object") return;
    if (Array.isArray(o)) {
      for (const v of o) walk(v, depth + 1);
      return;
    }
    const rec = o as Record<string, unknown>;
    const vr = rec["videoRenderer"] as Record<string, unknown> | undefined;
    if (vr && typeof vr["videoId"] === "string") {
      const id = vr["videoId"] as string;
      if (/^[\w-]{11}$/.test(id) && !seen.has(id) && vr["lengthText"]) {
        seen.add(id);
        out.push({
          id,
          title: txt(vr["title"]),
          channel: txt(vr["ownerText"]),
          duration: txt(vr["lengthText"]),
          views: txt(vr["shortViewCountText"]) || txt(vr["viewCountText"]),
          published: txt(vr["publishedTimeText"]),
          thumb: `https://i.ytimg.com/vi/${id}/hqdefault.jpg`,
          url: `https://www.youtube.com/watch?v=${id}`,
        });
      }
      return;
    }
    for (const v of Object.values(rec)) walk(v, depth + 1);
  };
  walk(data, 0);
  return out;
}

export const Route = createFileRoute("/api/public/search")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const who = await requireUser(request);
        if (who instanceof Response) return who;
        let q = "";
        let kind = "web";
        try {
          const b = (await request.json()) as { q?: unknown; kind?: unknown };
          q = String(b.q ?? "").trim().slice(0, 200);
          kind = b.kind === "images" ? "images" : b.kind === "videos" ? "videos" : "web";
        } catch {
          return Response.json({ error: "Pedido inválido" }, { status: 400 });
        }
        if (!q) return Response.json({ error: "Diga o que pesquisar" }, { status: 400 });
        const at = new Date().toISOString();

        if (kind === "videos") {
          let videos: Vid[] = [];
          try {
            videos = await ytVideos(q);
          } catch {
            /* reported below */
          }
          if (!videos.length) return Response.json({ error: "Não encontrei vídeos agora (o YouTube não respondeu).", at }, { status: 502 });
          return Response.json({ videos, engine: "YouTube", at });
        }

        if (kind === "images") {
          let engine = "DuckDuckGo Imagens";
          let images: Img[] = [];
          try {
            images = await ddgImages(q);
          } catch {
            /* fallback below */
          }
          if (images.length < 3) {
            try {
              const c = await commonsImages(q);
              if (c.length) engine = images.length ? engine + " + Wikimedia Commons" : "Wikimedia Commons";
              images = [...images, ...c].slice(0, 8);
            } catch {
              /* ignore */
            }
          }
          if (!images.length) return Response.json({ error: "Não encontrei imagens agora (as fontes não responderam).", at }, { status: 502 });
          return Response.json({ images, engine, at });
        }

        let engine = "DuckDuckGo";
        let raw: Omit<Web, "verified" | "status">[] = [];
        try {
          raw = await ddgWeb(q);
        } catch {
          /* fallback below */
        }
        if (!raw.length) {
          engine = "Wikipédia";
          try {
            raw = await wikiWeb(q);
          } catch {
            /* ignore */
          }
        }
        if (!raw.length) return Response.json({ error: "A pesquisa não respondeu agora. Sem resultados para mostrar.", at }, { status: 502 });
        const results = await Promise.all(raw.slice(0, 5).map(verify));
        return Response.json({ results, engine, at });
      },
    },
  },
});
