import { createFileRoute } from "@tanstack/react-router";
import { requireUser } from "@/lib/server/auth";

type Msg = { role: "user" | "assistant"; content: string };

const STYLE =
  "\nEstilo: como o J.A.R.V.I.S. dos filmes — educado, sereno, descontraído, chama o usuário de 'senhor'. " +
  "Pode fazer uma provocação sutil ou uma piada curta de vez em quando, sem exagerar na ironia e nunca à custa da precisão. " +
  "Respostas curtas e faladas (até 3 frases), sem markdown. " +
  "Nunca diga que executou uma ação, abriu algo, verificou uma página ou ativou uma integração se o sistema não confirmou isso na conversa.";

// Teaching mode (code lab, slides): code blocks allowed, still polite and in pt-BR.
const TUTOR =
  "\nEstilo: como o J.A.R.V.I.S. dos filmes, educado e sereno, chama o usuário de 'senhor'. Você é professor paciente: explique em português do Brasil, simples e passo a passo. " +
  "Pode e deve mandar código em blocos ```linguagem ... ``` quando ajudar. Fora dos blocos de código, sem markdown pesado. " +
  "Nunca diga que executou ou testou o código: quem executa é o simulador do app.";

// Built-in J.A.R.V.I.S. brain. Only signed-in users can use it.
export const Route = createFileRoute("/api/public/chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const who = await requireUser(request);
        if (who instanceof Response) return who;
        const key = process.env["LOVABLE_API_KEY"];
        if (!key) return Response.json({ error: "IA não configurada" }, { status: 500 });
        let system = "";
        let messages: Msg[] = [];
        let tutor = false;
        try {
          const b = (await request.json()) as { system?: string; messages?: Msg[]; mode?: string };
          system = String(b.system ?? "").slice(0, 12000);
          tutor = b.mode === "tutor";
          messages = (Array.isArray(b.messages) ? b.messages : [])
            .slice(-16)
            .map((m) => ({ role: m.role === "assistant" ? "assistant" : "user", content: String(m.content ?? "").slice(0, 12000) }));
        } catch {
          return Response.json({ error: "Pedido inválido" }, { status: 400 });
        }
        if (!messages.length) return Response.json({ error: "Sem mensagem" }, { status: 400 });

        const r = await fetch("https://ai.gateway.lovable.dev/v1/responses", {
          method: "POST",
          headers: { Authorization: `Bearer ${key}`, "content-type": "application/json" },
          body: JSON.stringify({
            model: "openai/gpt-6-astra",
            stream: true,
            reasoning: { effort: "low" },
            instructions:
              (system || "Você é J.A.R.V.I.S., a IA pessoal do usuário. Responda em português do Brasil.") +
              (tutor ? TUTOR : STYLE),
            input: messages.map((m) => ({ role: m.role, content: m.content })),
          }),
        });
        if (!r.ok || !r.body) {
          const t = await r.text();
          let msg = `HTTP ${r.status}`;
          try {
            const e = JSON.parse(t) as { message?: string; error?: { message?: string } };
            msg = e.message || e.error?.message || msg;
          } catch {
            /* ignore */
          }
          if (r.status === 402) msg = "Os créditos de IA do Jarvis acabaram. É preciso recarregar os créditos do projeto no Lovable para eu voltar a conversar.";
          else if (r.status === 403) msg = "O uso de IA está bloqueado no momento (limite de gastos do espaço de trabalho). " + msg;
          else if (r.status === 429) msg = "Muitos pedidos seguidos à IA. Tente de novo em alguns segundos.";
          return Response.json({ error: msg }, { status: r.status });
        }
        const reader = r.body.getReader();
        const dec = new TextDecoder();
        let buf = "";
        let text = "";
        for (;;) {
          const { done, value } = await reader.read();
          if (done) break;
          buf += dec.decode(value, { stream: true });
          const lines = buf.split("\n");
          buf = lines.pop() ?? "";
          for (const l of lines) {
            if (!l.startsWith("data:")) continue;
            try {
              const e = JSON.parse(l.slice(5));
              if (e.type === "response.output_text.delta") text += e.delta;
            } catch {
              /* ignore */
            }
          }
        }
        return Response.json({ text: text.trim() });
      },
    },
  },
});
