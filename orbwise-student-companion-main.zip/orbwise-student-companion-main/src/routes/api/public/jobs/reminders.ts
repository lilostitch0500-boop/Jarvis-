import { createFileRoute } from "@tanstack/react-router";
import { authenticateCronRequest } from "@/integrations/supabase/cron-auth";
import { isReminderDue } from "@/lib/reminders";
import { sendPush } from "@/lib/server/push";

// Runs on a schedule: sends agenda reminders as phone notifications, even with the app closed.
export const Route = createFileRoute("/api/public/jobs/reminders")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const authFailure = await authenticateCronRequest(request);
        if (authFailure) return authFailure;
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const now = Date.now();
        const { data: events, error } = await supabaseAdmin
          .from("events")
          .select("id,user_id,title,starts_at,remind_minutes,notified_at,status")
          .eq("status", "ativo")
          .is("notified_at", null)
          .not("remind_minutes", "is", null)
          .gte("starts_at", new Date(now - 6 * 3_600_000).toISOString())
          .lte("starts_at", new Date(now + 8 * 86_400_000).toISOString())
          .limit(500);
        if (error) return Response.json({ error: error.message }, { status: 500 });
        const due = (events ?? []).filter((e) => isReminderDue(e, now, 150_000));
        let sent = 0;
        for (const e of due) {
          const { data: subs } = await supabaseAdmin
            .from("push_subscriptions")
            .select("id,endpoint,p256dh,auth")
            .eq("user_id", e.user_id);
          const hora = new Date(e.starts_at).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit", timeZone: "America/Sao_Paulo" });
          for (const s of subs ?? []) {
            try {
              const st = await sendPush(s, {
                title: "Lembrete do J.A.R.V.I.S.",
                body: `${e.title} — ${hora}`,
                tag: "ev-" + e.id,
                url: "/jarvis/index.html",
              });
              if (st >= 200 && st < 300) sent++;
              else if (st === 404 || st === 410) await supabaseAdmin.from("push_subscriptions").delete().eq("id", s.id);
            } catch {
              /* keep going */
            }
          }
          await supabaseAdmin.from("events").update({ notified_at: new Date().toISOString() }).eq("id", e.id);
        }
        return Response.json({ due: due.length, sent });
      },
    },
  },
});
