import { createFileRoute } from "@tanstack/react-router";
import { vapidKeys } from "@/lib/server/vapid";

// Public half of the notification key (safe to share; browsers need it to subscribe).
export const Route = createFileRoute("/api/public/push-key")({
  server: {
    handlers: {
      GET: async () => {
        try {
          const { publicKey } = await vapidKeys();
          return Response.json({ publicKey }, { headers: { "cache-control": "no-store" } });
        } catch (e) {
          return Response.json({ error: (e as Error).message }, { status: 500 });
        }
      },
    },
  },
});
