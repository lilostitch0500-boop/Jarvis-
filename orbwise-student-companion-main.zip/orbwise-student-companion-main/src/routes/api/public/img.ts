import { createFileRoute } from "@tanstack/react-router";
import { requireUser } from "@/lib/server/auth";

// Hosts that must never be fetched by the server (local / private networks).
const PRIVATE =
  /^(localhost|.*\.local|.*\.internal|127\.|10\.|0\.|192\.168\.|169\.254\.|172\.(1[6-9]|2\d|3[01])\.|\[?::1\]?$|\[?f[cd][0-9a-f]{2}:|\[?fe80:)/i;
const MAX = 10_000_000;

// Fetches an internet image for the hologram table so the app can edit its pixels. Signed-in users only.
export const Route = createFileRoute("/api/public/img")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const who = await requireUser(request);
        if (who instanceof Response) return who;
        let u: URL;
        try {
          u = new URL(String(((await request.json()) as { url?: unknown }).url ?? ""));
        } catch {
          return Response.json({ error: "Link de imagem inválido" }, { status: 400 });
        }
        if (!/^https?:$/.test(u.protocol) || PRIVATE.test(u.hostname)) {
          return Response.json({ error: "Endereço não permitido" }, { status: 400 });
        }
        let r: Response;
        try {
          r = await fetch(u.toString(), {
            headers: {
              "user-agent": "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130 Mobile Safari/537.36",
              accept: "image/avif,image/webp,image/png,image/jpeg,image/*;q=0.8",
            },
            redirect: "follow",
            signal: AbortSignal.timeout(15000),
          });
        } catch {
          return Response.json({ error: "A imagem não respondeu" }, { status: 502 });
        }
        if (!r.ok) return Response.json({ error: `A imagem não abriu (HTTP ${r.status})` }, { status: 502 });
        const ct = r.headers.get("content-type") ?? "";
        if (!ct.startsWith("image/") || ct.includes("svg")) {
          return Response.json({ error: "Esse link não é uma foto" }, { status: 415 });
        }
        if (Number(r.headers.get("content-length") ?? 0) > MAX) {
          return Response.json({ error: "Imagem grande demais" }, { status: 413 });
        }
        const buf = await r.arrayBuffer();
        if (buf.byteLength > MAX) return Response.json({ error: "Imagem grande demais" }, { status: 413 });
        return new Response(buf, { headers: { "content-type": ct, "cache-control": "private, max-age=3600" } });
      },
    },
  },
});
