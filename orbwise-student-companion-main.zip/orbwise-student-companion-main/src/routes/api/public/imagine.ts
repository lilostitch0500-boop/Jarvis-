import { createFileRoute } from "@tanstack/react-router";
import { requireUser } from "@/lib/server/auth";
import { generateImage, imageSettings } from "@/lib/image-gateway.server";

// Creates a picture from a description for the Jarvis studio. Signed-in users only.
export const Route = createFileRoute("/api/public/imagine")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const who = await requireUser(request);
        if (who instanceof Response) return who;
        const apiKey = process.env["LOVABLE_API_KEY"];
        if (!apiKey) return Response.json({ error: "IA de imagens não configurada" }, { status: 500 });
        let prompt = "";
        let stream = true;
        try {
          const b = (await request.json()) as { prompt?: unknown; stream?: unknown };
          prompt = String(b.prompt ?? "").trim().slice(0, 2000);
          stream = b.stream !== false;
        } catch {
          return Response.json({ error: "Pedido inválido" }, { status: 400 });
        }
        if (prompt.length < 2) return Response.json({ error: "Descreva a imagem que deseja." }, { status: 400 });
        const upstream = await generateImage({ ...imageSettings, apiKey }, prompt, stream);
        return new Response(upstream.body, {
          status: upstream.status,
          headers: {
            "Content-Type": upstream.headers.get("Content-Type") ?? "application/json",
            "Cache-Control": "no-cache",
          },
        });
      },
    },
  },
});
