import { createFileRoute } from "@tanstack/react-router";
import { requireUser } from "@/lib/server/auth";

// Deep, calm male "butler" voice for J.A.R.V.I.S. via Lovable AI. Signed-in users only.
export const Route = createFileRoute("/api/public/tts")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const who = await requireUser(request);
        if (who instanceof Response) return who;
        const key = process.env["LOVABLE_API_KEY"];
        if (!key) return Response.json({ error: "Voz não configurada" }, { status: 500 });
        let text = "";
        try {
          text = String(((await request.json()) as { text?: string }).text ?? "").slice(0, 1200).trim();
        } catch {
          /* ignore */
        }
        if (!text) return Response.json({ error: "Texto vazio" }, { status: 400 });
        const r = await fetch("https://ai.gateway.lovable.dev/v1/audio/speech", {
          method: "POST",
          headers: { Authorization: `Bearer ${key}`, "content-type": "application/json" },
          body: JSON.stringify({
            model: "google/gemini-3.1-flash-tts-preview",
            contents: [
              {
                role: "user",
                parts: [
                  {
                    text: `Fale em português do Brasil com voz masculina grave, calma, confiante e elegante, como um mordomo britânico de inteligência artificial, com leve ironia refinada e ritmo fluido: ${text}`,
                  },
                ],
              },
            ],
            generationConfig: {
              responseModalities: ["AUDIO"],
              speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: "Charon" } } },
            },
          }),
        });
        if (!r.ok) {
          const body = await r.text();
          return new Response(body, { status: r.status, headers: { "content-type": "application/json" } });
        }
        return new Response(r.body, { headers: { "content-type": "audio/wav", "cache-control": "no-store" } });
      },
    },
  },
});
