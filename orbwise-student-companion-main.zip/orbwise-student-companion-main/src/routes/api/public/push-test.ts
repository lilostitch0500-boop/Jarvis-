import { createFileRoute } from "@tanstack/react-router";
import { requireUser } from "@/lib/server/auth";
import { sendPush } from "@/lib/server/push";

// Sends a real test notification to the signed-in user's devices and reports the result.
export const Route = createFileRoute("/api/public/push-test")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const who = await requireUser(request);
        if (who instanceof Response) return who;
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const { data: subs, error } = await supabaseAdmin
          .from("push_subscriptions")
          .select("id,endpoint,p256dh,auth")
          .eq("user_id", who.userId);
        if (error) return Response.json({ error: error.message }, { status: 500 });
        if (!subs?.length) return Response.json({ sent: 0, total: 0 });
        let sent = 0;
        for (const s of subs) {
          try {
            const st = await sendPush(s, { title: "J.A.R.V.I.S.", body: "Teste de notificação, senhor. Chegou.", tag: "teste" });
            if (st >= 200 && st < 300) sent++;
            else if (st === 404 || st === 410) await supabaseAdmin.from("push_subscriptions").delete().eq("id", s.id);
          } catch {
            /* count as not sent */
          }
        }
        return Response.json({ sent, total: subs.length });
      },
    },
  },
});
