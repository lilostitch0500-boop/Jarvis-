import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";

export const Route = createFileRoute("/entrar")({
  head: () => ({
    meta: [
      { title: "Entrar — J.A.R.V.I.S." },
      { name: "description", content: "Entre na sua conta para usar o J.A.R.V.I.S. com agenda, memória e música." },
      { property: "og:title", content: "Entrar — J.A.R.V.I.S." },
      { property: "og:description", content: "Acesso protegido ao seu assistente pessoal." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Entrar,
});

const APP = "/jarvis/index.html";

function Entrar() {
  const [mode, setMode] = useState<"in" | "up" | "reset">("in");
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const [msg, setMsg] = useState<{ t: string; err?: boolean } | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const leaving = new URLSearchParams(window.location.search).get("sair") === "1";
    if (leaving) {
      supabase.auth.signOut().then(() => {
        try {
          Object.keys(localStorage).filter((k) => k.startsWith("sb-") && k.endsWith("-auth-token")).forEach((k) => localStorage.removeItem(k));
        } catch {
          /* ignore */
        }
        window.history.replaceState(null, "", "/entrar");
        setMsg({ t: "Sessão encerrada. Até logo, senhor." });
      });
      return;
    }
    supabase.auth.getUser().then(({ data }) => {
      if (data.user) window.location.replace(APP);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((ev, s) => {
      if (ev === "SIGNED_IN" && s) window.location.replace(APP);
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setMsg(null);
    try {
      if (mode === "in") {
        const { error } = await supabase.auth.signInWithPassword({ email, password: pass });
        if (error) throw error;
        window.location.replace(APP);
      } else if (mode === "up") {
        const { data, error } = await supabase.auth.signUp({
          email,
          password: pass,
          options: { emailRedirectTo: window.location.origin + "/entrar" },
        });
        if (error) throw error;
        if (data.session) window.location.replace(APP);
        else setMsg({ t: "Conta criada. Confirme pelo link enviado ao seu e-mail e depois entre." });
      } else {
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: window.location.origin + "/reset-password",
        });
        if (error) throw error;
        setMsg({ t: "Se o e-mail existir, enviei um link para criar uma nova senha." });
      }
    } catch (err) {
      const m = (err as Error).message || "Falha";
      setMsg({
        t: /invalid login/i.test(m) ? "E-mail ou senha incorretos." : /not confirmed/i.test(m) ? "Confirme seu e-mail pelo link enviado antes de entrar." : m,
        err: true,
      });
    } finally {
      setBusy(false);
    }
  }

  async function social(p: "google" | "lovable") {
    setMsg(null);
    const r = await lovable.auth.signInWithOAuth(p, { redirect_uri: window.location.origin + "/entrar" });
    if (r.error) return setMsg({ t: "Não foi possível entrar: " + r.error.message, err: true });
    if (r.redirected) return;
    window.location.replace(APP);
  }

  return (
    <main className="relative flex min-h-screen items-center justify-center overflow-hidden bg-background px-4 font-mono text-foreground">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-30"
        style={{
          background:
            "radial-gradient(circle at 50% 35%, color-mix(in oklab, var(--primary) 35%, transparent), transparent 55%)",
        }}
      />
      <section className="relative w-full max-w-sm rounded-xl border border-primary/40 bg-card/90 p-6 shadow-[0_0_40px_color-mix(in_oklab,var(--primary)_25%,transparent)]">
        <div className="mx-auto mb-4 h-16 w-16 rounded-full border-2 border-primary shadow-[0_0_24px_var(--primary)]" />
        <h1 className="text-center text-xl font-bold tracking-[0.35em] text-primary">J.A.R.V.I.S.</h1>
        <p className="mt-1 text-center text-[11px] tracking-[0.2em] text-muted-foreground">
          {mode === "in" ? "IDENTIFIQUE-SE, SENHOR" : mode === "up" ? "NOVO CADASTRO" : "RECUPERAR SENHA"}
        </p>

        <form onSubmit={submit} className="mt-6 space-y-3">
          <label className="block text-xs text-muted-foreground">
            E-mail
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="mt-1 w-full rounded-md border border-input bg-background px-3 py-2 text-base text-foreground outline-none focus:border-primary"
              autoComplete="email"
            />
          </label>
          {mode !== "reset" && (
            <label className="block text-xs text-muted-foreground">
              Senha
              <input
                type="password"
                required
                minLength={6}
                value={pass}
                onChange={(e) => setPass(e.target.value)}
                className="mt-1 w-full rounded-md border border-input bg-background px-3 py-2 text-base text-foreground outline-none focus:border-primary"
                autoComplete={mode === "up" ? "new-password" : "current-password"}
              />
            </label>
          )}
          <button
            disabled={busy}
            className="w-full rounded-md bg-primary py-2.5 text-sm font-bold tracking-widest text-primary-foreground disabled:opacity-60"
          >
            {busy ? "AGUARDE…" : mode === "in" ? "ENTRAR" : mode === "up" ? "CRIAR CONTA" : "ENVIAR LINK"}
          </button>
        </form>

        {mode !== "reset" && (
          <div className="mt-4 space-y-2">
            <button
              onClick={() => social("google")}
              className="w-full rounded-md border border-primary/50 py-2.5 text-sm text-foreground hover:bg-accent"
            >
              Continuar com Google
            </button>
            <button
              onClick={() => social("lovable")}
              className="w-full rounded-md border border-border py-2 text-xs text-muted-foreground hover:bg-accent"
            >
              Continuar com Lovable
            </button>
          </div>
        )}

        {msg && (
          <p role="status" className={"mt-4 text-center text-sm " + (msg.err ? "text-destructive" : "text-primary")}>
            {msg.t}
          </p>
        )}

        <div className="mt-5 flex justify-between text-xs text-muted-foreground">
          {mode === "in" ? (
            <>
              <button onClick={() => setMode("up")} className="hover:text-primary">Criar conta</button>
              <button onClick={() => setMode("reset")} className="hover:text-primary">Esqueci a senha</button>
            </>
          ) : (
            <button onClick={() => setMode("in")} className="hover:text-primary">◂ Voltar para entrar</button>
          )}
        </div>
      </section>
    </main>
  );
}
