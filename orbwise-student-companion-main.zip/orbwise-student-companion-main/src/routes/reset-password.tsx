import { createFileRoute } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { title: "Nova senha — J.A.R.V.I.S." },
      { name: "description", content: "Defina uma nova senha para sua conta do J.A.R.V.I.S." },
      { property: "og:title", content: "Nova senha — J.A.R.V.I.S." },
      { property: "og:description", content: "Recuperação de acesso ao assistente." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Reset,
});

function Reset() {
  const [pass, setPass] = useState("");
  const [msg, setMsg] = useState<{ t: string; err?: boolean } | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    const { error } = await supabase.auth.updateUser({ password: pass });
    setBusy(false);
    if (error) return setMsg({ t: error.message, err: true });
    setMsg({ t: "Senha atualizada. Abrindo o Jarvis…" });
    setTimeout(() => window.location.replace("/jarvis/index.html"), 1200);
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-background px-4 font-mono text-foreground">
      <form onSubmit={submit} className="w-full max-w-sm space-y-4 rounded-xl border border-primary/40 bg-card p-6">
        <h1 className="text-center text-lg font-bold tracking-[0.3em] text-primary">NOVA SENHA</h1>
        <input
          type="password"
          required
          minLength={6}
          value={pass}
          onChange={(e) => setPass(e.target.value)}
          placeholder="Nova senha"
          className="w-full rounded-md border border-input bg-background px-3 py-2 text-base outline-none focus:border-primary"
          autoComplete="new-password"
        />
        <button disabled={busy} className="w-full rounded-md bg-primary py-2.5 text-sm font-bold tracking-widest text-primary-foreground disabled:opacity-60">
          {busy ? "AGUARDE…" : "SALVAR"}
        </button>
        {msg && <p className={"text-center text-sm " + (msg.err ? "text-destructive" : "text-primary")}>{msg.t}</p>}
      </form>
    </main>
  );
}
