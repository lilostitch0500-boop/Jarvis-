import { p256 } from "@noble/curves/nist.js";

const b64u = (u8: Uint8Array) =>
  btoa(String.fromCharCode(...u8))
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/, "");

/** VAPID key pair derived from the VAPID_SEED secret (stable across deploys). */
export async function vapidKeys() {
  const seed = process.env["VAPID_SEED"];
  if (!seed) throw new Error("VAPID_SEED ausente");
  const d = new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(seed)));
  const pub = p256.getPublicKey(d, false);
  return {
    publicKey: b64u(pub),
    jwk: { kty: "EC", crv: "P-256", x: b64u(pub.slice(1, 33)), y: b64u(pub.slice(33, 65)), d: b64u(d) },
  };
}
