import { createClient } from "@supabase/supabase-js";

/** Verifies the signed-in user's bearer token on a public server route. */
export async function requireUser(request: Request): Promise<{ userId: string } | Response> {
  const url = process.env["SUPABASE_URL"];
  const key = process.env["SUPABASE_PUBLISHABLE_KEY"];
  if (!url || !key) return Response.json({ error: "Servidor sem configuração de contas" }, { status: 500 });
  const m = /^Bearer\s+(\S+)$/.exec(request.headers.get("authorization") ?? "");
  const token = m?.[1];
  if (!token || token.split(".").length !== 3) {
    return Response.json({ error: "Entre na sua conta para usar o Jarvis." }, { status: 401 });
  }
  const sb = createClient(url, key, {
    auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
    global: {
      fetch: (input, init) => {
        const h = new Headers(init?.headers);
        if (h.get("Authorization") === `Bearer ${key}`) h.delete("Authorization");
        h.set("apikey", key);
        return fetch(input, { ...init, headers: h });
      },
    },
  });
  const { data, error } = await sb.auth.getClaims(token);
  const sub = data?.claims?.sub;
  if (error || !sub) return Response.json({ error: "Sessão expirada. Entre novamente." }, { status: 401 });
  return { userId: String(sub) };
}
