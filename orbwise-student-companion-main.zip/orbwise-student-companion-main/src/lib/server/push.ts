import { buildPushHTTPRequest } from "@pushforge/builder";
import { vapidKeys } from "./vapid";

export type Sub = { endpoint: string; p256dh: string; auth: string };
export type PushPayload = { title: string; body: string; tag?: string; url?: string };

/** Sends one notification. Returns the push service status (201 = accepted; 404/410 = expired). */
export async function sendPush(sub: Sub, payload: PushPayload): Promise<number> {
  const { jwk } = await vapidKeys();
  const { endpoint, headers, body } = await buildPushHTTPRequest({
    privateJWK: jwk,
    subscription: { endpoint: sub.endpoint, keys: { p256dh: sub.p256dh, auth: sub.auth } },
    message: { payload, adminContact: "mailto:jarvis@lovable.app", options: { ttl: 3600, urgency: "high" } },
  });
  const r = await fetch(endpoint, { method: "POST", headers, body });
  return r.status;
}
