export type ReminderEvent = {
  starts_at: string;
  remind_minutes: number | null;
  notified_at: string | null;
  status: string;
};

/** Moment the reminder should fire, or null when the event has no reminder. */
export function reminderAt(e: ReminderEvent): number | null {
  if (e.remind_minutes == null) return null;
  return new Date(e.starts_at).getTime() - e.remind_minutes * 60_000;
}

/**
 * A reminder is due when it is active, not yet sent, its moment has arrived
 * (with a small look-ahead so a periodic check is not late), and the event
 * started less than 6 hours ago (old ones are not sent anymore).
 */
export function isReminderDue(e: ReminderEvent, now: number, lookAheadMs = 0): boolean {
  if (e.status !== "ativo" || e.notified_at) return false;
  const at = reminderAt(e);
  if (at == null) return false;
  const start = new Date(e.starts_at).getTime();
  return at <= now + lookAheadMs && now - start < 6 * 3_600_000;
}
