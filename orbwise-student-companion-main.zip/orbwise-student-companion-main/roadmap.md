# Roadmap — J.A.R.V.I.S.

## Feito antes
- [x] Login, agenda própria, lembretes, protocolos, imagens, vídeos, pesquisa, memória, notificações (código)
- [x] Cores do arco-íris, modos do orbe em lista, interromper, vídeo minimizado, tela cheia, SFX, teletipo, pomodoro, diagnóstico, diário (código escrito)
- [x] Holograma, Laboratório, Estúdio, Idiomas, mini-player (código escrito)

## Operação atual ("pode começar a fazer e reajustar")
- [ ] 1. Erro de carregamento do jv-plus (pm antes de existir) e JVX.isStop
- [ ] 1. Saudação por horário (00–05 madrugada, nunca "bom dia")
- [ ] 1. Simulador do Lab: terminal não vaza da moldura; alternar código/celular no celular
- [ ] 2. Interpretação: frases livres ("bota a foto da armadura", "abre a mesa holográfica", "quero ver a mark 42")
- [ ] 3. Persistência: aba aberta, código do Lab, bancada do Holograma, conversa, preferências
- [ ] 5. Ligar Estúdio, Idiomas e mini-player no app
- [ ] 6. Palmas / "Jarvis" para ativar (verificar)
- [ ] Vistoria: zero erros no console, desktop e celular, todas as abas
- [ ] Atualizar cache do app (sw.js)

## Depois
- [ ] Criação de vídeos por IA
- [ ] Teste de notificação chegando no celular (precisa publicar e ativar no aparelho)
- [ ] Conversa e voz de estúdio dependem dos créditos de IA
